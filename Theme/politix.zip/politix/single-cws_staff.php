<?php
	get_header();

	global $cws_theme_funcs;

	/* -----> Variables declaration <----- */
	$p_id = get_queried_object_id();
	$deps = cws_vc_shortcode_get_post_term_links_str( 'cws_staff_member_department', ', ' );
	$poss = cws_vc_shortcode_get_post_term_links_str( 'cws_staff_member_position', ', ' );

	if( $cws_theme_funcs ){
		$sb = $cws_theme_funcs->cws_render_sidebars($p_id);
		$class = $sb['layout_class'].' '. $sb['sb_class'];
		$sb['sb_class'] = apply_filters('cws_print_single_class', $class);
	}

	/* -----> Get Post Meta <-----*/
	$post_meta = get_post_meta( get_the_ID(), 'cws_mb_post' );

	if( isset($post_meta[0]) ){
		$post_meta = $post_meta[0];

		if( isset($post_meta['experience']) ){
			$experience = esc_html($post_meta['experience']);
		}
		if( isset($post_meta['email']) ){
			$email = esc_html($post_meta['email']);
		}
		if( isset($post_meta['tel']) ){
			$tel = esc_html($post_meta['tel']);
		}
		if( isset($post_meta['biography']) ){
			$biography = esc_html($post_meta['biography']);
		}
	}

	?>
	<div class="<?php echo (isset($sb['sb_class']) ? $sb['sb_class'] : 'page-content'); ?>">
		<?php
		echo (isset($sb['content']) && !empty($sb['content'])) ? $sb['content'] : '';

		echo "<main id='page-content'>";

			echo "<div class='grid_row'>";
			$GLOBALS['cws_vc_shortcode_single_post_atts'] = array(
				'sb_layout'	=> $sb['layout_class'],
			);

			while ( have_posts() ) : the_post();
				echo "<article class='item cws_staff_single'>";
					echo "<div class='main_staff_info'>";

						cws_vc_shortcode_cws_staff_posts_grid_post_media();

						echo "<div class='information_wrapper'>";
							cws_vc_shortcode_cws_staff_posts_grid_post_title();
							if( !empty($deps) ){
								echo "<div class='department_list'>";
									echo sprintf('%s', $deps);
								echo "</div>";	
							}
							if ( !empty( $poss ) ){
								echo "<div class='position_list'>";
									echo sprintf('%s', $poss);
								echo "</div>";	
							}

							if ( !empty($experience) || !empty($tel) || !empty($email) ) {
							    echo '<div class="wrapper-staff-info">';
                                if (!empty($experience)) {
                                    echo "<div class='block-staff-info experience'>";
                                        echo "<span class='label'>" . esc_html__('Experience', 'politix') . ": </span>";
                                        echo "<span>" . $experience . "</span>";
                                    echo "</div>";
                                }
                                if (!empty($tel)) {
                                    echo "<div class='block-staff-info tel'>";
                                        echo "<a href='".esc_url("tel:" . $tel) . "'>" . $tel . "</a>";
                                    echo "</div>";
                                }
                                if (!empty($email)) {
                                    echo "<div class='block-staff-info email'>";
                                        echo "<a href='".esc_url("mailto:" . $email) . "'>" . $email . "</a>";
                                    echo "</div>";
                                }
                                echo '</div>';
                            }

                            echo "<div class='socials_wrapper'>";
                                cws_vc_shortcode_cws_staff_posts_grid_social_links();
                            echo "</div>";

						echo "</div>";

					echo "</div>";

					if( !empty($biography) ){
							echo "<h3 class='ce_title ce_title_div_left'>".esc_html__('Biography', 'politix')."</h3>";
							echo "<p>".$biography."</p>";
					}
                    the_content();

					cws_page_links();

				echo "</article>";

			endwhile;

			wp_reset_postdata();
			unset( $GLOBALS['cws_vc_shortcode_single_post_atts'] );

		echo "</div>";


		echo "</main>";
		echo (isset($sb['content']) && !empty($sb['content']) ) ? '</div>' : '';
		?>
	</div>

<?php
	get_footer();
?>
