<?php
	get_header ();

	global $cws_theme_funcs;
	global $politix_theme_standard;

	$pid = get_the_id();
	if ($cws_theme_funcs){
		$sb = $cws_theme_funcs->cws_render_sidebars( get_queried_object_id() );
		$class = $sb['layout_class'];
		$sb['sb_class'] = apply_filters('cws_print_single_class', $class);

		$meta = $cws_theme_funcs->cws_get_post_meta( $pid );
		if(isset($meta[0])){
			$meta = $meta[0];
		} 
		extract( shortcode_atts( array(
			'enable_lightbox' => '0',
			'author_info' => '1',
			'show_related' => '0',
			'show_featured' => '',
			'full_width_featured' => '',
		), $meta) );


		$fw_featured = $show_featured == '1' && $full_width_featured == '1';	
	}

	$page_class = '';
	$page_class .= (isset($sb) ? $sb['sb_class'] : 'page-content');
	$page_class .= isset($fw_featured) && $fw_featured ? ' full_width_featured' : '';

?>
<div class="<?php echo sprintf("%s", $page_class); ?>">
	<?php
	
	if ($cws_theme_funcs){	

		$GLOBALS['cws_vc_shortcode_single_post_atts'] = array(
			'sb_layout'	=> $sb['layout_class'],
		);	

		echo (isset($sb['content']) && !empty($sb['content'])) ? $sb['content'] : '';

		$related_projects_title = isset( $meta['rpo']['title'] ) ? $meta['rpo']['title'] : '';
		$related_projects_category = isset( $meta['rpo']['category'] ) ? $meta['rpo']['category'] : '';
		$related_projects_text_length = isset( $meta['rpo']['text_length'] ) ? $meta['rpo']['text_length'] : '90';
		$related_projects_cols = isset( $meta['rpo']['cols'] ) ? (int) $meta['rpo']['cols'] : '4';
		$related_projects_count = isset( $meta['rpo']['items_show'] ) ? (int) $meta['rpo']['items_show'] : '4';
		$posts_hide = isset( $meta['rpo']['posts_hide'] ) ? $meta['rpo']['posts_hide'] : '';

		$related_projects_category = !empty($related_projects_category) ? implode(',', $related_projects_category) : '';
		$posts_hide = !empty($posts_hide) ? implode(',', $posts_hide) : '';
	}

	$query_args = array(
		'post_type' => 'post',
		'ignore_sticky_posts' => true,
		'post_status' => 'publish',
	);
	$query_args["post__not_in"] = array( $pid );
	if ($cws_theme_funcs){
		if ( $related_projects_count ){
			$query_args['posts_per_page'] = $related_projects_count;
		}
	}
	$q = new WP_Query( $query_args );
	$related_posts = $q->posts;
	$has_related = false;
	if ( count( $related_posts ) > 0 ) {
		$has_related = true;
	}

	if ($cws_theme_funcs){
		$show_related_items = $show_related == 1 && $has_related;
	}

	$section_class = "news single";

	$query = cws_blog_defaults();

	$query['layout'] = '1';
	$query['post_hide_meta_override'] = true;
	$query['post_hide_meta'] = array('title');

	?>

	<main>
		<?php if(isset($sb['content']) && !empty($sb['content'])){ 
			echo '<i class="sidebar-tablet-trigger"></i>';
		} ?>
		<div class="grid_row clearfix">
			<section class="<?php echo esc_attr($section_class) ?>">
				<div class="cws_wrapper">
					<div class="grid">
						<?php

							while ( have_posts() ):
								the_post();
								cws_single_post_output($query);
							endwhile;
							wp_reset_postdata();
						?>
					</div>
				</div>
			</section>
        </div>

        <!-- Post navigation -->
        <div class="grid_row single_post_links">
            <div class="nav_post_links clearfix">

                <?php
                $prev_post = get_previous_post();
                if ( !empty($prev_post) ) {
                    $prev_id = get_previous_post()->ID;
                    $prev_title = get_previous_post()->post_title;
                    if (empty($prev_title)) {
                        $prev_title = '(no title)';
                    }

                    $prev_link = get_permalink($prev_id);
                }
                $next_post = get_next_post();
                if ( !empty($next_post) ) {
                    $next_id = get_next_post()->ID;
                    $next_title = get_next_post()->post_title;
                    if (empty($next_title)) {
                        $next_title = '(no title)';
                    }
                    $next_link = get_permalink($next_id);
                }
                $nav_category = array();
                if ( get_post_type() == 'cws_portfolio' ) {
                    $nav_category = get_the_terms ( $p_id, "cws_portfolio_cat" );
                }
                if ( get_post_type() == 'post' ) {
                    $nav_category = get_the_category();
                }
                $first_category_link = get_term_link($nav_category[0]->term_id);
                echo '<div class="prev_post nav_post">';
                    if ( !empty($prev_post) ) {
                        echo '<a href="' . esc_url($prev_link) . '" class="nav_post_link">';
                            echo '<span class="nav_post_label">' . esc_html__('Previous Post', 'politix') . '</span>';
                            echo '<span class="nav_post_title">' . $prev_title . '</span>';
                        echo '</a>';
                    }
                echo '</div>';
                if ( !empty($first_category_link) ) {
                    echo '<a class="archive_icon" href="' . esc_url($first_category_link) . '"></a>';
                }
                echo '<div class="next_post nav_post">';
                    if ( !empty($next_post) ) {
                        echo '<a href="' . esc_url($next_link) . '" class="nav_post_link">';
                            echo '<span class="nav_post_label">' . esc_html__('Next Post', 'politix') . '</span>';
                            echo '<span class="nav_post_title">' . $next_title . '</span>';
                        echo '</a>';
                    }
                echo '</div>';
                ?>

            </div>
        </div>

		<?php
            global $post;
            if ( isset($author_info) && !empty($author_info) && isset( $post->post_author ) ) {
                $post_author_name = get_the_author_meta( 'display_name', $post->post_author );
                if ( empty( $post_author_name ) ) {
                    $post_author_name = get_the_author_meta('nickname', $post->post_author);
                }

                $post_author_description = get_the_author_meta( 'user_description', $post->post_author );
                $post_author_link = get_author_posts_url( get_the_author_meta( 'ID' , $post->post_author));
                $post_author_avatar = get_avatar( get_the_author_meta('user_email') , 101 );

                echo '<div class="grid_row single_post_author">';
                    echo '<div class="block-author-info">';
                        echo '<div class="block-author-info_sticker sticker">';
                            echo '<div class="sticker_text">' . esc_html__('About author', 'politix') . '</div>';
                        echo '</div>';
                        echo ( !empty($post_author_link) && !empty($post_author_avatar) ? '<a class="block-author-info_avatar" href="' . esc_url($post_author_link) . '">' : '' );
                            echo ( !empty($post_author_avatar) ? $post_author_avatar : '' );
                        echo ( !empty($post_author_link) ? '</a>' : '' );
                        echo ( !empty($post_author_name) || !empty($post_author_description) ? '<div class="block-author-info_content">' : '' );
                            echo ( !empty($post_author_link) ? '<div class="block-author-info_name"><a href="' . esc_url($post_author_link) . '">' : '' );
                                echo ( !empty($post_author_name) ? esc_html($post_author_name) : '' );
                            echo ( !empty($post_author_link) ? '</a></div>' : '' );
                            echo ( !empty($post_author_description) ? '<div class="block-author-info_text">' . esc_html($post_author_description) . '</div>' : '' );
                        echo ( !empty($post_author_name) || !empty($post_author_description) ? '</div>' : '' );
                    echo '</div>';
                echo '</div>';
            }


			if ( $cws_theme_funcs && $show_related_items ){
				$crop_image = $cws_theme_funcs -> cws_get_option('crop_related_items');
				$crop_image = isset($crop_image) ? (bool)$crop_image : '';

				$mode = $q->post_count > $related_projects_cols ? '1' : '0';
				
				$terms = wp_get_post_terms( get_queried_object_id(), 'category' );
				$term_slugs = array();
				for ( $i=0; $i < count( $terms ); $i++ ){
					$term = $terms[$i];
					$term_slug = $term->slug;
					array_push( $term_slugs, $term_slug );
				}
				$term_slugs = implode( ",", $term_slugs );
				$p_id = get_queried_object_id();
				$sc_atts = array(
					'title' 						=> $related_projects_title,
					'tax' 							=> 'category',
					'related_items' 				=> true,
  					'terms' 						=> !empty($related_projects_category) ? $related_projects_category : $term_slugs,
  					'total_items_count'				=> $related_projects_count,
  					'display_style'					=> ($related_projects_count > $related_projects_cols ? 'carousel' : 'grid'),
  					'layout'						=> $related_projects_cols,
  					'chars_count' 					=> $related_projects_text_length,
  					'post_hide_meta_override'		=> true,
  					'navigation_carousel'			=> true,
  					'crop_featured'					=> $crop_image,
  					'drop_padding'					=> true,
  					'meta_position'					=> 'bottom',
  					'post_hide_meta'				=> $posts_hide,
  					'addl_query_args'				=> array(
					'post__not_in'					=> array( $p_id )
					),
				);

				$related_projects_section = function_exists('cws_blog_output') ? cws_blog_output( $sc_atts ) : "";

				if( !empty($related_projects_section) ){
					echo "<div class='grid_row single_related'>";
						echo "<h3 class='related_item ce_title'>".esc_html($related_projects_title)."</h3>";
						echo sprintf('%s', $related_projects_section);
					echo "</div>";
				}
				
				unset( $GLOBALS['cws_vc_shortcode_single_post_atts'] );
			}

            comments_template();

            if ( is_singular() && comments_open() && (get_option( 'thread_comments' ) == '1') ){
                wp_enqueue_script('comment-reply');
            }
		?>

	    </main>
        <?php echo (isset($sb) && !empty($sb['content']) ) ? '</div>' : ''; ?>
    </div>

<?php

get_footer ();
?>