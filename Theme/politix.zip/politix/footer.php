<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Politix
 * @since Politix 1.0
 */
?>

	</div><!-- #cws-main -->

	<?php
    global $cws_theme_funcs;
		if ($cws_theme_funcs){
			$printed_footer = $cws_theme_funcs->cws_page_footer();
			echo sprintf("%s", $printed_footer);
		} else {
		?>
        <footer class="page-footer">
            <div class="bg-layer"></div>
            <div class="copyrights-area">
                <div class="container">
                    <div class="copyrights-container">
                        <div class="copyrights">
                            <?php esc_html_e('Copyright ', 'politix'); ?> <?php echo date("Y");?>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<?php
		}
	    echo cws_scroll_to_top();
	?>
	</div>
<!-- end body cont -->
<?php
wp_footer();
?>
</body>
</html>