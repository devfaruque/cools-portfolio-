<?php

/****************** WALKER CUSTOM MENU *********************/
class Walker_Nav_Menu_Edit_Custom extends Walker_Nav_Menu  {
    /**
     * @see Walker_Nav_Menu::start_lvl()
     * @since 3.0.0
     *
     * @param string $output Passed by reference.
     */
    function start_lvl( &$output, $depth = 0, $args = array() ) {
    }

    /**
     * @see Walker_Nav_Menu::end_lvl()
     * @since 3.0.0
     *
     * @param string $output Passed by reference.
     */
    function end_lvl( &$output, $depth = 0, $args = array() ) {
    }

    /**
     * @see Walker::start_el()
     * @since 3.0.0
     *
     * @param string $output Passed by reference. Used to append additional content.
     * @param object $item Menu item data object.
     * @param int $depth Depth of menu item. Used for padding.
     * @param object $args
     */
    function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        global $_wp_nav_menu_max_depth;

        $_wp_nav_menu_max_depth = $depth > $_wp_nav_menu_max_depth ? $depth : $_wp_nav_menu_max_depth;

        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

        ob_start();
        $item_id = esc_attr( $item->ID );
        $removed_args = array(
            'action',
            'customlink-tab',
            'edit-menu-item',
            'menu-item',
            'page-tab',
            '_wpnonce',
        );

        $original_title = '';
        if ( 'taxonomy' == $item->type ) {
            $original_title = get_term_field( 'name', $item->object_id, $item->object, 'raw' );
            if ( is_wp_error( $original_title ) )
                $original_title = false;
        } elseif ( 'post_type' == $item->type ) {
            $original_object = get_post( $item->object_id );
            $original_title = $original_object->post_title;
        }

        $classes = array(
            'menu-item menu-item-depth-' . $depth,
            'menu-item-' . esc_attr( $item->object ),
            'menu-item-edit-' . ( ( isset( $_GET['edit-menu-item'] ) && $item_id == $_GET['edit-menu-item'] ) ? 'active' : 'inactive'),
        );

        $title = $item->title;

        if ( ! empty( $item->_invalid ) ) {
            $classes[] = 'menu-item-invalid';
            /* translators: %s: title of menu item which is invalid */
            $title = sprintf( __( '%s (Invalid)', 'politix' ), $item->title );
        } elseif ( isset( $item->post_status ) && 'draft' == $item->post_status ) {
            $classes[] = 'pending';
            /* translators: %s: title of menu item in draft status */
            $title = sprintf( __('%s (Pending)', 'politix'), $item->title );
        }

        $title = empty( $item->label ) ? $title : $item->label;

        ?>
        <li id="menu-item-<?php echo esc_attr($item_id); ?>" class="<?php echo implode(' ', $classes ); ?>">
        <dl class="menu-item-bar">
            <dt class="menu-item-handle">
                <span class="item-title"><?php echo esc_html( $title ); ?></span>
                <span class="item-controls">
						<span class="spinner"></span>
						<span class="item-type"><?php echo esc_html( $item->type_label ); ?></span>
						<span class="item-order hide-if-js">
							<a href="<?php
                            echo esc_url(wp_nonce_url(
                                add_query_arg(
                                    array(
                                        'action' => 'move-up-menu-item',
                                        'menu-item' => $item_id,
                                    ),
                                    remove_query_arg($removed_args, admin_url( 'nav-menus.php' ) )
                                ),
                                'move-menu_item'
                            ));
                            ?>" class="item-move-up"><abbr title="<?php esc_attr_e('Move up', 'politix'); ?>">&#8593;</abbr></a>
							|
							<a href="<?php
                            echo esc_url(wp_nonce_url(
                                add_query_arg(
                                    array(
                                        'action' => 'move-down-menu-item',
                                        'menu-item' => $item_id,
                                    ),
                                    remove_query_arg($removed_args, admin_url( 'nav-menus.php' ) )
                                ),
                                'move-menu_item'
                            ));
                            ?>" class="item-move-down"><abbr title="<?php esc_attr_e('Move down', 'politix'); ?>">&#8595;</abbr></a>
						</span>
						<a class="item-edit" id="edit-<?php echo esc_attr($item_id); ?>" title="<?php esc_attr_e('Edit Menu Item', 'politix'); ?>" href="<?php
                        echo ( isset( $_GET['edit-menu-item'] ) && $item_id == $_GET['edit-menu-item'] ) ? admin_url( 'nav-menus.php' ) : esc_url(add_query_arg( 'edit-menu-item', $item_id, remove_query_arg( $removed_args, admin_url( 'nav-menus.php#menu-item-settings-' . $item_id ) ) ));
                        ?>"><?php _e( 'Edit Menu Item', 'politix' ); ?></a>
					</span>
            </dt>
        </dl>

        <div class="menu-item-settings wp-clearfix" id="menu-item-settings-<?php echo esc_attr($item_id); ?>">
            <?php if( 'custom' == $item->type ) : ?>
                <p class="field-url description description-wide">
                    <label for="edit-menu-item-url-<?php echo esc_attr($item_id); ?>">
                        <?php _e( 'URL', 'politix' ); ?><br />
                        <input type="text" id="edit-menu-item-url-<?php echo esc_attr($item_id); ?>" class="widefat code edit-menu-item-url" name="menu-item-url[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr( $item->url ); ?>" />
                    </label>
                </p>
            <?php endif; ?>
            <p class="description description-thin">
                <label for="edit-menu-item-title-<?php echo esc_attr($item_id); ?>">
                    <?php _e( 'Navigation Label', 'politix' ); ?><br />
                    <input type="text" id="edit-menu-item-title-<?php echo esc_attr($item_id); ?>" class="widefat edit-menu-item-title" name="menu-item-title[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr( $item->title ); ?>" />
                </label>
            </p>
            <p class="description description-thin">
                <label for="edit-menu-item-attr-title-<?php echo esc_attr($item_id); ?>">
                    <?php _e( 'Title Attribute', 'politix' ); ?><br />
                    <input type="text" id="edit-menu-item-attr-title-<?php echo esc_attr($item_id); ?>" class="widefat edit-menu-item-attr-title" name="menu-item-attr-title[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr( $item->post_excerpt ); ?>" />
                </label>
            </p>
            <p class="field-link-target description">
                <label for="edit-menu-item-target-<?php echo esc_attr($item_id); ?>">
                    <input type="checkbox" id="edit-menu-item-target-<?php echo esc_attr($item_id); ?>" value="_blank" name="menu-item-target[<?php echo esc_attr($item_id); ?>]"<?php checked( $item->target, '_blank' ); ?> />
                    <?php _e( 'Open link in a new window/tab', 'politix' ); ?>
                </label>
            </p>
            <p class="field-css-classes description description-thin">
                <label for="edit-menu-item-classes-<?php echo esc_attr($item_id); ?>">
                    <?php _e( 'CSS Classes (optional)', 'politix' ); ?><br />
                    <input type="text" id="edit-menu-item-classes-<?php echo esc_attr($item_id); ?>" class="widefat code edit-menu-item-classes" name="menu-item-classes[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr( implode(' ', $item->classes ) ); ?>" />
                </label>
            </p>
            <p class="field-xfn description description-thin">
                <label for="edit-menu-item-xfn-<?php echo esc_attr($item_id); ?>">
                    <?php _e( 'Link Relationship (XFN)', 'politix' ); ?><br />
                    <input type="text" id="edit-menu-item-xfn-<?php echo esc_attr($item_id); ?>" class="widefat code edit-menu-item-xfn" name="menu-item-xfn[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr( $item->xfn ); ?>" />
                </label>
            </p>
            <p class="field-description description description-wide">
                <label for="edit-menu-item-description-<?php echo esc_attr($item_id); ?>">
                    <?php _e( 'Description', 'politix' ); ?><br />
                    <textarea id="edit-menu-item-description-<?php echo esc_attr($item_id); ?>" class="widefat edit-menu-item-description" rows="3" cols="20" name="menu-item-description[<?php echo esc_attr($item_id); ?>]"><?php echo esc_html( $item->description ); ?></textarea>
                    <span class="description"><?php _e('The description will be displayed in the menu if the current theme supports it.', 'politix'); ?></span>
                </label>
            </p>

            <?php
            /* New fields insertion starts here */
            ?>

            <p class="field-custom description description-thin description-thin-custom">
                <label for="edit-menu-item-align-<?php echo esc_attr($item_id); ?>">
                    <?php _e( 'Text alignment', 'politix' ); ?><br />
                    <select class="widefat" id="edit-menu-item-align<?php echo esc_attr($item_id); ?>" data-item-option data-name="align-<?php echo esc_attr($item_id); ?>">
                        <option value="left" <?php if($item->align == "left"){echo 'selected="selected"';} ?>>Left</option>
                        <option value="center" <?php if($item->align == "center"){echo 'selected="selected"';} ?>>Center</option>
                        <option value="right" <?php if($item->align == "right"){echo 'selected="selected"';} ?>>Right</option>
                    </select>
                </label>
            </p>

            <?php
            $icon_data_attr = 'icon-'. esc_attr($item_id);

            $icons = cws_get_all_fa_icons();
            $isIcons = !empty($icons);

            $ficons = cws_get_all_flaticon_icons();
            $isFlatIcons = !empty($ficons);

            $output_icons = '<option value=""></option>';
            ?>

            <p class="field-custom description description-thin description-thin-custom">
                <label for="edit-menu-item-icon-<?php echo esc_attr($item_id); ?>">
                    <?php _e( 'Icon', 'politix' ); ?><br />
                    <select class="widefat icons-select" id="edit-menu-item-icon<?php echo esc_attr($item_id); ?>" data-item-option data-name="<?php echo esc_attr($icon_data_attr); ?>">
                        <?php
                        if ($isIcons){
                            $output_icons .= '<optgroup label="Font Awesome">';
                            foreach ($icons as $icon) {
                                $selected = ($item->icon === 'fa fa-' . $icon) ? ' selected' : '';
                                $output_icons .= '<option value="fa fa-' . esc_attr($icon) . '" '.esc_attr($selected).'>' . esc_attr($icon) . '</option>';
                            }
                            $output_icons .= '</optgroup>';
                        }

                        if ($isFlatIcons){
                            $output_icons .= '<optgroup label="Flaticon">';
                            foreach ($ficons as $icon) {
                                $selected = ($item->icon === 'flaticon-' . $icon) ? ' selected' : '';
                                $output_icons .= '<option value="flaticon-' . esc_attr($icon) . '" '.esc_attr($selected).'>' . esc_attr($icon) . '</option>';
                            }
                            $output_icons .= '</optgroup>';
                        }

                        printf('%s', $output_icons);
                        ?>
                    </select>
                    <br/><?php _e( 'Select icon from list', 'politix' ); ?>
                </label>
            </p>

            <p class="field-custom description description-thin">
                <?php
                $value = $item->hide;
                if($value != "") $value = "checked";
                ?>
                <label for="edit-menu-item-hide-<?php echo esc_attr($item_id); ?>">
                    <input type="checkbox" id="edit-menu-item-hide-<?php echo esc_attr($item_id); ?>" class="code edit-menu-item-custom" data-item-option data-name="hide-<?php echo esc_attr($item_id); ?>" value="hide" <?php echo esc_attr($value); ?> />
                    <?php _e( "Don't show in menu", 'politix' ); ?>
                </label>
            </p>

            <p class="field-custom description description-thin description-thin-custom">
                <?php
                $value = $item->tag;
                if($value != "") $value = "checked";
                ?>
                <label for="edit-menu-item-tag-<?php echo esc_attr($item_id); ?>">
                    <input type="checkbox" id="edit-menu-item-tag-<?php echo esc_attr($item_id); ?>" class="code edit-menu-item-custom" data-item-option data-name="tag-<?php echo esc_attr($item_id); ?>" value="tag" <?php echo esc_attr($value); ?> />
                    <?php _e( "Show tag label", 'politix' ); ?>
                </label>
            </p>

            <p class="field-custom description description-wide description-wide-custom">
                <label for="edit-menu-item-tag_text-<?php echo esc_attr($item_id); ?>">
                    <?php _e( 'Tag text', 'politix' ); ?><br />
                    <input type="text" id="edit-menu-item-tag_text-<?php echo esc_attr($item_id); ?>" class="widefat code edit-menu-item-tag_text" data-item-option data-name="tag_text-<?php echo esc_attr($item_id); ?>" value="<?php echo esc_attr( $item->tag_text ); ?>" />
                </label>
            </p>

            <p class="field-custom description description-thin description-thin-custom">
                <label for="edit-menu-item-tag_font_color-<?php echo esc_attr($item_id); ?>">
                    <?php _e( 'Tag color', 'politix' ); ?><br />
                    <input type="text" data-default-color="<?php echo esc_attr(POLITIX_FIRST_COLOR);?>" id="edit-menu-item-tag_font_color-<?php echo esc_attr($item_id); ?>" class="color_picker widefat code edit-menu-item-tag_font_color" data-item-option data-name="tag_font_color-<?php echo esc_attr($item_id); ?>" value="<?php echo esc_attr( $item->tag_font_color ); ?>" />
                </label>
            </p>

            <p class="field-custom description description-thin description-thin-custom">
                <label for="edit-menu-item-tag_bg_color-<?php echo esc_attr($item_id); ?>">
                    <?php _e( 'Tag background', 'politix' ); ?><br />
                    <input type="text" data-default-color="#ffffff" id="edit-menu-item-tag_bg_color-<?php echo esc_attr($item_id); ?>" class="color_picker widefat code edit-menu-item-tag_bg_color" data-item-option data-name="tag_bg_color-<?php echo esc_attr($item_id); ?>" value="<?php echo esc_attr( $item->tag_bg_color ); ?>" />
                </label>
            </p>

            <?php
            /* New fields insertion ends here */
            ?>
            <div class="menu-item-actions description-wide submitbox">
                <?php if( 'custom' != $item->type && $original_title !== false ) : ?>
                    <p class="link-to-original">
                        <?php printf( __('Original: %s', 'politix'), '<a href="' . esc_url( $item->url ) . '">' . esc_html( $original_title ) . '</a>' ); ?>
                    </p>
                <?php endif; ?>
                <a class="item-delete submitdelete deletion" id="delete-<?php echo esc_attr($item_id); ?>" href="<?php
                echo esc_url(wp_nonce_url(
                    add_query_arg(
                        array(
                            'action' => 'delete-menu-item',
                            'menu-item' => $item_id,
                        ),
                        remove_query_arg($removed_args, admin_url( 'nav-menus.php' ) )
                    ),
                    'delete-menu_item_' . esc_attr($item_id)
                )); ?>"><?php _e('Remove', 'politix'); ?></a> <span class="meta-sep"> | </span> <a class="item-cancel submitcancel" id="cancel-<?php echo esc_attr($item_id); ?>" href="<?php echo esc_url( add_query_arg( array('edit-menu-item' => $item_id, 'cancel' => time()), remove_query_arg( $removed_args, admin_url( 'nav-menus.php' ) ) ) );
                ?>#menu-item-settings-<?php echo esc_attr($item_id); ?>"><?php _e('Cancel', 'politix'); ?></a>
            </div>

            <input class="menu-item-data-db-id" type="hidden" name="menu-item-db-id[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr($item_id); ?>" />
            <input class="menu-item-data-object-id" type="hidden" name="menu-item-object-id[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr( $item->object_id ); ?>" />
            <input class="menu-item-data-object" type="hidden" name="menu-item-object[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr( $item->object ); ?>" />
            <input class="menu-item-data-parent-id" type="hidden" name="menu-item-parent-id[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr( $item->menu_item_parent ); ?>" />
            <input class="menu-item-data-position" type="hidden" name="menu-item-position[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr( $item->menu_order ); ?>" />
            <input class="menu-item-data-type" type="hidden" name="menu-item-type[<?php echo esc_attr($item_id); ?>]" value="<?php echo esc_attr( $item->type ); ?>" />
        </div><!-- .menu-item-settings-->
        <ul class="menu-item-transport"></ul>
        <?php

        $output .= ob_get_clean();

    }
}

/****************** WALKER *********************/
class Politix_Walker_Nav_Menu extends Walker {
    private $elements;
    private $elements_counter = 0;
    private $cws_theme_funcs;

    function __construct($a) {
        $this->cws_theme_funcs = $a;
    }

    function walk ($items, $depth, ...$args) {
        $this->elements = $this->get_number_of_root_elements($items);
        return parent::walk($items, $depth);
    }

    /**
     * @see Walker::$tree_type
     * @since 3.0.0
     * @var string
     */
    var $tree_type = array( 'post_type', 'taxonomy', 'custom' );

    /**
     * @see Walker::$db_fields
     * @since 3.0.0
     * @todo Decouple this.
     * @var array
     */
    var $db_fields = array( 'parent' => 'menu_item_parent', 'id' => 'db_id' );

    /**
     * @see Walker::start_lvl()
     * @since 3.0.0
     *
     * @param string $output Passed by reference. Used to append additional content.
     * @param int $depth Depth of page. Used for padding.
     */
    function start_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent<ul class=\"sub-menu\">";
        $output .= "\n";
    }
    /**
     * @see Walker::end_lvl()
     * @since 3.0.0
     *
     * @param string $output Passed by reference. Used to append additional content.
     * @param int $depth Depth of page. Used for padding.
     */
    function end_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n";
    }
    /**
     * @see Walker::start_el()
     * @since 3.0.0
     *
     * @param string $output Passed by reference. Used to append additional content.
     * @param object $item Menu item data object.
     * @param int $depth Depth of menu item. Used for padding.
     * @param int $current_page Menu item ID.
     * @param object $args
     */

    function logo_ini( $indent, $item ) {
        $logo_box = $this->cws_theme_funcs->cws_get_meta_option( 'logo_box' );
        extract($logo_box, EXTR_PREFIX_ALL, 'logo_box');

        $logo_cont = '';

        $logo_lr_spacing = $logo_tb_spacing = $main_logo_height = '';


        if ($logo_box_default !== 'custom') {
            $logo = isset($this->cws_theme_funcs->cws_get_option( 'logo_box' )[$logo_box_default]) ?
                $this->cws_theme_funcs->cws_get_option( 'logo_box' )[$logo_box_default] : ''; //Call from ThemeOptions
        } else {
            $logo = isset($this->cws_theme_funcs->cws_get_meta_option( 'logo_box' )['custom']) ? $this->cws_theme_funcs->cws_get_meta_option( 'logo_box' )['custom'] : '';
        }
        $logo_box_sticky = isset($this->cws_theme_funcs->cws_get_meta_option( 'sticky_menu' )['sticky']) ?
            $this->cws_theme_funcs->cws_get_meta_option( 'sticky_menu' )['sticky'] : ''; //Call from ThemeOptions
        $logo_box_mobile = isset($this->cws_theme_funcs->cws_get_meta_option( 'mobile_menu_box' )['mobile']) ?
            $this->cws_theme_funcs->cws_get_meta_option( 'mobile_menu_box' )['mobile'] : ''; //Call from ThemeOptions
        $mobile_logo_nav = isset($this->cws_theme_funcs->cws_get_meta_option( 'mobile_menu_box' )['navigation']) ?
            $this->cws_theme_funcs->cws_get_meta_option( 'mobile_menu_box' )['navigation'] : ''; //Call from ThemeOptions

        $logo_box_dimensions_sticky = isset($this->cws_theme_funcs->cws_get_meta_option( 'sticky_menu' )['dimensions_sticky']) ? $this->cws_theme_funcs->cws_get_meta_option( 'sticky_menu' )['dimensions_sticky'] : ''; //Call from ThemeOptions
        $logo_box_dimensions_mobile = isset($this->cws_theme_funcs->cws_get_meta_option( 'mobile_menu_box' )['dimensions_mobile']) ? $this->cws_theme_funcs->cws_get_meta_option( 'mobile_menu_box' )['dimensions_mobile'] : ''; //Call from ThemeOptions
        $mobile_logo_nav_dimensions = isset($this->cws_theme_funcs->cws_get_meta_option( 'mobile_menu_box' )['dimensions_navigation']) ? $this->cws_theme_funcs->cws_get_meta_option( 'mobile_menu_box' )['dimensions_navigation'] : ''; //Call from ThemeOptions

        if ( $logo_box_position == 'center' && $logo_box_in_menu == '1' && $logo_box_enable ) {
            if ( !empty($logo['src']) ) {
                $bfi_args = $bfi_args_sticky = $bfi_args_mobile = array();
                if ( is_array( $logo_box_dimensions ) ) {
                    foreach ( $logo_box_dimensions as $key => $value ) {
                        if ( ! empty( $value ) ) {
                            $bfi_args[ $key ] = $value;
                            $bfi_args['crop'] = true;
                        }
                    }
                }
                if ( is_array( $logo_box_dimensions_sticky ) ) {
                    foreach ( $logo_box_dimensions_sticky as $key => $value ) {
                        if ( ! empty( $value ) ) {
                            $bfi_args_sticky[ $key ] = $value;
                            $bfi_args_sticky['crop'] = true;
                        }
                    }
                }
                if ( is_array( $logo_box_dimensions_mobile ) ) {
                    foreach ( $logo_box_dimensions_mobile as $key => $value ) {
                        if ( ! empty( $value ) ) {
                            $bfi_args_mobile[ $key ] = $value;
                            $bfi_args_mobile['crop'] = true;
                        }
                    }
                }
                if ( is_array( $mobile_logo_nav_dimensions ) ) {
                    foreach ( $mobile_logo_nav_dimensions as $key => $value ) {
                        if ( ! empty( $value ) ) {
                            $bfi_args_nav[ $key ] = $value;
                            $bfi_args_nav['crop'] = true;
                        }
                    }
                }

                $logo_lr_spacing = $logo_tb_spacing = '';
                if ( is_array( $logo_box_margin ) ) {
                    $logo_lr_spacing = $this->cws_theme_funcs->cws_print_css_keys($logo_box_margin, 'margin-', 'px');
                    $logo_tb_spacing = $this->cws_theme_funcs->cws_print_css_keys($logo_box_margin, 'padding-', 'px');
                }

                $img_mrg = ! empty( $logo_lr_spacing ) ? "style='".esc_attr( $logo_lr_spacing )."'" : '';

                $logo_src = $this->cws_theme_funcs->cws_print_img_html($logo, $bfi_args, $main_logo_height);


                if(!empty($logo['src'])){
                    $logo_default = '<img '. $logo_src .' '. $img_mrg .' class="logo-desktop" />';
                }

                $logo_sticky = $this->cws_theme_funcs->cws_get_meta_option('sticky_menu')['sticky'];
                if ( isset($logo_sticky) && !empty( $logo_sticky['src'] ) ) {
                    $logo_sticky_src = $this->cws_theme_funcs->cws_print_img_html($logo_sticky['id'], (!empty($bfi_args_sticky) ? $bfi_args_sticky : null));
                }

                $logo_mobile = $this->cws_theme_funcs->cws_get_meta_option('mobile_menu_box')['mobile'];
                if (isset($logo_mobile) && !empty($logo_mobile['src'])) {
                    $logo_mobile_src = $this->cws_theme_funcs->cws_print_img_html($logo_mobile['id'], (!empty($bfi_args_mobile) ? $bfi_args_mobile : null));
                }

                $logo_nav = $this->cws_theme_funcs->cws_get_meta_option('mobile_menu_box')['navigation'];
                if (isset($logo_nav) && !empty($logo_nav['src'])) {
                    $logo_nav_src = $this->cws_theme_funcs->cws_print_img_html($logo_nav['id'], (!empty($bfi_args_nav) ? $bfi_args_nav : null));
                }

                $rety = home_url();

                $logo_cont = '
				</ul></div>
					<div class="menu-center-part menu-logo-part">
						<a class="logo" href="'.esc_url($rety).'">';

                if( !empty($logo['src']) ){
                    $file_parts = pathinfo($logo['src']);

                    $logo_cont .= "<div class='logo-default-wrapper logo-wrapper" . ($logo_box_with_site_name ? " logo-with-text" : "") . "'>";
                    if( $file_parts['extension'] == 'svg' ){
                        $logo_cont .= $this->cws_theme_funcs->cws_print_svg_html($logo, $bfi_args, $main_logo_height);
                    } else {
                        $logo_cont .= $logo_default;
                    }
                    $logo_cont .= "</div>";
                }

                if( !empty($logo_sticky_src) ){
                    $file_parts_sticky = pathinfo($logo['src']);

                    $logo_cont .= "<div class='logo-sticky-wrapper logo-wrapper" . ($logo_box_with_site_name ? " logo-with-text" : "") . "'>";
                    if( $file_parts_sticky['extension'] != 'svg' ){
                        $logo_cont .= ($logo_sticky_src ?  '<img '.$logo_sticky_src." class='logo-sticky' />" : '');
                    } else {
                        $logo_cont .= $this->cws_theme_funcs->cws_print_svg_html($logo_sticky, $bfi_args);
                    }
                    $logo_cont .= "</div>";
                }

                if( !empty($logo_nav_src) ){
                    $file_parts_nav = pathinfo($logo['src']);

                    $logo_cont .= "<div class='logo-navigation-wrapper logo-wrapper'>";
                    if( $file_parts_nav['extension'] != 'svg' ){
                        $logo_cont .= ($logo_nav_src ?  '<img '.$logo_nav_src." class='logo-navigation' />" : '');
                    } else {
                        $logo_cont .= $this->cws_theme_funcs->cws_print_svg_html($logo_nav, $bfi_args);
                    }
                    $logo_cont .= "</div>";
                }
                $logo_cont .= ($logo_box_with_site_name ? '<h3>' . esc_html( get_bloginfo("name") ) . '</h3>' : '');

                $logo_cont .= '
						</a>
					</div>
				<div class="menu-right-part"><ul class="main-menu">';
            } else {
                $logo_cont = '
				</ul></div>
					<div class="menu-center-part menu-logo-part">
						<h1 class="header_site_title">'.esc_html(get_bloginfo( 'name' )).'</h1>
					</div>
				<div class="menu-right-part"><ul class="main-menu">';
            }
        }
        return $logo_cont;
    }

    function site_name_ini( $indent, $item ) {
        $logo_box_position = $this->cws_theme_funcs->cws_get_meta_option( 'logo_box' )['position'];
        if ( $indent == 0 && $logo_box_position == 'center' ) {
            ob_start();
            ?>
            </ul>
            </div>
            <div class="menu-center-part menu-logo-part site_name" <?php echo isset( $logo_box_position ) && !empty(
                    $logo_box_position ) && $logo_box_position == 'center' && ! empty( $logo_tb_spacing ) ? " style='".esc_attr($logo_tb_spacing)."'" : ''; ?>>
                <a <?php echo ( ! empty( $logo_lr_spacing ) ? " style='".esc_attr($logo_lr_spacing)."'" : '') ?> class="logo" href="<?php echo esc_url( home_url() ); ?>" >
                    <h1 class='header_site_title'><?php bloginfo( 'name' ); ?></h1>
                </a>
            </div>
            <div class="menu-right-part">
                <ul class="main-menu">
            <?php
            $site_name_cont = ob_get_clean();
        } else {
            $site_name_cont = '';
        }

        return $site_name_cont;
    }

    function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

        $class_names = $value = '';

        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . sanitize_html_class( $item->ID );

        //Custom menu fields
        if ($item->align != 'left' && isset($item->align)){
            array_push($classes,'link_align_'.$item->align);
        }

        if ($item->hide == 'hide'){
            array_push($classes,'hide_link');
        }
        //Custom menu fields

        if ($item->menu_item_parent=="0") {
            $this->elements_counter += 1;
            if ($this->elements_counter>=$this->elements/2){
                array_push($classes,'sub-align-right');
            }
        }

        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
        $class_names = $class_names ? ' class="' . $class_names  . '"' : '';

        $id = apply_filters( 'nav_menu_item_id', 'menu-item-'. sanitize_html_class( $item->ID ), $item, $args );
        $id = $id ? ' id="' . $id . '"' : '';

        // logo in cont init;
        if ( $item->menu_item_parent == '0' && $this->elements_counter == floor(($this->elements / 2)+1) ) {
            $logo_container = $this->logo_ini( $indent, $item );
        } else {
            $logo_container = '';
        }

        $output .= $indent . (!empty($search_and_woo_icon_start) ? $search_and_woo_icon_start : '' ) . $logo_container . '<li' . $id . $value . $class_names .'>';

        $atts = array();
        $atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
        $atts['target'] = ! empty( $item->target )	 ? $item->target	 : '';
        $atts['rel']	= ! empty( $item->xfn )		? $item->xfn		: '';
        $atts['href']   = ! empty( $item->url )		? $item->url		: '';

        $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args );

        $attributes = '';
        foreach ( $atts as $attr => $value ) {
            if ( ! empty( $value ) ) {
                $value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }
        $item_output = !empty($args->before) ? $args->before : '';
        $item_output .= '<a'. $attributes .'>';

        $item_output .= ( !empty($args->link_before) ? $args->link_before : "" ) .
            apply_filters( 'nav_menu_item_title', $item->title, $item, $args, $depth ) .
            (is_rtl() ? '&#x200E;' : '') . ( !empty($args->link_after ) ? $args->link_after : "" );

        $item_output .= '</a>';

        if (is_array($item->classes)){
            if ( in_array( 'menu-item-has-children', $item->classes ) ){
                $item_output .= "<i class='button_open'></i>";
            }
        }

        $item_output .= ( !empty($args->after) ? $args->after : '' );

        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }

    /**
     * @see Walker::end_el()
     * @since 3.0.0
     *
     * @param string $output Passed by reference. Used to append additional content.
     * @param object $item Page data object. Not used.
     * @param int $depth Depth of page.
     */

    function end_el( &$output, $item, $depth = 0, $args = array() ) {

        $output .= "</li>\n".(!empty($search_and_woo_icon_end) ? $search_and_woo_icon_end : '');

        if( $this->elements_counter == $this->elements && $depth == 0 ){
            $output .= "<li class='mobile-menu-search'>". $this->cws_theme_funcs->cws_clean_search_form() . "</li>";
        }
    }
}

/****************** TOPBAR WALKER *********************/
class Politix_Walker_Nav_Topbar_Menu extends Walker {
    private $elements;
    private $elements_counter = 0;
    private $cws_theme_funcs;

    function __construct($a) {
        $this->cws_theme_funcs = $a;
    }

    function walk ($items, $depth, ...$args) {
        $this->elements = $this->get_number_of_root_elements($items);
        return parent::walk($items, $depth);
    }

    var $tree_type = array( 'post_type', 'taxonomy', 'custom' );
    var $db_fields = array( 'parent' => 'menu_item_parent', 'id' => 'db_id' );

    function start_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent<ul class=\"sub-menu\">";
        $output .= "\n";
    }

    function end_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n";
    }

    function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

        $class_names = $value = '';

        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . sanitize_html_class( $item->ID );

        if ($item->menu_item_parent=="0") {
            $this->elements_counter += 1;
            if ($this->elements_counter>$this->elements/2){
                array_push($classes,'right');
            }
        }

        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
        $class_names = $class_names ? ' class="' . $class_names  . '"' : '';

        $id = apply_filters( 'nav_menu_item_id', 'top-bar-menu-item-'. sanitize_html_class( $item->ID ), $item, $args );
        $id = $id ? ' id="' . $id . '"' : '';

        $output .= $indent . '<li' . $id . $value . $class_names .'>';

        $atts = array();
        $atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
        $atts['target'] = ! empty( $item->target )	 ? $item->target	 : '';
        $atts['rel']	= ! empty( $item->xfn )		? $item->xfn		: '';
        $atts['href']   = ! empty( $item->url )		? $item->url		: '';

        $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args );

        $attributes = '';
        foreach ( $atts as $attr => $value ) {
            if ( ! empty( $value ) ) {
                $value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        $item_output = !empty($args->before) ? $args->before : '';
        $item_output .= '<a'. $attributes .'>';

        $item_output .= ( !empty($args->link_before) ? $args->link_before : '' ) . apply_filters( 'the_title', $item->title, $item->ID ) . (is_rtl() ? '&#x200E;' : '') . ( !empty($args->link_after ) ? $args->link_after : '' );
        $item_output .= '</a>';

        $item_output .= ( !empty($args->after) ? $args->after : '' );

        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }

    function end_el( &$output, $item, $depth = 0, $args = array() ) {
        $output .= "</li>\n";
    }
}

/****************** COPYRIGHTS WALKER *********************/
class Politix_Walker_Nav_Copyright_Menu extends Walker {
    private $elements;
    private $elements_counter = 0;
    private $cws_theme_funcs;

    function __construct($a) {
        $this->cws_theme_funcs = $a;
    }

    function walk ($items, $depth, ...$args) {
        $this->elements = $this->get_number_of_root_elements($items);
        return parent::walk($items, $depth);
    }

    var $tree_type = array( 'post_type', 'taxonomy', 'custom' );
    var $db_fields = array( 'parent' => 'menu_item_parent', 'id' => 'db_id' );

    function start_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent<ul class=\"sub-menu\">";
        $output .= "\n";
    }

    function end_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n";
    }

    function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

        $class_names = $value = '';

        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . sanitize_html_class( $item->ID );

        if ($item->menu_item_parent=="0") {
            $this->elements_counter += 1;
            if ($this->elements_counter>$this->elements/2){
                array_push($classes,'right');
            }
        }

        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
        $class_names = $class_names ? ' class="' . esc_attr($class_names)  . '"' : '';

        $id = apply_filters( 'nav_menu_item_id', 'top-bar-menu-item-'. sanitize_html_class( $item->ID ), $item, $args );
        $id = $id ? ' id="' . $id . '"' : '';

        $output .= $indent . '<li' . $id . $value . $class_names .'>';

        $atts = array();
        $atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
        $atts['target'] = ! empty( $item->target )	 ? $item->target	 : '';
        $atts['rel']	= ! empty( $item->xfn )		? $item->xfn		: '';
        $atts['href']   = ! empty( $item->url )		? $item->url		: '';

        $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args );

        $attributes = '';
        foreach ( $atts as $attr => $value ) {
            if ( ! empty( $value ) ) {
                $value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        $item_output = !empty($args->before) ? $args->before : '';
        $item_output .= '<a'. $attributes .'>';

        $item_output .= ( !empty($args->link_before) ? $args->link_before : '' ) . apply_filters( 'the_title', $item->title, $item->ID ) . (is_rtl() ? '&#x200E;' : '') . ( !empty($args->link_after ) ? $args->link_after : '' );
        $item_output .= '</a>';

        $item_output .= ( !empty($args->after) ? $args->after : '' );

        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }

    function end_el( &$output, $item, $depth = 0, $args = array() ) {
        $output .= "</li>\n";
    }
}

/****************** WALKER COMMENTS *********************/
class Politix_Walker_Comment extends Walker_Comment {
	// init classwide variables
	var $tree_type = 'comment';
	var $db_fields = array( 'parent' => 'comment_parent', 'id' => 'comment_ID' );
	function __construct() { ?>
		<div class="comment_list">
	<?php }

	/** START_LVL
	 * Starts the list before the CHILD elements are added. Unlike most of the walkers,
	 * the start_lvl function means the start of a nested comment. It applies to the first
	 * new level under the comments that are not replies. Also, it appear that, by default,
	 * WordPress just echos the walk instead of passing it to &$output properly. Go figure.  */
	function start_lvl( &$output, $depth = 0, $args = array() ) {
		$GLOBALS['comment_depth'] = $depth + 1; ?>
		<div class="comments_children">
	<?php }

	/** END_LVL
	 * Ends the children list of after the elements are added. */
	function end_lvl( &$output, $depth = 0, $args = array() ) {
		$GLOBALS['comment_depth'] = $depth + 1; ?>
		</div><!-- /.children -->

	<?php }

	/** START_EL */
	function start_el( &$output, $comment, $depth = 0, $args = array(), $id = 0 ) {
		$depth++;
		global $cws_theme_funcs;
		$GLOBALS['comment_depth'] = $depth;
		$GLOBALS['comment'] = $comment;
		$parent_class = ( empty( $args['has_children'] ) ? '' : 'parent' );
		$old_version = 0;
		?>

		<div <?php comment_class( $parent_class ); ?> id="comment-<?php comment_ID() ?>">
			<div id="comment-body-<?php comment_ID() ?>" class="comment-body">
                    <?php
                    $is_avatar = get_avatar( $comment, $args['avatar_size'] );
                        if ( !empty($is_avatar) && $args['avatar_size'] != 0 ) {
                            echo '<div class="avatar-wrapper">';
                                echo get_avatar( $comment, $args['avatar_size'] );
                            echo '</div>';
                        }
                    ?>

                    <div class="comment-text">

						<?php $reply_args = array(
						    'add_below' => 'comment-body',
							'reply_text'    => esc_html__( 'Reply', 'politix' ),
							'depth'         => $depth,
							'max_depth'     => $args['max_depth']
						); ?>

						<div class="comment-header">
							<cite class="comment__author bypostauthor"><?php echo get_comment_author_link(); ?></cite>
					        <div class="comment-info">
					            <?php
								echo "<time class='comment__published-date'>";
								    echo '<span class="date">' . esc_html( get_comment_date( 'F j, Y' ) ) . '</span> <span class="time">' . __('at ', 'politix') . get_comment_date( 'g:i a' ) . '</span>';
								echo "</time>";

								comment_reply_link( array_merge( $args, $reply_args ) );
                                edit_comment_link( esc_html__('(Edit)', 'politix') );
								?>
							</div>
						</div><!-- /.comment-meta -->

						<?php
						if( !$comment->comment_approved ) { ?>
						    <div id="comment-content-<?php comment_ID(); ?>" class="description">
						        <em class="comment-awaiting-moderation"><?php esc_html_e('Your comment is awaiting moderation.', 'politix'); ?></em>
						    </div><!-- /.description -->
						<?php
						} else {
						    if ($comment->comment_type != 'pingback')
						    {
						        ?>
						        <div id="comment-content-<?php comment_ID(); ?>" class="description">
						        <?php
						        comment_text();
						        ?>
						        </div>
						        <?php
						    }
						} ?>

					</div><!-- /.comment-text -->

			</div><!-- /.comment-body -->

	<?php }

	function end_el(&$output, $comment, $depth = 0, $args = array() ) { ?>

		</div><!-- /#comment-' . get_comment_ID() . ' -->

	<?php }

	/** DESTRUCTOR
	 * I just using this since we needed to use the constructor to reach the top
	 * of the comments list, just seems to balance out :) */
	function __destruct() { ?>

	</div><!-- /#comment-list -->

	<?php }
}