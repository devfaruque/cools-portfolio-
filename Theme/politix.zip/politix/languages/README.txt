Please use any of the bellow methods to translate your theme:

1) a free application for editing translation files - Poedit:
http://www.poedit.net/

2) a free translation WordPress plugin - Loco Translate plugin:
https://wordpress.org/plugins/loco-translate/