<?php
	get_header ();
	global $cws_theme_funcs;

	$home_url = get_home_url();
	$out = '<main>';
	    $out .= '<div class="grid_row clearfix">';
	        $out .= '<div class="grid_col grid_col_12">';
	            $out .= '<div class="block-404">';
	                $out .= '<div class="block-404-number">4<span class="mark">0</span>4</div>';
	                $out .= '<div class="block-404-divider-icon">';
	                    $out .= '<div class="block-404-divider-icon-large"></div>';
	                $out .= '</div>';
	                $out .= '<h2 class="block-404-title">';
	                    $out .= esc_html__('Ooops! Page Not Found.', 'politix');
	                $out .= '</h2>';
	                $out .= '<div class="block-404-button">';
	                    $out .= "<a class='cws_custom_button button_style_default with_icon icon_position_right large' href='".esc_url($home_url)."'>";
	                        $out .= '<span class="button_title">' . esc_html__( 'Back to home', 'politix' ) . '</span>';
	                        $out .= '<span class="button_icon">';
	                            $out .= '<i class="cws_icon_large"></i>';
	                        $out .= '</span>';
	                    $out .= '</a>';
	                $out .= '</div>';
	            $out .= '</div>';
	        $out .= '</div>';
	    $out .= '</div>';
	$out .= '</main>';

    echo sprintf('<div class="page-content wrapper-404">%s</div>', $out);

    get_footer ();
?>