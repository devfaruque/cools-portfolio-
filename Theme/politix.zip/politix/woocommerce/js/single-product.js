"use strict";

//Fix search button on single page
jQuery(document).ready(function ($){
	$('.woocommerce-product-gallery__trigger').empty();
})


