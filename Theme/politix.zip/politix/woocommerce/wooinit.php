<?php

class Politix_WooExt{

	public $def_args;
	public $args;
	public $def_img_sizes;
	public $widget_args;

	public function __construct ( $args = array() ){
		$this->args = wp_parse_args( $args, $this->def_args );
		add_theme_support( 'woocommerce' );	// Declare Woo Support
		add_action( 'activate_woocommerce/woocommerce.php', array( $this, 'on_woo_activation' ), 10 );
		if ( class_exists( 'woocommerce' ) ) {
			$this->def_args = array(
				'shop_catalog_image_size' 		=> array(),
				'shop_single_image_size'		=> array(),
				'shop_thumbnail_image_size'		=> array(),
				'shop_thumbnail_image_spacings'	=> array(),
				'shop_single_image_spacings'	=> array()
			);
			add_action( 'after_switch_theme', array( $this, 'after_switch_theme' ) );
			add_action( 'woocommerce_init', array( $this, 'woo_init' ) );
			add_filter( 'woocommerce_enqueue_styles', '__return_false' );
			add_filter( 'woocommerce_show_page_title', '__return_false' );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_script' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_style' ), 11 );
			add_action( 'body_font_hook',  array( $this, 'body_font_styles' ) );
			add_action( 'header_font_hook',  array( $this, 'header_font_styles' ) );
			if ( class_exists('WC_List_Grid') ) {
				$this->gridlist_init();
			}
		}	
	}
	public function on_woo_activation (){
		/* set product images dimensions */
		update_option( 'shop_catalog_image_size', $this->args['shop_catalog_image_size'] ); 
		update_option( 'shop_single_image_size', $this->args['shop_single_image_size'] ); 
		update_option( 'shop_thumbnail_image_size', $this->args['shop_thumbnail_image_size'] ); 
		/* set product images dimensions */
	}
	public function after_switch_theme (){
		/* set product images dimensions */
		update_option( 'shop_catalog_image_size', $this->args['shop_catalog_image_size'] ); 
		update_option( 'shop_single_image_size', $this->args['shop_single_image_size'] ); 
		update_option( 'shop_thumbnail_image_size', $this->args['shop_thumbnail_image_size'] ); 
		/* set product images dimensions */
	}
	public function woo_init (){
		/* loop */
		remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10, 0 ); 
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5, 0 ); 
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5, 0 ); 
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10, 0 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
        remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );

        remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
        add_action( 'woocommerce_before_main_content', array($this, 'custom_output_content_wrapper'), 10 );
        remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
        add_action( 'woocommerce_after_main_content', array($this, 'custom_output_content_wrapper_end'), 10 );

        add_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 15 );

		add_action( 'woocommerce_after_shop_loop_item_title', array( $this, 'after_shop_loop_item_price_wrapper_open' ), 1 );
		add_action( 'woocommerce_after_shop_loop_item_title', array( $this, 'after_shop_loop_item_price_wrapper_close' ), 20 );

		add_action( 'woocommerce_before_shop_loop_item', array( $this, 'shop_loop_item_content_wrapper_open' ), 1 );
		add_action( 'woocommerce_before_subcategory', array( $this, 'shop_loop_item_content_wrapper_open' ), 1 );
		add_action( 'woocommerce_shop_loop_item_title', array( $this, 'shop_loop_item_info_wrapper_open' ), 9 );
		add_action( 'woocommerce_after_shop_loop_item_title', array( $this, 'shop_loop_item_info_wrapper_close' ), 25 );
		add_action( 'woocommerce_after_shop_loop_item_title', array( $this, 'shop_loop_item_content_wrapper_close' ), 28 );
		add_action( 'woocommerce_after_subcategory', array( $this, 'shop_loop_item_content_wrapper_close' ), 28 );
        add_filter( 'woocommerce_layered_nav_count', array( $this, 'custom_woocommerce_layered_nav_set_color_filter' ), 30, 3 );
        add_filter( 'woocommerce_layered_nav_term_html', array( $this, 'custom_woocommerce_layered_nav_fix_color_filter' ), 30, 4 );

		add_filter( 'loop_shop_per_page', array( $this, 'loop_products_per_page' ), 20 );
        add_filter( 'woocommerce_sale_flash', array( $this, 'custom_replace_sale_text' ) );
		/* \loop */

		add_filter( 'loop_shop_columns' , array( $this, 'cws_loop_shop_column' ), 10 );

		/* single */
		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10, 0 );
		add_action( 'woocommerce_after_single_product_summary', array( $this, 'single_product_divider_before_upsells' ), 14 );
		add_action( 'woocommerce_after_single_product_summary', array( $this, 'single_product_divider_before_related' ), 19 );
		add_action( 'woocommerce_cart_collaterals', array( $this, 'divider' ), 1 );
		add_filter( 'woocommerce_output_related_products_args', array( $this, 'related_products_args' ) );

        remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
        remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
        remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
        remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
        remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 );
        remove_action( 'woocommerce_review_before', 'woocommerce_review_display_gravatar', 10 );

        add_action( 'woocommerce_single_product_summary', array( $this, 'single_product_info_banner' ), 1 );
        add_action( 'woocommerce_single_product_summary', array( $this, 'single_product_info_header_start' ), 5 );
        add_action( 'woocommerce_single_product_summary', array( $this, 'single_product_info_categories' ), 10 );
        add_action( 'woocommerce_single_product_summary', array( $this, 'custom_template_single_title' ), 12 );
        add_action( 'woocommerce_single_product_summary', array( $this, 'single_product_info_rating' ), 13 );
        add_action( 'woocommerce_single_product_summary', array( $this, 'single_product_info_price' ), 14 );

        add_action( 'woocommerce_single_product_summary', array( $this, 'single_product_info_header_finish' ), 15 );
        add_action( 'woocommerce_review_before', array( $this, 'single_product_review_display_gravatar' ), 10 );

        /*-- rewiew --*/
        remove_action( 'woocommerce_review_before_comment_meta', 'woocommerce_review_display_rating', 10 );
        remove_action( 'woocommerce_review_meta', 'woocommerce_review_display_meta', 10 );
        add_action( 'woocommerce_review_meta', array( $this, 'custom_wc_review_display_meta' ), 10, 1 );
        add_filter( 'woocommerce_product_review_comment_form_args', array( $this, 'custom_wc_review_form_defaults' ) );
		/* single */

		/* widgets */
		add_action( 'woocommerce_before_mini_cart', array( $this, 'minicart_wrapper_open' ) );
		add_action( 'woocommerce_after_mini_cart', array( $this, 'minicart_wrapper_close' ) );
		add_action( 'wp_ajax_woocommerce_remove_from_cart', array( $this, 'ajax_remove_from_cart' ), 1000 );
		add_action( 'wp_ajax_nopriv_woocommerce_remove_from_cart', array( $this, 'ajax_remove_from_cart' ), 1000 );
		add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'header_add_to_cart_fragment' ) );

		add_filter( 'woocommerce_get_price_html', array( $this, 'product_widget_price_wrapper' ) );
		add_filter( 'woocommerce_cart_item_price', array( $this, 'product_widget_price_wrapper' ) );
		/* \widgets */
		$this->set_img_dims();
		add_filter( 'woocommerce_breadcrumb_defaults', array( $this, 'change_breadcrumb_delimiter' ) );
	}

	public function gridlist_init (){
		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
		add_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 40 );
		add_action( 'woocommerce_before_shop_loop', array( $this, 'remove_excess_gridlist_actions' ), 40 );
		add_action( 'wp', array( $this, 'remove_excess_gridlist_actions' ), 30 );
	}

	public function set_img_dims (){
		global $pagenow;
	 	if ( ! isset( $_GET['activated'] ) || $pagenow != 'themes.php' ) {
			return;
		}
		if ( isset( $this->args['shop_catalog_image_size'] ) && !empty( $this->args['shop_catalog_image_size'] ) ){
			update_option( 'shop_catalog_image_size', $this->args['shop_catalog_image_size'] );		
		}
		if ( isset( $this->args['shop_single_image_size'] ) && !empty( $this->args['shop_single_image_size'] ) ){
			update_option( 'shop_single_image_size', $this->args['shop_single_image_size'] );		
		}
		if ( isset( $this->args['shop_thumbnail_image_size'] ) && !empty( $this->args['shop_thumbnail_image_size'] ) ){
			update_option( 'shop_thumbnail_image_size', $this->args['shop_thumbnail_image_size'] );		
		}
	}

	public function divider (){
		echo "<hr />";
	}

	public function custom_woocommerce_layered_nav_set_color_filter ($span, $count, $term) {
	    $taxonomy = $term->taxonomy;
	    if ( strpos(strtolower($taxonomy), 'color' ) != false) {
            $span = str_replace('<span class="count">', '<span class="post_count"><span class="color-box" style="background:'.esc_attr( strtolower($term->slug) ).';"></span>', $span);
        } else {
            $span = str_replace('<span class="count">', '<span class="post_count">', $span);
        }
		return $span;
	}

    public function custom_woocommerce_layered_nav_fix_color_filter ($term_html, $term, $link, $count) {

        $term_html = str_replace('</a>', '', $term_html);
        $term_html .= '</a>';
        return $term_html;
    }

	public function cws_loop_shop_column(){
		global $cws_theme_funcs;
		if ($cws_theme_funcs){
			$woo_columns = $cws_theme_funcs->cws_get_option('woo_columns');			
		} else {
			$woo_columns = 3;
		}
		return (int)$woo_columns;
	}

	static function get_wc_placeholder_img_src (){
		$image_link = wc_placeholder_img_src();
		$has_ext = preg_match( "#\.[^(\.)]*$#", $image_link, $matches );
		if ( $has_ext ){
			$ext = $has_ext ? $matches[0] : "";
			$wc_placeholder_img_name = "wc_placeholder_img";
			$wp_upload_dir = wp_upload_dir();
			$wp_upload_base_dir = isset( $wp_upload_dir['basedir'] ) ? $wp_upload_dir['basedir'] : "";
			$woo_upload_dir = trailingslashit( $wp_upload_base_dir ) . "woocommerce_uploads";
			$wc_placeholder_img_src = trailingslashit( $woo_upload_dir ) . "{$wc_placeholder_img_name}{$ext}";
			if ( !file_exists( $wc_placeholder_img_src ) ){
				$image_editor = wp_get_image_editor( $image_link );
				if ( ! is_wp_error( $image_editor ) ) {
					$image_editor->save( $wc_placeholder_img_src );
					return $wc_placeholder_img_src;
				}
			}
			else{
				return $wc_placeholder_img_src;
			}
		}
		return false;
	}

	public function change_breadcrumb_delimiter( $defaults ) {
		$defaults['delimiter'] = ' >> ';
		return $defaults;
	}

	public function custom_template_single_title () {
        the_title( '<h2 class="product_title entry-title">', '</h2>' );
    }

	/**/
	/* STYLES */
	/**/

	public function enqueue_style() {
			$is_rtl = is_rtl();
			if ( class_exists('WC_List_Grid') ) {		
				wp_register_style( 'woocommerce-gridlist', POLITIX_URI . '/woocommerce/css/woocommerce_gridlist.css', array( 'grid-list-layout', 'grid-list-button' ) );
				wp_enqueue_style( 'woocommerce-gridlist' );
			}
			if ( $is_rtl ){
				wp_register_style( 'woocommerce-rtl', POLITIX_URI . '/woocommerce/css/woocommerce-rtl.css');
				if ( class_exists( 'woocommerce' ) ) {
					wp_enqueue_style( 'woocommerce-rtl' );
				}
				if ( class_exists('WC_List_Grid') ) {		
					wp_register_style( 'woocommerce-gridlist-rtl', POLITIX_URI . '/woocommerce/css/woocommerce_gridlist-rtl.css', array( 'grid-list-layout', 'grid-list-button', 'woocommerce_gridlist' ) );
					wp_enqueue_style( 'woocommerce-gridlist-rtl' );
				}				
			}
			$this->custom_styles();
	}
	public function custom_styles(){
		$product_thumb_dims = get_option( 'shop_single_image_size' );
		$product_thumb_width = isset( $product_thumb_dims['width'] ) ? $product_thumb_dims['width'] : $this->args['shop_single_image_size']['width'];

		ob_start();
		echo "
			.woo_product_post_media.post_single_post_media > .post_media_wrapper{
				width: {$product_thumb_width}px;
			}
		";

		if ( isset( $this->args['shop_thumbnail_image_spacings'] ) && !empty( $this->args['shop_thumbnail_image_spacings'] ) ){
			echo ".woo_product_post_thumbnail.post_single_post_thumbnail{";
			foreach ( $this->args['shop_thumbnail_image_spacings'] as $key => $value) {
				echo "padding-{$key}: {$value}px;";		
			}
			echo "}";
			echo ".woo_product_post_media.post_single_post_media .thumbnails{";
			foreach ( $this->args['shop_thumbnail_image_spacings'] as $key => $value) {
				echo "margin-{$key}: -{$value}px;";		
			}
			echo "}";
		}
		if ( isset( $this->args['shop_single_image_spacings'] ) && !empty( $this->args['shop_single_image_spacings'] ) ){
			echo ".woo_product_post_media_wrapper.post_single_post_media_wrapper > .pic:not(:only-child){";
			foreach ( $this->args['shop_single_image_spacings'] as $key => $value) {
				echo "margin-{$key}: {$value}px;";		
			}
			echo "}";
		}
		$custom_styles = ob_get_clean();
		if ( !empty( $custom_styles ) ){
			wp_add_inline_style( 'woocommerce', $custom_styles );
		}	
	}
	public function body_font_styles (){
		global $cws_theme_funcs;
		if($cws_theme_funcs){
			$font_options = $cws_theme_funcs->cws_get_option('body-font');
		}else{
			$font_options = array(
			    'font-family' => 'Lato',
			    'font-weight' => array('regular','italic','700','700italic'),
			    'font-sub' => array('latin'),
			    'font-type' => '',
			    'color' => '#747474',
			    'font-size' => '16px',
			    'line-height' => '35px',
			);
		}
		

		$font_family = $font_options['font-family'];
		
		if ( class_exists( 'woocommerce' ) ) {
			ob_start();
			if ( !empty( $font_family ) ){
				echo "
				.tipr_content
				{
					font-family: $font_family;
				}";
			}

			$styles = ob_get_clean();
			echo sprintf("%s", $styles);
		}
	}
	public function header_font_styles (){
		global $cws_theme_funcs;
		if($cws_theme_funcs){
			$font_options = $cws_theme_funcs->cws_get_option( 'header-font' );
		}else{
			$font_options = array(
    			'font-family' => 'Montserrat',
			    'font-weight' => array('300','regular','500','600','700'),
			    'font-sub' => array('latin'),
			    'font-type' => '',
			    'color' => '#000000',
			    'font-size' => '27px',
			    'line-height' => '36px',
			);	
		}
		
		$font_family = $font_options['font-family'];
		$font_size = $font_options['font-size'];
		$line_height = $font_options['line-height'];
		$font_color = $font_options['color'];

		if ( class_exists( 'woocommerce' ) ) {
			ob_start();
			if ( !empty( $font_size ) ){
				echo "";
			}
			if ( !empty( $font_family ) ){
				echo "
				ul.products.list li.product .woo_product_post_title.posts_grid_post_title
				{
				font-family: $font_family;
				}";
			}
			$styles = ob_get_clean();
			echo sprintf("%s", $styles);
		}
	}
	/**/
	/* \STYLES */
	/**/

	/**/
	/* SCRIPTS */
	/**/
	public function enqueue_script() {
		wp_register_script( 'politix-woocommerce', POLITIX_URI . '/woocommerce/js/woocommerce.js', array(), '', 'footer' );
		if ( class_exists( 'woocommerce' ) ) {
			wp_enqueue_script( 'politix-woocommerce' );
		}
	}
	/**/
	/* SCRIPTS */
	/**/

	/**/
	/* LOOP */
	/**/
	public function loop_products_per_page() {
		global $cws_theme_funcs;
		if ($cws_theme_funcs){
			return (int) $cws_theme_funcs->cws_get_option( 'woo_num_products' );
		} else {
			return 9;
		}		
	}
    public function custom_replace_sale_text( $html ) {
        return str_replace( esc_html__( 'Sale!', 'politix' ), esc_html__( 'Sale', 'politix' ), $html );
    }
	public function after_shop_loop_item_price_wrapper_open (){
		echo "<div class='woo_product_post_price_wrapper'>";
	}

	public function after_shop_loop_item_price_wrapper_close (){
		echo "</div>";
	}
	public function shop_loop_item_content_wrapper_open (){
		echo "<div class='politix_shop_loop_item_content_wrapper'>";
	}
	public function shop_loop_item_content_wrapper_close (){
		echo "</div>";
	}
    public function shop_loop_item_info_wrapper_open (){
        echo "<div class='woo_product_post_info'>";
    }
    public function shop_loop_item_info_wrapper_close (){
        echo "</div>";
    }
	public function remove_excess_gridlist_actions (){
		$actions = array(
			'woocommerce_after_shop_loop_item'	=> array( 'gridlist_buttonwrap_open', 'gridlist_buttonwrap_close', 'gridlist_hr' )
		);
		global $wp_filter;
		foreach ( $actions as $hook => $functions ) {
			if ( array_key_exists( $hook, $wp_filter ) ){
				$reg_functions = &$wp_filter[$hook];
				foreach ( $reg_functions as $reg_id => $reg_atts ){
					foreach ( $reg_atts as $reg_method_id => $reg_method_atts) {
						$reg_method = $reg_method_atts['function'];
						$reg_method_name = "";
						if ( is_array( $reg_method ) && isset( $reg_method[1] ) ){
							$reg_method_name = $reg_method[1];
						}else{
							$reg_method_name = $reg_method;
						}
						if ( in_array( $reg_method_name, $functions ) ){
							if ( empty( $wp_filter[$hook][$reg_id] ) ) unset( $wp_filter[$hook][$reg_id] );
							break 1;
						}
					}
				}
			}
		}
	}

	public function custom_output_content_wrapper() {
        echo '<div id="primary" class="content-area">';
    }
    public function custom_output_content_wrapper_end() {
        echo '</div>';
    }
	/**/
	/* \LOOP */
	/**/

	/**/
	/* SINGLE */
	/**/
	public function single_product_divider_before_upsells (){
		global $product;
		$posts_per_page = get_option( 'posts_per_page' );
		$upsells = $product->get_upsell_ids( $posts_per_page );
		echo sizeof( $upsells ) ? "<hr />" : "";
	}
	public function single_product_divider_before_related (){
		global $product;
		if ( !isset( $product ) ) return false;
		$posts_per_page = get_option( 'posts_per_page' );
		if(function_exists('wc_get_related_products')){
			$related = wc_get_related_products( $posts_per_page );
		}else{
			$related = $product->get_related( $posts_per_page );
		}
		
		echo sizeof( $related ) ? "<hr />" : "";
	}
	public function related_products_args( $args ) {
		global $product;
		global $cws_theme_funcs;
		if($cws_theme_funcs){
			$ppp = $cws_theme_funcs->cws_get_option( 'woo_related_num_products' );
			$columns = $cws_theme_funcs->cws_get_option( 'woo_related_columns' );
		}else{
			$ppp = 10;
			$columns = 3;
		}

		$args['posts_per_page'] = $ppp;
		$args['columns'] = $columns;
		return $args;
	}

	public function single_product_info_header_start () {
	    echo '<div class="single_product_header">';
    }
    public function single_product_info_header_finish () {
        echo '</div>';
    }

    public function single_product_info_price () {
        global $product;

        echo "<div class='single_product_price'>";
            echo sprintf( '%s', $product->get_price_html() );
        echo "</div>";
    }

    public function single_product_info_banner () {
        global $product;

        ob_start();
        woocommerce_show_product_loop_sale_flash();
        $sale = ob_get_clean();

        $featured = $product->is_featured() ? esc_html__('Hot', 'politix') : '';
        $free = ( $product->get_price() === '' || $product->get_price() == 0 ) ? esc_html__('Free', 'politix') : '';

        if ( !empty($sale) || !empty($featured) || !empty($free) ) {
            echo "<div class='woo_banner_wrapper'>";
                if ( !empty($sale) ) {
                    echo "<div class='woo_banner sale_banner'>";
                        echo sprintf("<div class='woo_banner_text'>%s</div>", $sale);
                    echo "</div>";
                }
                if ( !empty($featured) ) {
                    echo "<div class='woo_banner featured_banner'>";
                        echo sprintf("<div class='woo_banner_text'>%s</div>", $featured);
                    echo "</div>";
                }
                if ( !empty($free) ) {
                    echo "<div class='woo_banner free_banner'>";
                        echo sprintf("<div class='woo_banner_text'>%s</div>", $free);
                    echo "</div>";
                }
            echo "</div>";
        }
    }

    public function single_product_info_rating () {
        global $product;

        if ( ! wc_review_ratings_enabled() ) {
            return;
        }

        $rating_count = $product->get_rating_count();
        $average      = $product->get_average_rating();

        if ( $rating_count > 0 ) {

            echo '<div class="woocommerce-product-rating">';
                echo wc_get_rating_html( $average, $rating_count );
                echo '<div class="woocommerce-product-rating_info">';
                    echo esc_html($average) . ' (' . esc_html($rating_count) . ($rating_count == 1 ? __('rating',
                            'politix') : __('ratings', 'politix') ) . __(' by customers', 'politix') . ')';
                echo '</div>';
            echo '</div>';

        }
    }

    public function single_product_info_categories () {
        global $product;

        echo '<div class="single_product_categories">';
            do_action( 'woocommerce_product_meta_start' );
            echo wc_get_product_category_list( $product->get_id(), ', ', '<span class="posted_in">' . _n( '', '', count( $product->get_category_ids() ), 'politix' ) . ' ', '</span>' );
            do_action( 'woocommerce_product_meta_end' );
        echo '</div>';
    }

    public function single_product_review_display_gravatar ($comment) {
        echo get_avatar( $comment, apply_filters( 'woocommerce_review_gravatar_size', '80' ), '' );
    }

    public function custom_wc_review_display_meta($comment) {
        $verified = wc_review_is_from_verified_owner( $comment->comment_ID );

        if ( '0' === $comment->comment_approved ) {
            echo '<div class="comment-header">';
                echo '<em class="woocommerce-review__awaiting-approval">';
                    echo esc_html_e( 'Your review is awaiting approval', 'politix' );
                echo '</em>';
            echo '</div>';
        } else {
            echo '<div class="comment-header">';
                echo '<div class="woocommerce-review__author">';
                    echo comment_author();
                    if ( 'yes' === get_option( 'woocommerce_review_rating_verification_label' ) && $verified ) {
                        echo '<em class="woocommerce-review__verified verified">(' . esc_attr__( 'verified owner', 'politix' ) . ')</em> ';
                    }
                echo '</div>';

                echo '<div class="comment-info">';
                    echo '<time class="woocommerce-review__published-date" datetime="' . esc_attr( get_comment_date( 'c' ) ) . '">';
                        echo esc_html( get_comment_date( 'F j, Y' ) . __(' at ', 'politix') . get_comment_date( 'g:i a' ) );
                    echo '</time>';
                    woocommerce_review_display_rating();
                echo '</div>';
            echo '</div>';
        }
    }

    function custom_wc_review_form_defaults($defaults) {
        $commenter = wp_get_current_commenter();
        $req = get_option( 'require_name_email' );
        $html_req = ( $req ? " required='required'" : '' );

        $defaults['fields']['author'] = '<p class="comment-form-author">' .
            '<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30" maxlength="245" placeholder="' . esc_attr__('Name *', 'politix') . '"' . $html_req . ' /></p>';
        $defaults['fields']['email'] = '<p class="comment-form-email">' .
            '<input id="email" name="email" type="text" value="'
            . esc_attr(  $commenter['comment_author_email'] ) . '" size="30" maxlength="100" aria-describedby="email-notes" placeholder="' . esc_attr__('Email *', 'politix') . '"' . $html_req  . ' /></p>';

        $defaults['comment_field'] = '<p class="comment-form-rating"><label for="rating">' . esc_html__( 'Your rating:', 'politix' ) . '</label><select name="rating" id="rating" required>
						<option value="">' . esc_html__( 'Rate&hellip;', 'politix' ) . '</option>
						<option value="5">' . esc_html__( 'Perfect', 'politix' ) . '</option>
						<option value="4">' . esc_html__( 'Good', 'politix' ) . '</option>
						<option value="3">' . esc_html__( 'Average', 'politix' ) . '</option>
						<option value="2">' . esc_html__( 'Not that bad', 'politix' ) . '</option>
						<option value="1">' . esc_html__( 'Very poor', 'politix' ) . '</option>
					</select></p><p class="comment-form-comment"><textarea id="comment" name="comment" cols="45" rows="1" aria-required="true" placeholder="' . esc_attr__('Your review', 'politix') . '"></textarea></p>';

        return $defaults;
    }
	/**/
	/* \SINGLE */
	/**/

	/**/
	/* WIDGETS */
	/**/
	public function ajax_remove_from_cart() {
		global $woocommerce;

		$woocommerce->cart->set_quantity( $_POST['remove_item'], 0 );

		$ver = explode( '.', WC_VERSION );

		if ( $ver[1] == 1 && $ver[2] >= 2 ) :
			$wc_ajax = new WC_AJAX();
			$wc_ajax->get_refreshed_fragments();
		else :
			woocommerce_get_refreshed_fragments();
		endif;

		die();
	}
	public function header_add_to_cart_fragment( $fragments ) {
		global $woocommerce;
		ob_start();
			?>
				<span class='woo_mini_count'><?php echo ( (WC()->cart->cart_contents_count > 0) ? esc_html( WC()->cart->cart_contents_count ) : '' ) ?></span>
			<?php
			$fragments['.woo_mini_count'] = ob_get_clean();

			ob_start();
			woocommerce_mini_cart();
			$fragments['.cws_woo_minicart_wrapper'] = ob_get_clean();

			return $fragments;
	}
	public function minicart_wrapper_open (){
		echo "<div class='woo_mini_cart'>";
	}
	public function minicart_wrapper_close (){
		echo "</div>";
	}
	public function product_widget_price_wrapper( $price ){
	    $price = !empty($price) ? '<div class="price">' . $price . '</div>' : $price;
	    return $price;
    }
	/**/
	/* \WIDGETS */
	/**/
}

/**/
/* Config and enable extension */
/**/
$politix_woo_args = array(
	'shop_catalog_image_size'		=> array(
		'width'	=> 1000,
		'height'=> 1000,
		'crop'	=> 1
	),
	'shop_single_image_size'		=> array(
		'width'	=> 600,
		'height'=> 600,
		'crop'	=> 1
	),
	'shop_thumbnail_image_size'		=> array(
		'width'	=> 116,
		'height'=> 116,
		'crop'	=> 1
	),
	'shop_thumbnail_image_spacings' => array(
		'left'	=> 6,
		'right'	=> 5,
		'top'	=> 11
	),
	'shop_single_image_spacings'	 => array(
		'bottom'=> 10
	),
);
global $politix_woo_ext;
$politix_woo_ext = new Politix_WooExt ( $politix_woo_args );

/**/
/* \Config and enable extension */
/**/

/**/
/* Overriden functions */
/**/
function woocommerce_template_loop_product_title(){
	$title = get_the_title();
	$permalink = get_the_permalink();
	echo !empty( $title ) ? "<h3 class='post_title woo_product_post_title posts_grid_post_title'><a href='"
        .esc_url($permalink)."'>$title</a></h3>" : "";
}
function woocommerce_template_loop_product_thumbnail (){
	global $product;
	$pid = get_the_id();
	$post_thumb_exists = has_post_thumbnail( $pid );
	$permalink = esc_url( get_the_permalink() );
	$img_url = "";
	if ( $post_thumb_exists ){
		$img_obj = wp_get_attachment_image_src( get_post_thumbnail_id( $pid ), 'full' );
		$img_url = isset( $img_obj[0] ) ? esc_url( $img_obj[0] ) : '';
	}
	else{
		$wc_placeholder_img_src = Politix_WooExt::get_wc_placeholder_img_src();
		$img_url = $wc_placeholder_img_src ? $wc_placeholder_img_src : $img_url;
	}
	if ( empty( $img_url ) ) return false;
	$lightbox_en = get_option( 'woocommerce_enable_lightbox' ) == 'yes' ? true : false;	
	ob_start();
	if ( $lightbox_en ) {	
	echo "<div class='links'>";
		if($post_thumb_exists){
			echo "<a href='".esc_url($img_url)."' data-mode='top' data-tip='Quick view' class='tip fancy fa 
            flaticon-search-icon-politix'></a>";
		}
		echo "<a href='".esc_url($permalink)."' data-mode='top' data-tip='Product page' class='tip fancy fa 
        flaticon-right-arrow-icon-politix'></a>";
	echo "</div>";
	}
	$lightbox = ob_get_clean();	
	$thumb_dims = get_option( 'shop_catalog_image_size' );
    $retina_thumb_url = '';

    if (function_exists('cws_thumb')) {
        $thumb_obj = cws_thumb( get_post_thumbnail_id( $pid ), $thumb_dims );
    } else {
        $thumb_obj = array(
            0 => wp_get_attachment_image_url(get_post_thumbnail_id(), array($thumb_dims['width'], $thumb_dims['height'])),
            1 => '',
            2 => '',
            3 => '',
        );
    }

	$thumb_url = isset( $thumb_obj[0] ) ? esc_url( $thumb_obj[0] ) : "";
	$thumb_obj[0] = empty($thumb_obj[0]) ? woocommerce_placeholder_img_src() : $thumb_obj[0];

	echo "<div class='post_media woo_product_post_media posts_grid_post_media'>";
        ob_start();
        woocommerce_show_product_loop_sale_flash();
        $sale = ob_get_clean();
        $featured = $product->is_featured() ? esc_html__('Hot', 'politix') : '';
        $free = ( $product->get_price() === '' || $product->get_price() == 0 ) ? esc_html__('Free', 'politix') : '';

        if ( !empty($sale) || !empty($featured)  || !empty($free) ) {
            echo "<div class='woo_banner_wrapper'>";
            if ( !empty($sale) ) {
                echo "<div class='woo_banner sale_banner'>";
                    echo sprintf("<div class='woo_banner_text'>%s</div>", $sale);
                echo "</div>";
            }
            if ( !empty($featured) ) {
                echo "<div class='woo_banner featured_banner'>";
                echo sprintf("<div class='woo_banner_text'>%s</div>", $featured);
                echo "</div>";
            }
            if ( !empty($free) ) {
                echo "<div class='woo_banner free_banner'>";
                    echo sprintf("<div class='woo_banner_text'>%s</div>", $free);
                echo "</div>";
            }
            echo "</div>";
        }
		echo "<div class='pic'>";
			echo "<a href='".esc_url($permalink)."'>";
			$thumb_path_hdpi = !empty($thumb_obj[3]) ? " src='". esc_url( $thumb_obj[0] ) ."' data-at2x='" . esc_attr( $thumb_obj[3] ) ."'" : " src='". esc_url( $thumb_obj[0] ) . "' data-no-retina";
			echo "<img $thumb_path_hdpi alt />";
			echo "</a>";
			echo sprintf("%s", $lightbox);
		echo "</div>";
		echo "<div class='post_media_buttons'>";
            woocommerce_template_loop_add_to_cart();
        echo "</div>";
	echo '</div>';
}
function woocommerce_template_loop_price() {
    global $product;
    if ($price_html = $product->get_price_html()) {
        echo sprintf('%s', $price_html);
    }
}
/**/
/* \Overriden functions */
/**/

// Reposition WooCommerce breadcrumb
function politix_remove_woo_breadcrumb() {
	remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
}
add_action('woocommerce_before_main_content', 'politix_remove_woo_breadcrumb'
);

?>