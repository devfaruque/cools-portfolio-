<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 8.6.0
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

//CWS ADDON
global $cws_theme_funcs;
$page_class = "page-content";
$woo_sb_layout = $cws_theme_funcs ? sanitize_html_class( $cws_theme_funcs->cws_get_option( 'woo_sb_layout' ) ) : 'none';
$woo_sb_exists = in_array( $woo_sb_layout, array( "left", "right" ) );
ob_start();

/**
* Hook: woocommerce_sidebar.
*
* @hooked woocommerce_get_sidebar - 10
*/
do_action( 'woocommerce_sidebar' );
$woo_sb = ob_get_clean();
$page_class .= $woo_sb_exists ? " single-sidebar " : "";
$page_class .= ' col-3';
$page_class .= $cws_theme_funcs ? ' col-'.$cws_theme_funcs->cws_get_option( 'woo_columns' ) : '';

	if(!empty($woo_sb)){ 
		echo '<i class="sidebar-tablet-trigger"></i>';
	}

	echo "<div " . ( !empty( $page_class ) ? " class='".$page_class."'" : "" ) . ">";
		echo "<div class='container'>";
			if ($woo_sb_exists) {
				if( !empty($woo_sb) && $woo_sb_layout != 'none' ){
					echo "<aside class='sb-". $woo_sb_layout ."'>". $woo_sb ."</aside>";
				}
			}
			echo '<main>';
			//-----CWS ADDON

					/**
					* Hook: woocommerce_before_main_content.
					*
					* @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
					* @hooked woocommerce_breadcrumb - 20
					* @hooked WC_Structured_Data::generate_website_data() - 30
					*/
					do_action( 'woocommerce_before_main_content' );

					/**
					 * Hook: woocommerce_shop_loop_header.
					 *
					 * @since 8.6.0
					 *
					 * @hooked woocommerce_product_taxonomy_archive_header - 10
					 */
					do_action( 'woocommerce_shop_loop_header' );

					if ( woocommerce_product_loop() ) {

						/**
						 * Hook: woocommerce_before_shop_loop.
						 *
						 * @hooked wc_print_notices - 10
						 * @hooked woocommerce_result_count - 20
						 * @hooked woocommerce_catalog_ordering - 30
						 */
						echo ('<div class="woo_panel">');
							do_action( 'woocommerce_before_shop_loop' );
						echo ('</div>');


						woocommerce_product_loop_start();

						if ( wc_get_loop_prop( 'total' ) ) {
							while ( have_posts() ) {
								the_post();

								/**
								 /* Hook: woocommerce_shop_loop.
								 /*
								 /* @hooked WC_Structured_Data::generate_product_data() - 10
								 */
								 
								do_action( 'woocommerce_shop_loop' );

								wc_get_template_part( 'content', 'product' );
							}
						}

						woocommerce_product_loop_end();

						/**
						 * Hook: woocommerce_after_shop_loop.
						 *
						 * @hooked woocommerce_pagination - 10
						 */
						do_action( 'woocommerce_after_shop_loop' );

					} else {
						/**
						 * Hook: woocommerce_no_products_found.
						 *
						 * @hooked wc_no_products_found - 10
						 */
						do_action( 'woocommerce_no_products_found' );
					}

					/**
					 * Hook: woocommerce_after_main_content.
					 *
					 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
					 */
					do_action( 'woocommerce_after_main_content' );

			//CWS ADDON
echo '</main>';
		echo "</div>";
	echo "</div>";
	//-----CWS ADDON

get_footer( 'shop' );
