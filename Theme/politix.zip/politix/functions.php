<?php

defined( 'ABSPATH' ) or exit;

# CONSTANTS
define('POLITIX_URI', get_template_directory_uri());
define('POLITIX_THEME_DIR', get_template_directory());
defined('POLITIX_FIRST_COLOR') or define('POLITIX_FIRST_COLOR', '#ed4e40');
defined('POLITIX_SECOND_COLOR') or define('POLITIX_SECOND_COLOR', '#00395e');
# \CONSTANTS

# TEXT DOMAIN
load_theme_textdomain( 'politix' , get_template_directory() .'/languages' );
# \TEXT DOMAIN

global $cws_theme_funcs;
global $politix_theme_standard;

//Check if plugin active
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
require_once( POLITIX_THEME_DIR . '/core/cws_blog.php');

// Init theme core function
require_once(get_template_directory() . '/core/functions-theme-class.php');
if (function_exists('cws_core_cwsfw_startFramework') && get_option('politix')){
	$cws_theme_funcs = new Politix_Funcs();
} else {
	require_once(get_template_directory() . '/core/cws_default.php');
	$politix_theme_standard = new Politix_Funcs_default();
}

//Functions
add_action( 'init', 'cws_setup_admin_styles' );
function cws_setup_admin_styles() {
	// Admin`s editor styles
	wp_enqueue_style( 'politix-editor-additional', get_template_directory_uri() . '/core/css/editor-additional.css',
        array(), '1.0.0', 'all' );
}

function cws_logo_extra_info() {
	global $cws_theme_funcs;

	$logo_box = $cws_theme_funcs->cws_get_meta_option( 'logo_box' );
	extract($logo_box, EXTR_PREFIX_ALL, 'logo_box');

	$extra_info = '';

	if( !empty($logo_box_extra_title) || !empty($logo_box_extra_link) ){
		$extra_info .= '<div class="logo_extra_info">';
			if( !empty($logo_box_extra_title) ){
				$extra_info .= '<p>'.wp_kses( $logo_box_extra_title, array(
					'a' 	=> array(
						'href'	=> true,
						'title' => true
					),
					'span' 	=> true,
					'p' 	=> true,
					'i' 	=> array(
						'class'	=> true
					),
					'br' 	=> true,
					'center' => true,
					'em' 	=> true,
					'strong'=> true,
				)).'</p>';
			}
			if( !empty($logo_box_extra_link) ){
				$extra_info .= '<i class="'.esc_attr($logo_box_extra_icon).'"></i>';
				if( $logo_box_link_type != 'link' ){
					$extra_info .= '<a href="'.esc_url($logo_box_link_type . $logo_box_extra_link).'">'.esc_html($logo_box_extra_link).'</a>';
				} else {
					$extra_info .= '<a href="'.esc_url($logo_box_extra_link).'">'.esc_html($logo_box_extra_link).'</a>';
				}
			}
		$extra_info .= '</div>';
	}

	return $extra_info;
}

function cws_vc_animations_disable() {
	wp_dequeue_style('animate');
	wp_deregister_style('animate');
}

function cws_custom_background() {
    ob_start();

    _custom_background_cb(); // Default handler

    $style = ob_get_clean();

    echo sprintf("%s", $style);
}

if(!function_exists('cws_pagination')){
	function cws_page_links(){
		$args = array(
			'before'		   => '',
			'after'			=> '',
			'link_before'	  => '<span>',
			'link_after'	   => '</span>',
			'next_or_number'   => 'number',
			'nextpagelink'	 =>  esc_html__("Next Page",'politix'),
			'previouspagelink' => esc_html__("Previous Page",'politix'),
			'pagelink'		 => '%',
			'echo'			 => 0
		);
		$pagination = wp_link_pages( $args );
		echo !empty( $pagination ) ? "<div class='pagination'><div class='page_links'>$pagination</div></div>" : '';
	}
}

if(!function_exists('cws_pagination')){
	function cws_pagination ( $paged=1, $max_paged=1, $dynamic = true ){
		$is_rtl = is_rtl();

		$pagenum_link = html_entity_decode( get_pagenum_link() );
		$query_args   = array();
		$url_parts	= explode( '?', $pagenum_link );

		if ( isset( $url_parts[1] ) ) {
			wp_parse_str( $url_parts[1], $query_args );
		}

		$permalink_structure = get_option('permalink_structure');

		$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
		$pagenum_link = $permalink_structure ? trailingslashit( $pagenum_link ) . '%_%' : trailingslashit( $pagenum_link ) . '?%_%';
		$pagenum_link = add_query_arg( $query_args, $pagenum_link );

		$format  = $permalink_structure && preg_match( '#^/*index.php#', $permalink_structure ) && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
		$format .= $permalink_structure ? user_trailingslashit( 'page/%#%', 'paged' ) : 'paged=%#%';
		$classes = '';
		$classes .= $dynamic ? ' dynamic' : '';
		?>

		<div class="pagination<?php echo sprintf("%s", $classes); ?>">
			<div class='page_links'>
			<?php
			$pagination_args = array( 'base' => $pagenum_link,
				'format' => $format,
				'current' => $paged,
				'total' => $max_paged,
				"prev_text" => "<i class='" . ( $is_rtl ? "rtl" : "" ) . "'></i>",
				"next_text" => "<i class='" . ( $is_rtl ? "rtl" : "" ) . "'></i>",
				"link_before" => '',
				"link_after" => '',
				"before" => '',
				"after" => '',
				"mid_size" => 2,
			);
			$pagination = paginate_links($pagination_args);
			echo sprintf("%s", $pagination);
			?>
			</div>
		</div>
		<?php

	}
}

if(!function_exists('cws_loader_html')){
	function cws_loader_html ( $args = array() ){
		extract( wp_parse_args( $args, array(
			'holder_id'		=> '',
			'holder_class' 	=> '',
			'loader_id'		=> '',
			'loader_class'	=> ''
		)));
		$holder_class 	.= " cws-loader-holder";
		$loader_class 	.= " cws-loader";
		$holder_id		= esc_attr( $holder_id );
		$holder_class 	= esc_attr( trim( $holder_class ) );
		$loader_id		= esc_attr( $loader_id );
		$loader_class 	= esc_attr( trim( $loader_class ) );
		echo "<div " . ( !empty( $holder_id ) ? " id='$holder_id'" : "" ) . " class='$holder_class'>";
			echo "<div " . ( !empty( $loader_id ) ? " id='$loader_id'" : "" ) . " class='$loader_class'>";
				?>
				<svg width='104px' height='104px' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid" class="uil-default"><rect x="0" y="0" width="100" height="100" fill="none" class="bk"></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(0 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(30 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.08333333333333333s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(60 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.16666666666666666s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(90 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.25s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(120 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.3333333333333333s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(150 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.4166666666666667s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(180 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.5s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(210 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.5833333333333334s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(240 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.6666666666666666s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(270 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.75s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(300 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.8333333333333334s' repeatCount='indefinite'/></rect><rect  x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(330 50 50) translate(0 -30)'>  <animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.9166666666666666s' repeatCount='indefinite'/></rect></svg>
				<?php
			echo "</div>";
		echo "</div>";
	}	
}

//Add inline styles to enqueue
if(!function_exists('Cws_shortcode_css')){
    function Cws_shortcode_css() {
        return Cws_shortcode_css::instance();
    }
}

if ( !class_exists( "Cws_shortcode_css" ) ){
    class Cws_shortcode_css{
        public $settings;
        protected static $instance = null;

        public static function instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }    
        public function enqueue_cws_css( $style ) {
            if(!empty($style)){
                wp_register_style( 'politix-footer-styles', false);
                wp_enqueue_style( 'politix-footer-styles' );
                wp_add_inline_style( 'politix-footer-styles', $style );
            }
        }
    }
}

/* FA ICONS */
function cws_get_all_fa_icons() {
	global $wp_filesystem;
	if( empty( $wp_filesystem ) ) {
		require_once( ABSPATH .'/wp-admin/includes/file.php' );
		WP_Filesystem();
	}
	$file = get_template_directory() . '/fonts/font-awesome/font-awesome.css';
	$fa_content = '';
	if ( $wp_filesystem && $wp_filesystem->exists($file) ) {
		$fa_content = $wp_filesystem->get_contents($file);
		if ( preg_match_all( "/fa-((\w+|-?)+):before/", $fa_content, $matches, PREG_PATTERN_ORDER ) ) {
			return $matches[1];
		}
	}
}

/* FL ICONS */
function cws_get_all_flaticon_icons() {
	$cwsfi = get_option('cwsfi');
	if (!empty($cwsfi) && isset($cwsfi['entries'])) {
		return $cwsfi['entries'];
	} else {
		global $wp_filesystem;
		if( empty( $wp_filesystem ) ) {
			require_once( ABSPATH .'/wp-admin/includes/file.php' );
			WP_Filesystem();
		}
		$file = get_template_directory() . '/fonts/flaticon/flaticon.css';
		$fi_content = '';
		$out = '';
		if ( $wp_filesystem && $wp_filesystem->exists($file) ) {
			$fi_content = $wp_filesystem->get_contents($file);
			if ( preg_match_all( "/flaticon-((\w+|-?)+):before/", $fi_content, $matches, PREG_PATTERN_ORDER ) ){
				return $matches[1];
			}
		}
	}
}

function cws_time_elapsed_string($ptime){
    $etime = time() - $ptime;

    if ($etime < 1)
    {
        return esc_html__('0 seconds', 'politix');
    }

    $a = array( 365 * 24 * 60 * 60  =>  esc_html__('year', 'politix'),
                 30 * 24 * 60 * 60  =>  esc_html__('month', 'politix'),
                      24 * 60 * 60  =>  esc_html__('day', 'politix'),
                           60 * 60  =>  esc_html__('hour', 'politix'),
                                60  =>  esc_html__('minute', 'politix'),
                                 1  =>  esc_html__('second', 'politix')
                );
    $a_plural =  array( esc_html__('year', 'politix')   => esc_html__('years', 'politix'),
                        esc_html__('month', 'politix')  => esc_html__('months', 'politix'),
                        esc_html__('day', 'politix')    => esc_html__('days', 'politix'),
                        esc_html__('hour', 'politix')   => esc_html__('hours', 'politix'),
                        esc_html__('minute', 'politix') => esc_html__('minutes', 'politix'),
                        esc_html__('second', 'politix') => esc_html__('seconds', 'politix')
                );

    foreach ($a as $secs => $str)
    {
        $d = $etime / $secs;
        if ($d >= 1)
        {
            $r = round($d);
            return $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . esc_html__(' ago', 'politix');
        }
    }
}

/* Additional functions */
function cws_scroll_to_top (){
    ob_start();

    echo "<div class='scroll-to-top'></div>";

    return ob_get_clean();
}

if( !isset($content_width) ){
	$content_width = 1170;
}

if(!function_exists('cws_load_more')){
	function cws_load_more ( $paged = 1, $max_paged = PHP_INT_MAX ){
	?>	
		<div class="cws_custom_button_wrapper load_more">
			<a class="cws_custom_button regular cws_load_more" href="#"><?php esc_html_e( "Load More", 'politix' ); ?></a>
		</div>
	<?php
	}
}

function cws_portfolio_loader(){
	ob_start();
	?>
		<div class='portfolio_loader_wraper'>
			<div class='portfolio_loader_container'>
				<svg width='104px' height='104px' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid" class="uil-default"><rect x="0" y="0" width="100" height="100" fill="none" class="bk"></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(0 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(30 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.083s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(60 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.1667s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(90 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.25s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(120 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.33s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(150 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.4166s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(180 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.5s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(210 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.5833s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(240 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.67s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(270 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.75s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(300 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.83s' repeatCount='indefinite'/></rect><rect x='46.5' y='40' width='7' height='20' rx='5' ry='5' fill='#000000' transform='rotate(330 50 50) translate(0 -30)'><animate attributeName='opacity' from='1' to='0' dur='1s' begin='0.9167s' repeatCount='indefinite'/></rect></svg>
			</div>
		</div>
	<?php
	echo ob_get_clean();
}

// Add theme menu walkers
require_once(POLITIX_THEME_DIR . '/core/functions-walkers.php');

?>