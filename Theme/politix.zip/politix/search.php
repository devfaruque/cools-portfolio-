<?php
	$paged = !empty($_POST['paged']) ? (int)$_POST['paged'] : (!empty($_GET['paged']) ? (int)$_GET['paged'] : ( get_query_var("paged") ? get_query_var("paged") : 1 ) );
	$posts_per_page = (int)get_option('posts_per_page');
	$search_terms = get_query_var( 'search_terms' );

	get_header();
	global $cws_theme_funcs;
	global $politix_theme_standard;

	if ($cws_theme_funcs){
		$sb = $cws_theme_funcs->cws_render_sidebars( get_queried_object_id() );
		$fixed_header = $cws_theme_funcs->cws_get_meta_option( 'fixed_header' );
		$class = $sb['layout_class'].' '. $sb['sb_class'];
		$sb['sb_class'] = apply_filters('cws_print_single_class', $class);
	}
?>
<div class="page-content search_results <?php echo (isset($sb['sb_class']) ? $sb['sb_class'] : ''); ?>">
	<?php 
		echo (isset($sb['content']) ? $sb['content'] : '<div class="container">'); 
	?>

	<main>
		<div class="grid_row clearfix">
			<?php
			global $wp_query;
			$total_post_count = $wp_query->found_posts;
			$max_paged = ceil( $total_post_count / $posts_per_page );
			if ( 0 === strlen($wp_query->query_vars['s'] ) ){
				$message_title = esc_html__( 'Empty search string', 'politix' );
				$message = esc_html__( 'Please, enter some characters to search field', 'politix' );
				if(!empty($cws_theme_funcs)){
					$printed_theme_funcs = $cws_theme_funcs->cws_print_search_form($message_title, $message);
					echo sprintf("%s", $printed_theme_funcs);
				}else{
					$printed_theme_standard = $politix_theme_standard->cws_print_search_form($message_title, $message);
					echo sprintf("%s", $printed_theme_standard);
				}
				
			} else {

				if(have_posts()){
					?>
					<section class="news posts_grid layout_1 meta_above_title">
						<div class='cws_vc_shortcode_wrapper'>
							<div class="cws_vc_shortcode_grid grid layout-1">
							<?php
								$use_pagination = $max_paged > 1;
									while( have_posts() ) : the_post();
										$content = get_the_content();
										$content = preg_replace( '/\[.*?(\"title\":\"(.*?)\").*?\]/', '$2', $content );
										$content = preg_replace( '/\[.*?(|title=\"(.*?)\".*?)\]/', '$2', $content );
										$content = strip_tags( $content );
										$content = preg_replace( '|\s+|', ' ', $content );
										$title = get_the_title();

										$cont = '';
										$bFound = false;
										$contlen = strlen( $content );

										foreach ($search_terms as $term) {
											$pos = 0;
											$term_len = strlen($term);
											do {
												if ( $contlen <= $pos ) {
													break;
												}
												$pos = stripos( $content, $term, $pos );
												if ( $pos ) {
													$start = ($pos > 50) ? $pos - 50 : 0;
													$temp = substr( $content, $start, $term_len + 100 );
													$cont .= ! empty( $temp ) ? $temp . ' ... ' : '';
													$pos += $term_len + 50;
												}
											} while ($pos);
										}

										if( strlen($cont) > 0 ){
											$bFound = true;
										} else {
											$cont = mb_substr( $content, 0, $contlen < 100 ? $contlen : 100 );
											if ( $contlen > 100 ){
												$cont .= '...';
											}
											$bFound = true;
										}

										$pattern = "#\[[^\]]+\]#";
										$replace = "";
										$cont = preg_replace($pattern, $replace, $cont);
										$cont = preg_replace('/('.implode('|', $search_terms) .')/iu', '<mark>\0</mark>', $cont);
										$permalink = esc_url( get_the_permalink() );
										$button_word = esc_html__( 'Read More', 'politix' );
										$title = get_the_title();
										$title = preg_replace( '/('.implode( '|', $search_terms ) .')/iu', '<mark>\0</mark>', $title );

										echo "<article class='item post_item'>";
											echo "<div class='post_wrapper'>";

												echo "<div class='post_info_wrapper'>";

                                                    /* -----> Title <----- */
                                                    if( !empty($title) ){
                                                        echo "<h3 class='post_title'>";
                                                        echo "<a href='".esc_url($permalink)."'>".$title."</a>";
                                                        echo "</h3>";
                                                    }

                                                    /* -----> Content <----- */
                                                    if( !empty($cont) ){
                                                        echo "<div class='post_content'>";
                                                        echo apply_filters( 'the_content', $cont );
                                                        echo "</div>";
                                                    }


                                                    echo "<div class='post_info_footer'>";
                                                        echo "<div class='post_meta_wrapper'>";
                                                            echo cws_post_categories();
                                                            echo cws_blog_date();
                                                            echo cws_blog_meta_comments();
                                                            echo cws_blog_meta_likes();
                                                        echo "</div>";
                                                        echo "<div class='post_meta_item read_more_wrapper'>";
                                                            echo "<a href='".esc_url($permalink)."' class='read_more'>"
                                        .esc_html($button_word)."</a>";
                                                        echo "</div>";
                                                    echo "</div>";


												echo "</div>";

											echo "</div>";
										echo "</article>";
									endwhile;
									wp_reset_postdata();
								?>
							</div>
						</div>
					</section>
					<?php
					if ( $use_pagination ) {
						cws_pagination($paged, $max_paged);
					}
				}
				else {
					$message_title = esc_html__( 'Nothing Found', 'politix' );
					$message = esc_html__( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'politix' );
					
					if(!empty($cws_theme_funcs)){
						$printed_cws_theme_funcs = $cws_theme_funcs->cws_print_search_form($message_title, $message);
						echo sprintf("%s", $printed_cws_theme_funcs);
					}else{
						$printed_politix_theme_standard = $politix_theme_standard->cws_print_search_form($message_title, $message);
						echo sprintf("%s", $printed_politix_theme_standard);
					}
				}
			}
			?>
		</div>
	</main>
	<?php echo (isset($sb['content']) ? $sb['content'] : '</div>'); ?>
</div>

<?php

get_footer ();
?>