<?php

function cwsfw_get_sections() {

	$l_components = cwsfw_get_local_components();
	$g_components = array();
	if (function_exists('cws_core_get_base_components')) {
		$g_components = cws_core_get_base_components();
		$g_components = cws_core_merge_components($g_components, $l_components);
	}

	$settings = array(
		'general_setting' => array(
			'type' => 'section',
			'title' => esc_html__( 'Header', 'politix' ),
			'icon' => array('fa', 'header'),
			'layout' => array(
				'general_cont' => array(
					'type' => 'tab',
					'init' => 'open',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Header', 'politix' ),
					'layout' => array(

						'header' => array(
							'type' => 'fields',
							'addrowclasses' => 'inside-box groups grid-col-12 box main-box',
							'layout' => array(
								'order' => array(
									'type' => 'group',
									'addrowclasses' => 'group sortable drop grid-col-12 no_overflow',
									'tooltip' => array(
										'title' => esc_html__( 'Header Order', 'politix' ),
										'content' => esc_html__( 'Drag to reorder and customize the header.', 'politix' ),
									),
									'title' => esc_html__('Header order', 'politix' ),
									'button_title' => esc_html__('Add new sidebar', 'politix' ),
									'value' => array(
										array('title' => esc_html__('Top Bar', 'politix'),'val' => 'top_bar_box'),
										array('title' => esc_html__('Header Zone', 'politix'),'val' => 'drop_zone_start'),
										array('title' => esc_html__('Logo', 'politix'),'val' => 'logo_box'),
										array('title' => esc_html__('Menu', 'politix'),'val' => 'menu_box'),
										array('title' => esc_html__('Header Zone', 'politix'),'val' => 'drop_zone_end'),
										array('title' => esc_html__('Title area', 'politix'), 'val' => 'title_box'),
									),
									'layout' => array(
										'title' => array(
											'type' => 'text',
											'value' => '',
											'atts' => 'data-role="title"',
											'title' => esc_html__('Sidebar', 'politix' ),
										),

										'val' => array(
											'type' => 'text',
										)

									)
								),
								'outside_slider' => array(
									'title' => esc_html__( 'Header Overlays Slider', 'politix' ),
                                        'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
								),
                                'slider_mask' => array(
                                    'title' => esc_html__( 'Add SVG mask to Slider', 'politix' ),
                                    'addrowclasses' => 'checkbox grid-col-12',
                                    'type' => 'checkbox',
                                    'atts' => 'checked'
                                ),
								'customize' => array(
									'title' => esc_html__( 'Customize', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
									'atts' => 'checked data-options="e:background_image;e:background_color;e:overlay;e:spacings;e:override_topbar_color;e:override_topbar_color_hover;"',
								),
								'background_image' => array(
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 inside-box groups',
									'layout' => '%image_layout%',
								),
                                'background_color'	=> array(
                                    'title'	=> esc_html__( 'Background Color', 'politix' ),
                                    'atts' => 'data-default-color=""',
                                    'addrowclasses' => 'grid-col-12 disable',
                                    'value' => '',
                                    'type'	=> 'text',
                                ),
								'overlay' => array(
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 disable inside-box groups',
									'layout' => array(
										'type'	=> array(
											'title'		=> esc_html__( 'Add Color overlay', 'politix' ),
											'addrowclasses' => 'grid-col-4',
											'type'	=> 'select',
											'source'	=> array(
												'none' => array( esc_html__( 'None', 'politix' ),  false, 'd:opacity;d:color;d:gradient;' ),
												'color' => array( esc_html__( 'Color', 'politix' ),  true, 'e:opacity;e:color;d:gradient;' ),
												'gradient' => array( esc_html__('Gradient', 'politix' ), false, 'e:opacity;d:color;e:gradient;' )
											),
										),
										'color'	=> array(
											'title'	=> esc_html__( 'Color', 'politix' ),
											'atts' => 'data-default-color="#000000"',
											'addrowclasses' => 'grid-col-4',
											'value' => '#000000',
											'type'	=> 'text',
										),
										'opacity' => array(
											'type' => 'number',
											'title' => esc_html__( 'Opacity (%)', 'politix' ),
											'placeholder' => esc_html__( 'In percents', 'politix' ),
											'value' => '55',
											'addrowclasses' => 'grid-col-4',
										),
										'gradient' => array(
											'type' => 'fields',
											'addrowclasses' => 'grid-col-12 disable box inside-box groups',
											'layout' => '%gradient_layout%',
										),
									),
								),
								'override_topbar_color'	=> array(
									'title'	=> esc_html__( 'Override TopBar\'s Font Color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'addrowclasses' => 'grid-col-6 disable',
									'value' => '#ffffff',
									'type'	=> 'text',
								),
								'override_topbar_color_hover' => array(
									'title'	=> esc_html__( 'Override TopBar\'s Font Color on Hover', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'addrowclasses' => 'grid-col-6 disable',
									'value' => '#ffffff',
									'type'	=> 'text',
								),
								'spacings' => array(
									'title' => esc_html__( 'Add Spacings', 'politix' ),
									'type' => 'margins',
									'addrowclasses' => 'disable grid-col-4 two-inputs',
									'value' => array(
										'top' => array('placeholder' => esc_html__( 'Top', 'politix' ), 'value' => '0'),
										'bottom' => array('placeholder' => esc_html__( 'Bottom', 'politix' ), 'value' => '0'),
									),
								),
							),
						),

					)
				),
				'logo_cont' => array(
					'type' => 'tab',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Logo', 'politix' ),
					'layout' => array(

						'logo_box' => array(
							'type' => 'fields',
							'addrowclasses' => 'inside-box groups grid-col-12 box main-box',
							'layout' => array(
								'enable' => array(
									'title' => esc_html__( 'Logo area', 'politix' ),
									'addrowclasses' => 'checkbox alt grid-col-12',
									'type' => 'checkbox',
									'atts' => 'checked',
								),
								'default'	=> array(
									'title'		=> esc_html__( 'Default Logo Variation', 'politix' ),
									'addrowclasses' => 'grid-col-12',
									'type'	=> 'select',
									'source'	=> array(
										'dark' => array( esc_html__( 'Dark', 'politix' ),  false, '' ),
										'light' => array( esc_html__( 'Light', 'politix' ),  true, '' ),
									),
								),
								'dark' => array(
									'title' => esc_html__( 'Dark Logo', 'politix' ),
									'type' => 'media',
									'url-atts' => 'readonly',
									'addrowclasses' => 'grid-col-6',
									'layout' => array(
										'is_high_dpi' => array(
											'title' => esc_html__( 'High-Resolution logo', 'politix' ),
											'addrowclasses' => 'checkbox',
											'type' => 'checkbox',
										),
									),
								),
								'light' => array(
									'title' => esc_html__( 'Light Logo', 'politix' ),
									'type' => 'media',
									'url-atts' => 'readonly',
									'addrowclasses' => 'grid-col-6',
									'layout' => array(
										'is_high_dpi' => array(
											'title' => esc_html__( 'High-Resolution logo', 'politix' ),
											'addrowclasses' => 'checkbox',
											'type' => 'checkbox',
										),
									),
								),
								'dimensions' => array(
									'title' => esc_html__( 'Dimensions', 'politix' ),
									'type' => 'dimensions',
									'addrowclasses' => 'grid-col-4',
									'value' => array(
										'width' => array('placeholder' => esc_html__( 'Width', 'politix' ), 'value' => ''),
										'height' => array('placeholder' => esc_html__( 'Height', 'politix' ), 'value' => ''),
									),
								),
								'position' => array(
									'title' => esc_html__( 'Position', 'politix' ),
									'type' => 'radio',
									'subtype' => 'images',
									'addrowclasses' => 'grid-col-4',
									'value' => array(
										'left' => array( esc_html__('Left', 'politix'), true, '', '/img/align-left.png' ),
										'center' =>array( esc_html__('Center', 'politix'), false, '', '/img/align-center.png', ),
										'right' =>array( esc_html__('Right', 'politix'), false, '', '/img/align-right.png', ),
									),
								),
								'margin' => array(
									'title' => esc_html__( 'Margins (px)', 'politix' ),
									'type' => 'margins',
									'addrowclasses' => 'grid-col-4',
									'value' => array(
										'top' => array('placeholder' => esc_html__( 'Top', 'politix' ), 'value' => '0'),
										'left' => array('placeholder' => esc_html__( 'left', 'politix' ), 'value' => '0'),
										'right' => array('placeholder' => esc_html__( 'Right', 'politix' ), 'value' => '0'),
										'bottom' => array('placeholder' => esc_html__( 'Bottom', 'politix' ), 'value' => '0'),
									),
								),
                                'with_site_name' => array(
                                    'title' => esc_html__( 'Add Site Name to the Logo', 'politix' ),
                                    'addrowclasses' => 'checkbox grid-col-12',
                                    'type' => 'checkbox',
                                    'atts' => 'checked data-options="e:site_name_color;"'
                                ),
                                'site_name_color'	=> array(
                                    'title'	=> esc_html__( 'Site Name Color', 'politix' ),
                                    'atts' => 'data-default-color="#ffffff"',
                                    'addrowclasses' => 'disable grid-col-4',
                                    'value' => '#ffffff',
                                    'type'	=> 'text',
                                ),
								'in_menu' => array(
									'title' => esc_html__( 'Logo in menu box', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
									'atts' => 'checked data-options="d:wide;d:customize;d:border;d:extra_button;d:info_items;d:text_color;d:text_color_hover;d:add_info;"',
								),
                                'text_color'	=> array(
                                    'title'	=> esc_html__( 'Logo area text color', 'politix' ),
                                    'atts' => 'data-default-color=""',
                                    'addrowclasses' => 'grid-col-6',
                                    'value' => '',
                                    'type'	=> 'text',
                                ),
                                'text_color_hover'	=> array(
                                    'title'	=> esc_html__( 'Logo area hovered text color', 'politix' ),
                                    'atts' => 'data-default-color=""',
                                    'addrowclasses' => 'grid-col-6',
                                    'value' => '',
                                    'type'	=> 'text',
                                ),
                                'add_info' => array(
                                    'title' => esc_html__( 'Add info to the logo area', 'politix' ),
                                    'addrowclasses' => 'checkbox grid-col-12',
                                    'type' => 'checkbox',
                                    'atts' => 'data-options="e:info_title;e:info_value;"',
                                ),
                                'info_title' => array(
                                    'title' => esc_html__( 'Info title', 'politix' ),
                                    'type' => 'text',
                                    'addrowclasses' => 'grid-col-6 disable',
                                    'value' => '',
                                ),
                                'info_value' => array(
                                    'title' => esc_html__( 'Info value', 'politix' ),
                                    'type' => 'text',
                                    'addrowclasses' => 'grid-col-6 disable',
                                    'value' => '',
                                ),
                                'info_items' => array(
                                    'type' => 'group',
                                    'addrowclasses' => 'grid-col-12 group expander sortable box',
                                    'title' => esc_html__('Logo Info', 'politix' ),
                                    'button_title' => esc_html__('Add new info row', 'politix' ),
                                    'layout' => array(
                                        'icon' => array(
                                            'type' => 'select',
                                            'addrowclasses' => 'grid-col-3 fai',
                                            'source' => 'fa',
                                            'title' => esc_html__('Select the icon', 'politix' )
                                        ),
                                        'title' => array(
                                            'type' => 'text',
                                            'atts' => 'data-role="title"',
                                            'addrowclasses' => 'grid-col-3',
                                            'title' => esc_html__('Write main info', 'politix' ),
                                        ),
                                        'url' => array(
                                            'type' => 'text',
                                            'addrowclasses' => 'grid-col-3',
                                            'title' => esc_html__('Write URL', 'politix' ),
                                        ),
                                        'link_type' => array(
                                            'type' => 'select',
                                            'addrowclasses' => 'grid-col-3 fai',
                                            'source' => array(
                                                'link' => array( esc_html__( 'Link', 'politix' ),  true, '' ),
                                                'mailto:' => array( esc_html__( 'Email', 'politix' ),  false, '' ),
                                                'skype:' => array( esc_html__( 'Skype', 'politix' ),  false, '' ),
                                                'tel:' => array( esc_html__( 'Phone', 'politix' ),  false, '' ),
                                            ),
                                            'title' => esc_html__('Select link type', 'politix' )
                                        ),
                                    ),
                                ),
								'wide' => array(
									'title' => esc_html__( 'Apply Full-Width Container', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
								),
								'border' => array(
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 inside-box groups',
									'layout' => '%border_layout%',
								),

                                'customize' => array(
                                    'title' => esc_html__( 'Customize', 'politix' ),
                                    'addrowclasses' => 'checkbox grid-col-12',
                                    'type' => 'checkbox',
                                    'atts' => 'data-options="e:background_image;e:background_color;e:spacings;e:overlay"',
                                ),
                                'background_image' => array(
                                    'type' => 'fields',
                                    'addrowclasses' => 'grid-col-12 inside-box groups',
                                    'layout' => '%image_layout%',
                                ),
                                'background_color'	=> array(
                                    'title'	=> esc_html__( 'Background Color', 'politix' ),
                                    'atts' => 'data-default-color=""',
                                    'addrowclasses' => 'grid-col-12 disable',
                                    'value' => '',
                                    'type'	=> 'text',
                                ),
                                'overlay' => array(
                                    'type' => 'fields',
                                    'addrowclasses' => 'grid-col-12 box inside-box groups',
                                    'layout' => array(
                                        'type'	=> array(
                                            'title'		=> esc_html__( 'Add Color overlay', 'politix' ),
                                            'addrowclasses' => 'grid-col-4',
                                            'type'	=> 'select',
                                            'source'	=> array(
                                                'none' => array( esc_html__( 'None', 'politix' ),  true, 'd:opacity;d:color;d:gradient;' ),
                                                'color' => array( esc_html__( 'Color', 'politix' ),  false, 'e:opacity;e:color;d:gradient;' ),
                                                'gradient' => array( esc_html__('Gradient', 'politix' ), false, 'e:opacity;d:color;e:gradient;' )
                                            ),
                                        ),
                                        'color'	=> array(
                                            'title'	=> esc_html__( 'Color', 'politix' ),
                                            'atts' => 'data-default-color="#ffffff"',
                                            'addrowclasses' => 'grid-col-4',
                                            'value' => '#ffffff',
                                            'type'	=> 'text',
                                        ),
                                        'opacity' => array(
                                            'type' => 'number',
                                            'title' => esc_html__( 'Opacity (%)', 'politix' ),
                                            'placeholder' => esc_html__( 'In percents', 'politix' ),
                                            'value' => '100',
                                            'addrowclasses' => 'grid-col-4',
                                        ),
                                        'gradient' => array(
                                            'type' => 'fields',
                                            'addrowclasses' => 'grid-col-12 disable box inside-box groups',
                                            'layout' => '%gradient_layout%',
                                        ),
                                    ),
                                ),
                                'spacings' => array(
                                    'title' => esc_html__( 'Add Spacings', 'politix' ),
                                    'type' => 'margins',
                                    'addrowclasses' => 'disable grid-col-4 two-inputs',
                                    'value' => array(
                                        'top' => array('placeholder' => esc_html__( 'Top', 'politix' ), 'value' => '0'),
                                        'bottom' => array('placeholder' => esc_html__( 'Bottom', 'politix' ), 'value' => '0'),
                                    ),
                                ),

                                'extra_button' => array(
                                    'title' => esc_html__( 'Add extra button to the logo area', 'politix' ),
                                    'addrowclasses' => 'checkbox grid-col-12',
                                    'type' => 'checkbox',
                                    'atts' => 'data-options="e:extra_button_title;e:extra_button_link;e:extra_button_icon;e:extra_button_type;e:extra_button_color;e:extra_button_hover;e:extra_button_bd_color;"',
                                ),
                                'extra_button_title' => array(
                                    'title' => esc_html__( 'Extra Button title', 'politix' ),
                                    'type' => 'text',
                                    'addrowclasses' => 'grid-col-6 disable',
                                    'value' => 'Donate',
                                ),
                                'extra_button_link' => array(
                                    'title' => esc_html__( 'Extra Button link', 'politix' ),
                                    'type' => 'text',
                                    'addrowclasses' => 'grid-col-6 disable',
                                    'value' => '#link',
                                ),
                                'extra_button_icon' => array(
                                    'title' => esc_html__( 'Extra Button icon', 'politix' ),
                                    'type' => 'select',
                                    'addrowclasses' => 'grid-col-6 fai disable',
                                    'source' => 'fa',
                                ),
                                'extra_button_type' => array(
                                    'title' => esc_html__( 'Extra Button type', 'politix' ),
                                    'type' => 'select',
                                    'addrowclasses' => 'grid-col-6 disable',
                                    'source' => array(
                                        'default' => array( esc_html__( 'Default', 'politix' ),  true, '' ),
                                        'advanced' => array( esc_html__( 'Advanced', 'politix' ),  false, '' ),
                                    ),
                                ),
                                'extra_button_color' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Extra Button text color', 'politix' ),
                                    'atts' => 'data-default-color="#ffffff"',
                                    'value' => '#ffffff',
                                    'addrowclasses' => 'grid-col-4',
                                ),
                                'extra_button_hover' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Extra Button text color (on Hover)', 'politix' ),
                                    'atts' => 'data-default-color="#ffffff"',
                                    'value' => '#ffffff',
                                    'addrowclasses' => 'grid-col-4',
                                ),
                                'extra_button_bd_color' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Extra Button accent color', 'politix' ),
                                    'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
                                    'value' => POLITIX_FIRST_COLOR,
                                    'addrowclasses' => 'grid-col-4',
                                ),
							),
						),

					)
				),
				'menu_cont' => array(
					'type' => 'tab',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Menu', 'politix' ),
					'layout' => array(

						'menu_box' => array(
							'type' => 'fields',
							'addrowclasses' => 'inside-box groups grid-col-12 box main-box',
							'layout' => array(
								'enable' => array(
									'title' => esc_html__( 'Menu', 'politix' ),
									'addrowclasses' => 'checkbox alt grid-col-12',
									'type' => 'checkbox',
									'atts' => 'checked',
								),
								'position' => array(
									'title' => esc_html__( 'Menu Alignment', 'politix' ),
									'type' => 'radio',
									'subtype' => 'images',
									'addrowclasses' => 'grid-col-4',
									'value' => array(
										'left' => array( esc_html__( 'Left', 'politix' ), 	false, '', '/img/align-left.png' ),
										'center' =>array( esc_html__( 'Center', 'politix' ), false, '', '/img/align-center.png' ),
										'right' =>array( esc_html__( 'Right', 'politix' ), true, '', '/img/align-right.png' ),
									),
								),
								'search_place' => array(
									'title' => esc_html__( 'Search Icon Location', 'politix' ),
									'type' => 'radio',
									'subtype' => 'images',
									'addrowclasses' => 'grid-col-4',
									'value' => array(
										'none' => array( esc_html__( 'None', 'politix' ), 	true, '', '/img/no_layout.png' ),
										'top' => array( esc_html__( 'Top', 'politix' ), 	false, '', '/img/search-social-right.png' ),
										'left' =>array( esc_html__( 'Left', 'politix' ), false, '', '/img/search-menu-left.png' ),
										'right' =>array( esc_html__( 'Right', 'politix' ), false, '', '/img/search-menu-right.png' ),
									),
								),							
								'mobile_place' => array(
									'title' => esc_html__( 'Mobile Menu Location', 'politix' ),
									'type' => 'radio',
									'subtype' => 'images',
									'addrowclasses' => 'grid-col-4',
									'value' => array(
										'left' =>array( esc_html__( 'Left', 'politix' ), false, '', '/img/hamb-left.png' ),
										'right' =>array( esc_html__( 'Right', 'politix' ), true, '', '/img/hamb-right.png' ),
									),
								),
								'background_color' => array(
									'title' => esc_html__( 'Background color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'grid-col-6',
									'type' => 'text',
								),
								'background_opacity' => array(
									'type' => 'number',
									'title' => esc_html__( 'Opacity', 'politix' ),
									'placeholder' => esc_html__( 'In percents', 'politix' ),
									'addrowclasses' => 'grid-col-6',
									'value' => '0'
								),
								'font_color' => array(
									'type' => 'text',
									'title' => esc_html__( 'Override Font color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'grid-col-6',
								),
								'font_color_hover' => array(
									'type' => 'text',
									'title' => esc_html__( 'Override Font hover color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'grid-col-6',
								),

                                'submenu_font_color' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Submenu item Font color', 'politix' ),
                                    'atts' => 'data-default-color="#4c4c4d"',
                                    'value' => '#4c4c4d',
                                    'addrowclasses' => 'grid-col-6',
                                ),
                                'submenu_font_color_hover' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Submenu item Font color on Hover', 'politix' ),
                                    'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
                                    'value' => POLITIX_FIRST_COLOR,
                                    'addrowclasses' => 'grid-col-6',
                                ),
                                'submenu_bg_color' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Submenu item Background color', 'politix' ),
                                    'atts' => 'data-default-color="#ffffff"',
                                    'value' => '#ffffff',
                                    'addrowclasses' => 'grid-col-6',
                                ),
                                'submenu_bg_color_hover' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Submenu item Background color on Hover', 'politix' ),
                                    'atts' => 'data-default-color="#ffffff"',
                                    'value' => '#ffffff',
                                    'addrowclasses' => 'grid-col-6',
                                ),

								'border' => array(
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 box inside-box groups',
									'layout' => '%border_layout%',
								),
								'margin' => array(
									'title' => esc_html__( 'Add Spacings', 'politix' ),
									'type' => 'margins',
									'addrowclasses' => 'grid-col-12 two-inputs',
									'value' => array(
										'top' => array('placeholder' => esc_html__( 'Top', 'politix' ), 'value' => '25'),
										'bottom' => array('placeholder' => esc_html__( 'Bottom', 'politix' ), 'value' => '26'),
									),
								),
								'menu_mode'	=> array(
									'title'		=> esc_html__( 'Desktop Menu on Devices', 'politix' ),
									'type'	=> 'select',
									'addrowclasses' => 'grid-col-12',
									'source'	=> array(
										'default' => array( esc_html__( 'Default', 'politix' ),  true ),
										'portrait' => array( esc_html__( 'Portrait', 'politix' ), false ),
										'landdscape' => array( esc_html__( 'Landscape', 'politix' ), false ),
										'both' => array( esc_html__( 'Both', 'politix' ), false ),
									),
								),				
								'sandwich' => array(
									'title' => esc_html__( 'Use mobile menu on desktop PCs', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
								),
								'wide' => array(
									'title' => esc_html__( 'Apply Full-Width Menu', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
								),
                                'add_highlight' => array(
                                    'title' => esc_html__( 'Highlight active item', 'politix' ),
                                    'addrowclasses' => 'checkbox grid-col-12',
                                    'type' => 'checkbox',
                                    'atts' => 'checked data-options="e:highlight_color;"',
                                ),
                                'highlight_color' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Highlight color', 'politix' ),
                                    'atts' => 'data-default-color="#ffffff"',
                                    'value' => '#ffffff',
                                    'addrowclasses' => 'grid-col-12 disable',
                                ),
                                'extra_button' => array(
                                    'title' => esc_html__( 'Add extra button to the menu', 'politix' ),
                                    'addrowclasses' => 'checkbox grid-col-12',
                                    'type' => 'checkbox',
                                    'atts' => 'checked data-options="e:extra_button_title;e:extra_button_link;e:extra_button_icon;e:extra_button_type;e:extra_button_color;e:extra_button_hover;e:extra_button_bd_color;"',
                                ),
                                'extra_button_title' => array(
                                    'title' => esc_html__( 'Extra Button title', 'politix' ),
                                    'type' => 'text',
                                    'addrowclasses' => 'grid-col-6 disable',
                                    'value' => 'Donate',
                                ),
                                'extra_button_link' => array(
                                    'title' => esc_html__( 'Extra Button link', 'politix' ),
                                    'type' => 'text',
                                    'addrowclasses' => 'grid-col-6 disable',
                                    'value' => '#link',
                                ),
                                'extra_button_icon' => array(
                                    'title' => esc_html__( 'Extra Button icon', 'politix' ),
                                    'type' => 'select',
                                    'addrowclasses' => 'grid-col-6 fai disable',
                                    'source' => 'fa',
                                ),
                                'extra_button_type' => array(
                                    'title' => esc_html__( 'Extra Button type', 'politix' ),
                                    'type' => 'select',
                                    'addrowclasses' => 'grid-col-6 disable',
                                    'source' => array(
                                        'default' => array( esc_html__( 'Default', 'politix' ),  true, '' ),
                                        'advanced' => array( esc_html__( 'Advanced', 'politix' ),  false, '' ),
                                    ),
                                ),
                                'extra_button_color' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Extra Button text color', 'politix' ),
                                    'atts' => 'data-default-color="#ffffff"',
                                    'value' => '#ffffff',
                                    'addrowclasses' => 'grid-col-4',
                                ),
                                'extra_button_hover' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Extra Button text color (on Hover)', 'politix' ),
                                    'atts' => 'data-default-color="#ffffff"',
                                    'value' => '#ffffff',
                                    'addrowclasses' => 'grid-col-4',
                                ),
                                'extra_button_bd_color' => array(
                                    'type' => 'text',
                                    'title' => esc_html__( 'Extra Button accent color', 'politix' ),
                                    'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
                                    'value' => POLITIX_FIRST_COLOR,
                                    'addrowclasses' => 'grid-col-4',
                                ),
							),
						),

					)
				),
				'mobile_menu_cont' => array(
					'type' => 'tab',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Mobile', 'politix' ),
					'layout' => array(

						'mobile_menu_box' => array(
							'type' => 'fields',
							'addrowclasses' => 'inside-box groups grid-col-12 box main-box',
							'layout' => array(
								'mobile' => array(
									'title' => esc_html__( 'Mobile Logo', 'politix' ),
									'type' => 'media',
									'url-atts' => 'readonly',
									'addrowclasses' => 'grid-col-6',
									'layout' => array(
										'logo_mobile_is_high_dpi' => array(
											'title' => esc_html__( 'High-Resolution mobile logo', 'politix' ),
											'addrowclasses' => 'checkbox',
											'type' => 'checkbox',
										),
									),
								),
								'navigation' => array(
									'title' => esc_html__( 'Navigation Logo', 'politix' ),
									'type' => 'media',
									'url-atts' => 'readonly',
									'addrowclasses' => 'grid-col-6',
									'layout' => array(
										'logo_mobile_is_high_dpi' => array(
											'title' => esc_html__( 'High-Resolution mobile logo', 'politix' ),
											'addrowclasses' => 'checkbox',
											'type' => 'checkbox',
										),
									),
								),
								'dimensions_mobile' => array(
									'title' => esc_html__( 'Mobile Logo Dimensions', 'politix' ),
									'type' => 'dimensions',
									'addrowclasses' => 'grid-col-6',
									'value' => array(
										'width' => array('placeholder' => esc_html__( 'Width', 'politix' ), 'value' => ''),
										'height' => array('placeholder' => esc_html__( 'Height', 'politix' ), 'value' => ''),
									),
								),
								'dimensions_navigation' => array(
									'title' => esc_html__( 'Navigation Logo Dimensions', 'politix' ),
									'type' => 'dimensions',
									'addrowclasses' => 'grid-col-6',
									'value' => array(
										'width' => array('placeholder' => esc_html__( 'Width', 'politix' ), 'value' => ''),
										'height' => array('placeholder' => esc_html__( 'Height', 'politix' ), 'value' => ''),
									),
								),
								'remove_search' => array(
									'title' => esc_html__( 'Remove Search from Navigation', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-6',
									'type' => 'checkbox',
                                    'atts' => 'checked'
								),
							),
						),

					)
				),
				'sticky_menu_cont' => array(
					'type' => 'tab',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Sticky', 'politix' ),
					'layout' => array(

						'sticky_menu' => array(
							'type' => 'fields',
							'addrowclasses' => 'inside-box groups grid-col-12 box main-box',
							'layout' => array(
								'enable' => array(
									'title' => esc_html__( 'Sticky menu', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-6 alt',
									'type' => 'checkbox',
								),
								'sticky' => array(
									'title' => esc_html__( 'Sticky Logo', 'politix' ),
									'type' => 'media',
									'url-atts' => 'readonly',
									'addrowclasses' => 'grid-col-6',
									'layout' => array(
										'logo_sticky_is_high_dpi' => array(
											'title' => esc_html__( 'High-Resolution sticky logo', 'politix' ),
											'addrowclasses' => 'checkbox',
											'type' => 'checkbox',
										),
									),
								),
								'dimensions_sticky' => array(
									'title' => esc_html__( 'Sticky Logotype Dimensions', 'politix' ),
									'type' => 'dimensions',
									'addrowclasses' => 'grid-col-6',
									'value' => array(
										'width' => array('placeholder' => esc_html__( 'Width', 'politix' ), 'value' => ''),
										'height' => array('placeholder' => esc_html__( 'Height', 'politix' ), 'value' => ''),
									),
								),
								'mode'	=> array(
									'title'		=> esc_html__( 'Select a Sticky\'s Mode', 'politix' ),
									'type'	=> 'select',
									'addrowclasses' => 'grid-col-6',
									'source'	=> array(
										'smart' => array( esc_html__( 'Smart', 'politix' ),  true ),
										'simple' => array( esc_html__( 'Simple', 'politix' ), false ),
									),
								),
								'margin_sticky' => array(
									'title' => esc_html__( 'Sticky Menu Spacings', 'politix' ),
									'type' => 'margins',
									'tooltip' => array(
										'title' => esc_html__('Sticky menu spacings', 'politix'),
										'content' => esc_html__('These values should not exceed the menu spacings, which are set in Menu\'s section', 'politix'),
									),
									'addrowclasses' => 'grid-col-6 two-inputs',
									'value' => array(
										'top' => array('placeholder' => esc_html__( 'Top', 'politix' ), 'value' => '15'),
										'bottom' => array('placeholder' => esc_html__( 'Bottom', 'politix' ), 'value' => '15'),
									),
								),			
								'background_color' => array(
									'title' => esc_html__( 'Background color', 'politix' ),
									'tooltip' => array(
										'title' => esc_html__( 'Background Color', 'politix' ),
										'content' => esc_html__( 'This color is applied to header section including top bar.', 'politix' ),
									),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'grid-col-6',
									'type' => 'text',
								),
								'background_opacity' => array(
									'type' => 'number',
									'title' => esc_html__( 'Background Opacity', 'politix' ),
									'tooltip' => array(
										'title' => esc_html__( 'Background Opacity', 'politix' ),
										'content' => esc_html__( 'This option will apply the transparent header when set to "0".', 'politix' ),
									),
									'placeholder' => esc_html__( 'In percents', 'politix' ),
									'addrowclasses' => 'grid-col-6',
									'value' => '100'
								),
								'font_color' => array(
									'title' => esc_html__( 'Override Font color', 'politix' ),
									'tooltip' => array(
										'title' => esc_html__( 'Override Font Color', 'politix' ),
										'content' => wp_kses(__( 'This color is applied to main menu items and menu icons, submenus will use the color which is set in Typography section.<br /> This option is very useful when transparent menu is set.', 'politix' ), array(
										    'br' => true,
                                        )),
									),
									'atts' => 'data-default-color="#4c4c4d"',
									'value' => '#4c4c4d',
									'addrowclasses' => 'grid-col-6',
									'type' => 'text',
								),
								'font_color_hover' => array(
									'title' => esc_html__( 'Override Font color on hover', 'politix' ),
									'tooltip' => array(
										'title' => esc_html__( 'Override Font Color on hover', 'politix' ),
										'content' => wp_kses(__( 'This color is applied to main menu items and menu icons on mouse hover, submenus will use the color which is set in Typography section.<br /> This option is very useful when transparent menu is set.', 'politix' ), array(
										    'br' => true,
                                        )),
									),
									'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
									'value' => POLITIX_FIRST_COLOR,
									'addrowclasses' => 'grid-col-6',
									'type' => 'text',
								),
								'shadow' => array(
									'title' => esc_html__( 'Add Shadow', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
                                    'atts' => 'checked',
								),
							),
						),

					)
				),
				'title_area_cont' => array(
					'type' => 'tab',
					'icon' => array( 'fa', 'fa-book' ),
					'title' => esc_html__( 'Title', 'politix' ),
					'layout' => array(

						'title_box' => array(
							'type' => 'fields',
							'addrowclasses' => 'inside-box groups grid-col-12 box main-box',
							'layout' => array(
								'enable' => array(
									'title' => esc_html__( 'Title area', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12 alt',
									'type' => 'checkbox',
									'atts' => 'checked',
								),							
								'no_title' => array(
									'title' => esc_html__( 'Hide Page Title', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
								),	
								'customize' => array(
									'title' => esc_html__( 'Customize', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
									'atts' => 'checked data-options="e:show_on_posts;e:show_on_archives;e:font_color;e:helper_font_color;e:helper_hover_font_color;e:background_image;e:overlay;e:use_pattern;e:effect;e:spacings;e:border;"',
								),
								'show_on_posts' => array(
									'title' => esc_html__( 'Use Custom Settings on Posts', 'politix' ),
									'addrowclasses' => 'disable checkbox grid-col-4',
									'type' => 'checkbox',
									'atts' => 'disable checked',
								),
								'show_on_archives' => array(
									'title' => esc_html__( 'Use Custom Settings on Archives', 'politix' ),
									'addrowclasses' => 'disable checkbox grid-col-6',
									'type' => 'checkbox',
									'atts' => 'disable checked',
								),
								'background_image' => array(
									'type' => 'fields',
									'addrowclasses' => 'disable box grid-col-12 inside-box groups',
									'layout' => '%image_layout%',
								),
                                'subtitle_content' => array(
                                    'title' => esc_html__( 'Subtitle Content', 'politix' ),
                                    'addrowclasses' => 'grid-col-12 full_row',
                                    'type' => 'textarea',
                                    'atts' => 'rows="2"',
                                ),
								'spacings' => array(
									'title' => esc_html__( 'Add Top/Bottom Spacings', 'politix' ),
									'type' => 'margins',
									'addrowclasses' => 'disable two-inputs grid-col-6',
									'value' => array(
										'top' => array('placeholder' => esc_html__( 'Top', 'politix' ), 'value' => '74'),
										'bottom' => array('placeholder' => esc_html__( 'Bottom', 'politix' ), 'value' => '91'),
									),
								),
								'font_color' => array(
									'title'	=> esc_html__( 'Override Title Color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'disable grid-col-6',
									'type'	=> 'text',
								),
								'helper_font_color' => array(
									'title'	=> esc_html__( 'Subtitle content/Breadcrumbs Font Color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'disable grid-col-6',
									'type'	=> 'text',
								),
								'helper_hover_font_color' => array(
									'title'	=> esc_html__( 'Breadcrumbs hover Font Color', 'politix' ),
									'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
									'value' => POLITIX_FIRST_COLOR,
									'addrowclasses' => 'disable grid-col-6',
									'type'	=> 'text',
								),
								'overlay' => array(
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 disable box inside-box groups',
									'layout' => array(
										'type'	=> array(
											'title'		=> esc_html__( 'Add Color overlay', 'politix' ),
											'addrowclasses' => 'grid-col-4',
											'type'	=> 'select',
											'source'	=> array(
												'none' => array( esc_html__( 'None', 'politix' ),  true, 'd:opacity;d:color;d:gradient;' ),
												'color' => array( esc_html__( 'Color', 'politix' ),  false, 'e:opacity;e:color;d:gradient;' ),
												'gradient' => array( esc_html__('Gradient', 'politix' ), false, 'e:opacity;d:color;e:gradient;' )
											),
										),
										'color'	=> array(
											'title'	=> esc_html__( 'Color', 'politix' ),
											'atts' => 'data-default-color="#000000"',
											'addrowclasses' => 'grid-col-4',
											'value' => '#000000',
											'type'	=> 'text',
										),
										'opacity' => array(
											'type' => 'number',
											'title' => esc_html__( 'Opacity (%)', 'politix' ),
											'placeholder' => esc_html__( 'In percents', 'politix' ),
											'value' => '55',
											'addrowclasses' => 'grid-col-4',
										),
										'gradient' => array(
											'type' => 'fields',
											'addrowclasses' => 'grid-col-12 disable box inside-box groups',
											'layout' => '%gradient_layout%',
										),
									),
								),
								'use_pattern' => array(
									'title' => esc_html__( 'Add pattern', 'politix' ),
									'addrowclasses' => 'disable checkbox grid-col-12',
									'type' => 'checkbox',
									'atts' => 'data-options="e:pattern_image;"',
								),
								'pattern_image' => array(
									'type' => 'fields',
									'title' => esc_html__( 'Pattern image', 'politix' ),
									'addrowclasses' => 'disable box grid-col-12 inside-box groups',
									'layout' => '%image_layout%',
								),
								'border' => array(
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 box inside-box groups',
									'layout' => '%border_layout%',
								),
							),
						),

					)
				),
				'top_bar_cont' => array(
					'type' => 'tab',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Top Bar', 'politix' ),
					'layout' => array(

						'top_bar_box' => array(
							'type' => 'fields',
							'addrowclasses' => 'inside-box groups grid-col-12 box main-box',
							'layout' => array(
								'enable' => array(
									'title' => esc_html__( 'Customize', 'politix' ),
									'addrowclasses' => 'grid-col-12 checkbox alt',
									'type' => 'checkbox',
                                    'atts' => 'checked',
								),
								'wide' => array(
									'title' => esc_html__( 'Apply Full-Width Top Bar', 'politix' ),
									'addrowclasses' => 'grid-col-4 checkbox',
									'type' => 'checkbox',
								),							
								'language_bar' => array(
									'title' => esc_html__( 'Add Language Bar', 'politix' ),
									'addrowclasses' => 'grid-col-4 checkbox',
									'atts' => 'checked data-options="e:language_bar_position;"',
									'type' => 'checkbox',
								),
								'social_place' => array(
									'title' => esc_html__( 'Social Icons Alignment', 'politix' ),
									'type' => 'radio',
									'subtype' => 'images',
									'addrowclasses' => 'grid-col-6',
									'value' => array(
										'left' =>array( esc_html__( 'Left', 'politix' ), false, '', '/img/social-left.png' ),
										'right' =>array( esc_html__( 'Right', 'politix' ), true, '', '/img/social-right.png' ),
									),
								),								
								'language_bar_position' => array(
									'title' => esc_html__( 'Language Bar Alignment', 'politix' ),
									'type' => 'radio',
									'subtype' => 'images',
									'addrowclasses' => 'disable grid-col-6',
									'value' => array(
										'left' => array( esc_html__( 'Left', 'politix' ), 	false, '', '/img/multilingual-left.png' ),
										'right' =>array( esc_html__( 'Right', 'politix' ), true, '', '/img/multilingual-right.png' ),
									),
								),
								'toggle_share' => array(
									'title' => esc_html__( 'Toggle Social Icons', 'politix' ),
									'addrowclasses' => 'grid-col-12 checkbox',
									'type' => 'checkbox',
								),
								'text' => array(
									'title' => esc_html__( 'Content', 'politix' ),
									'addrowclasses' => 'grid-col-8 full_row',
									'tooltip' => array(
										'title' => esc_html__( 'Indent Adjusting', 'politix' ),
										'content' => wp_kses(__( 'Adjust Indents by multiple spaces.<br /> Line breaks are working too.', 'politix' ), array(
										    'br' => true,
                                        )),
									),
									'type' => 'text'
								),
								'content_items' => array(
									'type' => 'group',
									'addrowclasses' => 'grid-col-12 group expander sortable box',
									'title' => esc_html__('Top Bar Info', 'politix' ),
									'button_title' => esc_html__('Add new info row', 'politix' ),
									'layout' => array(
										'icon' => array(
											'type' => 'select',
											'addrowclasses' => 'grid-col-3 fai',
											'source' => 'fa',
											'title' => esc_html__('Select the icon', 'politix' )
										),
										'title' => array(
											'type' => 'text',
											'atts' => 'data-role="title"',
											'addrowclasses' => 'grid-col-3',
											'title' => esc_html__('Write main info', 'politix' ),
										),
										'url' => array(
											'type' => 'text',
											'addrowclasses' => 'grid-col-3',
											'title' => esc_html__('Write URL', 'politix' ),
										),
										'link_type' => array(
											'type' => 'select',
											'addrowclasses' => 'grid-col-3 fai',
											'source' => array(
												'link' => array( esc_html__( 'Link', 'politix' ),  true, '' ),
												'mailto:' => array( esc_html__( 'Email', 'politix' ),  false, '' ),
												'skype:' => array( esc_html__( 'Skype', 'politix' ),  false, '' ),
												'tel:' => array( esc_html__( 'Phone', 'politix' ),  false, '' ),
											),
											'title' => esc_html__('Select link type', 'politix' )
										),
									),
								),
								'background_color' => array(
									'title' => esc_html__( 'Customize Background', 'politix' ),
									'atts' => 'data-default-color="' . POLITIX_SECOND_COLOR . '"',
									'value' => POLITIX_SECOND_COLOR,
									'addrowclasses' => 'new_row grid-col-3',
									'type' => 'text',
								),
								'font_color' => array(
									'title' => esc_html__( 'Font Color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'grid-col-3',
									'type' => 'text',
								),
								'hover_font_color' => array(
									'title' => esc_html__( 'Hover Color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'grid-col-3',
									'type' => 'text',
								),									
								'background_opacity' => array(
									'type' => 'number',
									'title' => esc_html__( 'Background Opacity (%)', 'politix' ),
									'placeholder' => esc_html__( 'In percents', 'politix' ),
									'value' => '100',
									'addrowclasses' => 'grid-col-3',
								),
								'border' => array(
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 box inside-box groups',
									'layout' => '%border_layout%',
								),
								'spacings' => array(
									'title' => esc_html__( 'Add Spacings (px)', 'politix' ),
									'type' => 'margins',
									'addrowclasses' => 'new_row grid-col-12 two-inputs',
									'value' => array(
										'top' => array('placeholder' => esc_html__( 'Top', 'politix' ), 'value' => '10'),
										'bottom' => array('placeholder' => esc_html__( 'Bottom', 'politix' ), 'value' => '11'),
									),
								),	
							),
						),

					)
				),
				'side_panel_cont' => array(
					'type' => 'tab',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Sidebar', 'politix' ),
					'layout' => array(

						'side_panel' => array(
							'type' => 'fields',
							'addrowclasses' => 'inside-box groups grid-col-12 box main-box',
							'layout' => array(
								'enable' => array(
									'title' => esc_html__( 'Side Panel', 'politix' ),
									'addrowclasses' => 'alt checkbox grid-col-12',
									'type' => 'checkbox',
								),	
								'place' => array(
									'title' => esc_html__( 'Menu Icon Location', 'politix' ),
									'type' => 'radio',
									'subtype' => 'images',
									'addrowclasses' => 'grid-col-6',
									'value' => array(
										'topbar_left' =>array( esc_html__( 'TopBar (Left)', 'politix' ), false, '', '/img/top-hamb-left.png' ),
										'topbar_right' => array( esc_html__( 'TopBar (Right)', 'politix' ), 	false, '', '/img/top-hamb-right.png' ),
										'menu_left' =>array( esc_html__( 'Menu (Left)', 'politix' ), false, '', '/img/hamb-left.png' ),
										'menu_right' =>array( esc_html__( 'Menu (Right)', 'politix' ), true, '', '/img/hamb-right.png' ),
									),
								),
								'position' => array(
									'title' 			=> esc_html__('Side Panel Position', 'politix' ),
									'type' 				=> 'radio',
									'subtype' 			=> 'images',
									'addrowclasses' => 'grid-col-6',
									'value' 			=> array(
										'left' 				=> 	array( esc_html__('Left', 'politix' ), true, '',	'/img/left.png' ),
										'right' 			=> 	array( esc_html__('Right', 'politix' ), false, '', '/img/right.png' ),
									),
								),
								'sidebar' => array(
									'title' 		=> esc_html__('Select the Sidebar Area', 'politix' ),
									'type' 			=> 'select',
									'addrowclasses' => 'new_row grid-col-6',
									'source' 		=> 'sidebars',
									'value'         => 'side_panel',
								),
								'appear'	=> array(
									'title'		=> esc_html__( 'Animation Format', 'politix' ),
									'type'	=> 'select',
									'addrowclasses' => 'grid-col-6',
									'source'	=> array(
										'fade' => array( esc_html__( 'Fade & Slide', 'politix' ),  true ),
										'slide' => array( esc_html__( 'Slide', 'politix' ), false ),
										'pull' => array( esc_html__( 'Pull', 'politix' ), false ),
									),
								),
								'logo' => array(
									'title' => esc_html__( 'Logo', 'politix' ),
									'type' => 'media',
									'url-atts' => 'readonly',
									'addrowclasses' => 'grid-col-6',
									'layout' => array(
										'is_high_dpi' => array(
											'title' => esc_html__( 'High-Resolution logo', 'politix' ),
											'addrowclasses' => 'checkbox',
											'type' => 'checkbox',
										),
									),
								),
								'logo_position' => array(
									'title' => esc_html__( 'Logo position', 'politix' ),
									'addrowclasses' => 'grid-col-3',
									'type' => 'radio',
									'value' => array(
										'left' => array( esc_html__( 'Left', 'politix' ),  true, '' ),
										'center' =>array( esc_html__( 'Center', 'politix' ), false,  '' ),
										'right' =>array( esc_html__( 'Right', 'politix' ), false,  '' ),
									),
								),
								'logo_dimensions' => array(
									'title' => esc_html__( 'Logo Dimensions', 'politix' ),
									'type' => 'dimensions',
									'addrowclasses' => 'grid-col-3',
									'value' => array(
										'width' => array('placeholder' => esc_html__( 'Width', 'politix' ), 'value' => ''),
										'height' => array('placeholder' => esc_html__( 'Height', 'politix' ), 'value' => ''),
									),
								),
                                'with_site_name' => array(
                                    'title' => esc_html__( 'Add Site Name to the Logo', 'politix' ),
                                    'addrowclasses' => 'checkbox grid-col-6',
                                    'type' => 'checkbox',
                                    'atts' => 'checked data-options="e:site_name_color;"'
                                ),
                                'site_name_color'	=> array(
                                    'title'	=> esc_html__( 'Site Name Color', 'politix' ),
                                    'atts' => 'data-default-color="#ffffff"',
                                    'addrowclasses' => 'disable grid-col-6',
                                    'value' => '#ffffff',
                                    'type'	=> 'text',
                                ),
								'background_image' => array(
									'title' => esc_html__( 'Background image', 'politix' ),
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 inside-box groups',
									'layout' => '%image_layout%',
								),
								'overlay' => array(
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 inside-box groups',
									'layout' => array(
										'type'	=> array(
											'title'		=> esc_html__( 'Add Color overlay', 'politix' ),
											'addrowclasses' => 'grid-col-4',
											'type'	=> 'select',
											'source'	=> array(
												'none' => array( esc_html__( 'None', 'politix' ),  false, 'd:opacity;d:color;d:gradient;' ),
												'color' => array( esc_html__( 'Color', 'politix' ),  true, 'e:opacity;e:color;d:gradient;' ),
												'gradient' => array( esc_html__('Gradient', 'politix' ), false, 'e:opacity;d:color;e:gradient;' )
											),
										),
										'color'	=> array(
											'title'	=> esc_html__( 'Color', 'politix' ),
											'atts' => 'data-default-color="#00263e"',
											'addrowclasses' => 'grid-col-4',
											'value' => '#00263e',
											'type'	=> 'text',
										),
										'opacity' => array(
											'type' => 'number',
											'title' => esc_html__( 'Opacity (%)', 'politix' ),
											'placeholder' => esc_html__( 'In percents', 'politix' ),
											'value' => '100',
											'addrowclasses' => 'grid-col-4',
										),
										'gradient' => array(
											'type' => 'fields',
											'addrowclasses' => 'grid-col-12 disable box inside-box groups',
											'layout' => '%gradient_layout%',
										),
									),
								),
								'font_color'	=> array(
									'title'	=> esc_html__( 'Font color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'addrowclasses' => 'grid-col-4',
									'value' => '#ffffff',
									'type'	=> 'text',
								),
								'font_color_hover'	=> array(
									'title'	=> esc_html__( 'Font color on Hover', 'politix' ),
									'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
									'addrowclasses' => 'grid-col-4',
									'value' => POLITIX_FIRST_COLOR,
									'type'	=> 'text',
								),
								'fixed_bg' => array(
									'title'	=> esc_html__( 'Fixed info Background', 'politix' ),
									'atts' => 'data-default-color="#00263e"',
									'addrowclasses' => 'grid-col-4',
									'value' => '#00263e',
									'type'	=> 'text',
								),
								'add_social' => array(
									'title' => esc_html__( 'Add social icon to Fixed Info Bar', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
								),
								'bottom_bar' => array(
									'type' => 'fields',
									'addrowclasses' => 'inside-box groups grid-col-12 box',
									'layout' => array(
										'info_icons' => array(
											'type' => 'group',
											'addrowclasses' => 'group sortable grid-col-12 box',
											'title' => esc_html__('Fixed Information', 'politix' ),
											'button_title' => esc_html__('Add new information row', 'politix' ),
											'button_icon' => 'fa fa-plus',
											'layout' => array(
												'title' => array(
													'type' => 'text',
													'atts' => 'data-role="title"',
													'addrowclasses' => 'grid-col-3',
													'title' => esc_html__('Title', 'politix' ),
												),
												'url' => array(
													'type' => 'text',
													'addrowclasses' => 'grid-col-3',
													'title' => esc_html__('Link', 'politix' ),
												),
												'icon' => array(
													'type' => 'select',
													'addrowclasses' => 'fai grid-col-3',
													'source' => 'fa',
													'title' => esc_html__('Icon', 'politix' )
												),
												'link_type' => array(
													'type' => 'select',
													'addrowclasses' => 'grid-col-3',
													'source' => array(
														'link' => array( esc_html__( 'Link', 'politix' ),  true, '' ),
														'mailto:' => array( esc_html__( 'Email', 'politix' ),  false, '' ),
														'skype:' => array( esc_html__( 'Skype', 'politix' ),  false, '' ),
														'tel:' => array( esc_html__( 'Phone', 'politix' ),  false, '' ),
													),
													'title' => esc_html__('Select link type', 'politix' )
												),
											)
										),																
									),
								),
							),
						),
					)
				),
			)
		),
		// end of sections
		'footer_options' => array(
			'type' => 'section',
			'title' => esc_html__('Footer', 'politix' ),
			'icon' => array('fa', 'list-alt'),
			'layout' => array(
				'footer_cont' => array(
					'type' => 'tab',
					'init' => 'open',
					'icon' => array( 'fa', 'fa-book' ),
					'title' => esc_html__( 'Footer', 'politix' ),
					'layout' => array(

						'footer' => array(
							'type' => 'fields',
							'addrowclasses' => 'inside-box groups grid-col-12 box main-box',
							'layout' => array(
								'wide' => array(
									'title' => esc_html__( 'Apply Full-Width Footer', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-12',
									'type' => 'checkbox',
								),

                                'layout' => array(
									'type' => 'select',
									'title' => esc_html__( 'Select a layout', 'politix' ),
									'addrowclasses' => 'grid-col-4',
									'source' => array(
										'1' => array( esc_html__( '1/1 Column', 'politix' ),  false ),
										'2' => array( esc_html__( '2/2 Column', 'politix' ), false ),
										'3' => array( esc_html__( '3/3 Column', 'politix' ), false ),
										'4' => array( esc_html__( '4/4 Column', 'politix' ), false ),
										'66-33' => array( esc_html__( '2/3 + 1/3 Column', 'politix' ), false ),
										'33-66' => array( esc_html__( '1/3 + 2/3 Column', 'politix' ), false ),
										'25-75' => array( esc_html__( '1/4 + 3/4 Column', 'politix' ), false ),
										'51-38-38-54-49' => array( esc_html__( '5 Columns', 'politix' ), true ),
									),
								),
								'sidebar' => array(
									'title' 		=> esc_html__('Select Footer\'s Sidebar Area', 'politix' ),
									'type' 			=> 'select',
									'addrowclasses' => 'grid-col-4',
									'source' 		=> 'sidebars',
                                    'value'         => 'footer',
								),
								'alignment' => array(
									'type' => 'select',
									'title' => esc_html__( 'Copyrights alignment', 'politix' ),
									'addrowclasses' => 'grid-col-4',
									'source' => array(
										'left' => array( esc_html__( 'Left', 'politix' ),  true ),
										'center' => array( esc_html__( 'Center', 'politix' ), false ),
										'right' => array( esc_html__( 'Right', 'politix' ), false ),
									),
								),
								'copyrights_text' => array(
									'title' => esc_html__( 'Copyrights content', 'politix' ),
									'type' => 'textarea',
									'addrowclasses' => 'grid-col-12 full_row',
									'value' => esc_html__('© 2019 WordPress theme. All Rights Reserved', 'politix'),
									'atts' => 'rows="6"',
								),
								'background_image' => array(
									'type' => 'fields',
									'addrowclasses' => 'box grid-col-12 inside-box groups',
									'layout' => '%image_layout%',
								),
								'title_color' => array(
									'title' => esc_html__( 'Widgets Title Color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'grid-col-4',
									'type' => 'text',
								),								
								'font_color' => array(
									'title' => esc_html__( 'Font Color', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'grid-col-4',
									'type' => 'text',
								),
								'font_color_hover' => array(
									'title' => esc_html__( 'Font Color on Hover', 'politix' ),
									'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
									'value' => POLITIX_FIRST_COLOR,
									'addrowclasses' => 'grid-col-4',
									'type' => 'text',
								),
								'copyrights_background_color' => array(
									'title'	=> esc_html__( 'Background Color (Copyrights)', 'politix' ),
									'atts'	=> 'data-default-color="' . POLITIX_SECOND_COLOR . '"',
									'value' => POLITIX_SECOND_COLOR,
									'addrowclasses' => 'grid-col-4',
									'type'	=> 'text'
								),
								'copyrights_font_color' => array(
									'title' => esc_html__( 'Font color (Copyrights)', 'politix' ),
									'atts' => 'data-default-color="#ffffff"',
									'value' => '#ffffff',
									'addrowclasses' => 'grid-col-4',
									'type' => 'text',
								),
								'copyrights_hover_color' => array(
									'title' => esc_html__( 'Hover color (Copyrights)', 'politix' ),
									'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
									'value' => POLITIX_FIRST_COLOR,
									'addrowclasses' => 'grid-col-4',
									'type' => 'text',
								),				
								'pattern_image' => array(
									'type' => 'fields',
									'title' => esc_html__( 'Pattern Image', 'politix' ),
									'addrowclasses' => 'box grid-col-12 inside-box groups',
									'layout' => '%image_layout%',
								),
								'overlay' => array(
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 box inside-box groups',
									'layout' => array(
										'type'	=> array(
											'title'		=> esc_html__( 'Color overlay', 'politix' ),
											'addrowclasses' => 'grid-col-4',
											'type'	=> 'select',
											'source'	=> array(
												'none' => array( esc_html__( 'None', 'politix' ),  false, 'd:opacity;d:color;d:gradient;' ),
												'color' => array( esc_html__( 'Color', 'politix' ),  true, 'e:opacity;e:color;d:gradient;' ),
												'gradient' => array( esc_html__('Gradient', 'politix' ), false, 'e:opacity;d:color;e:gradient;' )
											),
										),
										'color'	=> array(
											'title'	=> esc_html__( 'Color', 'politix' ),
											'atts' => 'data-default-color="' . POLITIX_SECOND_COLOR . '"',
											'addrowclasses' => 'grid-col-4',
											'value' => POLITIX_SECOND_COLOR,
											'type'	=> 'text',
											'customizer' => array( 'show' => true )
										),
										'opacity' => array(
											'type' => 'number',
											'title' => esc_html__( 'Opacity (%)', 'politix' ),
											'placeholder' => esc_html__( 'In percents', 'politix' ),
											'value' => '100',
											'addrowclasses' => 'grid-col-4',
										),
										'gradient' => array(
											'type' => 'fields',
											'addrowclasses' => 'grid-col-12 disable box inside-box groups',
											'layout' => '%gradient_layout%',
										),
									),
								),
								'border' => array(
									'type' => 'fields',
									'addrowclasses' => 'grid-col-12 box inside-box groups',
									'layout' => '%border_layout%',
								),
								'instagram_feed' => array(
									'title' => esc_html__( 'Add Instagram Feed', 'politix' ),
									'addrowclasses' => 'checkbox grid-col-6',
									'type' => 'checkbox',
									'atts' => 'data-options="e:instagram_feed_shortcode;e:instagram_feed_full_width;"',
								),
								'instagram_feed_full_width' => array(
									'title' => esc_html__( 'Apply Full-Width Feed', 'politix' ),
									'addrowclasses' => 'disable checkbox grid-col-12',
									'type' => 'checkbox',
								),							
								'instagram_feed_shortcode' => array(
									'title' => esc_html__( 'Instagram Shortcode', 'politix' ),
									'addrowclasses' => 'disable grid-col-12 full_row',
									'type' => 'textarea',
									'atts' => 'rows="3"',
									'default' => '',
									'value' => '[instagram-feed cols=8 num=8 imagepadding=0 imagepaddingunit=px showheader=false showbutton=true showfollow=true]'
								),
								'spacings' => array(
									'title' => esc_html__( 'Add Spacings (px)', 'politix' ),
									'type' => 'margins',
									'addrowclasses' => 'new_row grid-col-12 two-inputs',
									'value' => array(
										'top' => array('placeholder' => esc_html__( 'Top', 'politix' ), 'value' => '75'),
										'bottom' => array('placeholder' => esc_html__( 'Bottom', 'politix' ), 'value' => '0'),
									),
								),	

							),
						),
					),
				),	
			)
		),	// end of sections

		'styling_options' => array(
			'type' => 'section',
			'title' => esc_html__('Styling options', 'politix' ),
			'icon' => array('fa', 'paint-brush'),
			'layout' => array(
				'theme_colors' => array(
					'type' => 'tab',
					'init' => 'open',
					'icon' => array('fa', 'calendar-plus-o'),
					'title' => esc_html__( 'Theme colors', 'politix' ),
					'layout' => array(
						'theme_first_color' => array(
							'title' => esc_html__( 'Theme Main color', 'politix' ),
							'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
							'value' => POLITIX_FIRST_COLOR,
							'addrowclasses' => 'grid-col-4',
							'type' => 'text',
						),						
						'theme_second_color' => array(
							'title' => esc_html__( 'Theme Second Color', 'politix' ),
							'atts' => 'data-default-color="' . POLITIX_SECOND_COLOR . '"',
							'value' => POLITIX_SECOND_COLOR,
							'addrowclasses' => 'grid-col-4',
							'type' => 'text',
						),
					)
				)
			),
		),	// end of sections

		'layout_options' => array(
			'type' => 'section',
			'title' => esc_html__('Page layouts', 'politix' ),
			'icon' => array('fa', 'columns'),
			'layout'	=> array(
				'layout_options_homepage'	=> array(
					'type' => 'tab',
					'init'	=> 'open',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Home', 'politix' ),
					'layout' => array(
						'home-slider-type' => array(
							'title' => esc_html__('Slider', 'politix' ),
							'type' => 'radio',
							'value' => array(
								'none' => 	array( esc_html__('None', 'politix' ), true, 'd:home-header-slider-options;d:slidersection-start;d:static_img_section' ),
								'img-slider'=>	array( esc_html__('Image Slider', 'politix' ), false, 'e:home-header-slider-options;d:slidersection-start;d:static_img_section' ),
								'video-slider' => 	array( esc_html__('Video Slider', 'politix' ), false, 'd:home-header-slider-options;e:slidersection-start;d:static_img_section' ),
								'stat-img-slider' => 	array( esc_html__('Static image', 'politix' ), false, 'd:home-header-slider-options;d:slidersection-start;e:static_img_section' ),
							),
						),
						'home-header-slider-options' => array(
							'title' => esc_html__( 'Slider shortcode', 'politix' ),
							'addrowclasses' => 'disable',
							'type' => 'text',
							'value' => '[rev_slider homepage]',
						),
						'slidersection-start' => array(
							'title' => esc_html__( 'Video Slider Setting', 'politix' ),
							'type' => 'fields',
							'addrowclasses' => 'disable groups',
							'layout' => array(
								'slider_switch' => array(
									'title' => esc_html__( 'Slider', 'politix' ),
									'addrowclasses' => 'grid-col-12 checkbox',
									'type' => 'checkbox',
									'atts' => 'data-options="e:slider_shortcode;"',
								),
								'slider_shortcode' => array(
									'title' => esc_html__( 'Slider shortcode', 'politix' ),
									'addrowclasses' => 'grid-col-12 disable box',
									'type' => 'text',
								),
								'set_video_header_height' => array(
									'title' => esc_html__( 'Set Video height', 'politix' ),
									'type' => 'checkbox',
									'addrowclasses' => 'grid-col-12 checkbox',
									'atts' => 'data-options="e:video_header_height"',
								),
								'video_header_height' => array(
									'title' => esc_html__( 'Video height', 'politix' ),
									'addrowclasses' => 'grid-col-12 disable box',
									'type' => 'number',
									'value' => '600',
								),
								'video_type' => array(
									'title' => esc_html__('Video type', 'politix' ),
									'addrowclasses' => 'grid-col-12',
									'type' => 'radio',
									'value' => array(
										'self_hosted' => 	array( esc_html__('Self-hosted', 'politix' ), true, 'e:sh_source;d:youtube_source;d:vimeo_source' ),
										'youtube'=>	array( esc_html__('Youtube clip', 'politix' ), false, 'd:sh_source;e:youtube_source;d:vimeo_source' ),
										'vimeo' => 	array( esc_html__('Vimeo clip', 'politix' ), false, 'd:sh_source;d:youtube_source;e:vimeo_source' ),
									),
								),
								'sh_source' => array(
									'title' => esc_html__( 'Add video', 'politix' ),
									'addrowclasses' => 'grid-col-12 box',
									'url-atts' => 'readonly',
									'type' => 'media',
								),
								'youtube_source' => array(
									'title' => esc_html__( 'Youtube video code', 'politix' ),
									'addrowclasses' => 'grid-col-12 disable box',
									'type' => 'text',
								),
								'vimeo_source' => array(
									'title' => esc_html__( 'Vimeo embed url', 'politix' ),
									'addrowclasses' => 'grid-col-12 disable box',
									'type' => 'text',
								),
								'color_overlay_type' => array(
									'title' => esc_html__( 'Overlay', 'politix' ),
									'addrowclasses' => 'grid-col-4',
									'type' => 'select',
									'source' => array(
										'none' => array( esc_html__( 'None', 'politix' ), 	true, 'd:overlay_color;d:slider_gradient_settings;d:color_overlay_opacity;'),
										'color' => array( esc_html__( 'Color', 'politix' ), 	false, 'e:overlay_color;d:slider_gradient_settings;e:color_overlay_opacity;'),
										'gradient' =>array( esc_html__( 'Gradient', 'politix' ), false, 'd:overlay_color;e:slider_gradient_settings;e:color_overlay_opacity;'),
									),
								),
								'overlay_color' => array(
									'title' => esc_html__( 'Color', 'politix' ),
									'addrowclasses' => 'grid-col-12',
									'atts' => 'data-default-color=""',
									'addrowclasses' => 'box',
									'type' => 'text',
								),
								'color_overlay_opacity' => array(
									'type' => 'number',
									'addrowclasses' => 'grid-col-4 box',
									'title' => esc_html__( 'Opacity', 'politix' ),
									'placeholder' => esc_attr__( 'In percents', 'politix' ),
									'value' => '40'
								),
								'slider_gradient_settings' => array(
									'title' => esc_html__( 'Gradient settings', 'politix' ),
									'addrowclasses' => 'grid-col-12',
									'type' => 'fields',
									'addrowclasses' => 'disable box groups',
									'layout' => array(
										'first_color' => array(
											'type' => 'text',
											'addrowclasses' => 'grid-col-6',
											'title' => esc_html__( 'From', 'politix' ),
											'atts' => 'data-default-color=""',
										),
										'second_color' => array(
											'type' => 'text',
											'addrowclasses' => 'grid-col-6',
											'title' => esc_html__( 'To', 'politix' ),
											'atts' => 'data-default-color=""',
										),
										'first_color_opacity' => array(
											'type' => 'number',
											'addrowclasses' => 'grid-col-6',
											'title' => esc_html__( 'From (Opacity %)', 'politix' ),
											'value' => '100',
										),
										'second_color_opacity' => array(
											'type' => 'number',
											'addrowclasses' => 'grid-col-6',
											'title' => esc_html__( 'To (Opacity %)', 'politix' ),
											'value' => '100',
										),
										'type' => array(
											'title' => esc_html__( 'Gradient type', 'politix' ),
											'addrowclasses' => 'grid-col-12',
											'type' => 'radio',
											'value' => array(
												'linear' => array( esc_html__( 'Linear', 'politix' ),  true, 'e:linear_settings;d:radial_settings' ),
												'radial' =>array( esc_html__( 'Radial', 'politix' ), false,  'd:linear_settings;e:radial_settings' ),
											),
										),
										'linear_settings' => array(
											'title' => esc_html__( 'Linear settings', 'politix'  ),
											'type' => 'fields',
											'addrowclasses' => 'disable',
											'layout' => array(
												'angle' => array(
													'type' => 'number',
													'title' => esc_html__( 'Angle', 'politix' ),
													'value' => '45',
												),
											)
										),
										'radial_settings' => array(
											'title' => esc_html__( 'Radial settings', 'politix'  ),
											'type' => 'fields',
											'addrowclasses' => 'disable',
											'layout' => array(
												'shape_settings' => array(
													'title' => esc_html__( 'Shape', 'politix' ),
													'type' => 'radio',
													'value' => array(
														'simple' => array( esc_html__( 'Simple', 'politix' ),  true, 'e:shape;d:size;d:size_keyword;' ),
														'extended' =>array( esc_html__( 'Extended', 'politix' ), false, 'd:shape;e:size;e:size_keyword;' ),
													),
												),
												'shape' => array(
													'title' => esc_html__( 'Gradient type', 'politix' ),
													'type' => 'radio',
													'value' => array(
														'ellipse' => array( esc_html__( 'Ellipse', 'politix' ),  true ),
														'circle' =>array( esc_html__( 'Circle', 'politix' ), false ),
													),
												),
												'size_keyword' => array(
													'type' => 'select',
													'title' => esc_html__( 'Size keyword', 'politix' ),
													'addrowclasses' => 'disable',
													'source' => array(
														'closest-side' => array(esc_html__( 'Closest side', 'politix' ), false),
														'farthest-side' => array(esc_html__( 'Farthest side', 'politix' ), false),
														'closest-corner' => array(esc_html__( 'Closest corner', 'politix' ), false),
														'farthest-corner' => array(esc_html__( 'Farthest corner', 'politix' ), true),
													),
												),
												'size' => array(
													'type' => 'text',
													'addrowclasses' => 'disable',
													'title' => esc_html__( 'Size', 'politix' ),
													'atts' => 'placeholder="'.esc_attr__( 'Two space separated percent values, for example (60% 55%)', 'politix' ).'"',
												),
											)
										)

									),
								),
								'use_pattern' => array(
									'title' => esc_html__( 'Use pattern image', 'politix' ),
									'type' => 'checkbox',
									'addrowclasses' => 'grid-col-12 checkbox',
									'atts' => 'data-options="e:pattern_image"',
								),
								'pattern_image' => array(
									'title' => esc_html__( 'Pattern image', 'politix' ),
									'addrowclasses' => 'grid-col-12 disable box',
									'url-atts' => 'readonly',
									'type' => 'media',
								),
							),
						),// end of video-section
						'static_img_section' => array(
							'title' => esc_html__( 'Static image Slider Setting', 'politix' ),
							'type' => 'fields',
							'addrowclasses' => 'groups',
							'layout' => array(
								'home_header_image_options' => array(
									'title' => esc_html__( 'Static image', 'politix' ),
									'type' => 'media',
									'url-atts' => 'readonly',
									'layout' => array(
										'is_high_dpi' => array(
											'title' => esc_html__( 'High-Resolution image', 'politix' ),
											'type' => 'checkbox',
											'addrowclasses' => 'checkbox',
										),
									),
								),
								'set_static_image_height' => array(
									'title' => esc_html__( 'Set Image height', 'politix' ),
									'addrowclasses' => 'grid-col-12 checkbox',
									'type' => 'checkbox',
									'atts' => 'data-options="e:static_image_height;"',
								),
								'static_image_height' => array(
									'title' => esc_html__( 'Static Image Height', 'politix' ),
									'addrowclasses' => 'grid-col-12 disable box',
									'type' => 'number',
									'default' => '600',
								),
								'static_customize_colors' => array(
									'title' => esc_html__( 'Customize colors', 'politix' ),
									'addrowclasses' => 'grid-col-12 checkbox',
									'type' => 'checkbox',
									'atts' => 'data-options="e:img_header_color_overlay_type;e:img_header_overlay_color;e:img_header_color_overlay_opacity;"',
								),
								'img_header_color_overlay_type'	=> array(
									'title'		=> esc_html__( 'Color overlay type', 'politix' ),
									'type'	=> 'select',
									'addrowclasses' => 'grid-col-12 box disable',
									'source'	=> array(
										'color' => array( esc_html__( 'Color', 'politix' ),  true, 'e:img_header_overlay_color;d:img_header_gradient_settings;' ),
										'gradient' => array( esc_html__( 'Gradient', 'politix' ), false, 'd:img_header_overlay_color;e:img_header_gradient_settings;' )
									),
								),
								'img_header_overlay_color'	=> array(
									'title'	=> esc_html__( 'Overlay color', 'politix' ),
									'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
									'value' => POLITIX_FIRST_COLOR,
									'addrowclasses' => 'box disable',
									'type'	=> 'text',
								),
								'img_header_gradient_settings' => array(
									'title' => esc_html__( 'Gradient Settings', 'politix' ),
									'type' => 'fields',
									'addrowclasses' => 'disable box groups',
									'layout' => array(
										'first_color' => array(
											'type' => 'text',
											'title' => esc_html__( 'From', 'politix' ),
											'atts' => 'data-default-color=""',
										),
										'second_color' => array(
											'type' => 'text',
											'title' => esc_html__( 'To', 'politix' ),
											'atts' => 'data-default-color=""',
										),
										'first_color_opacity' => array(
											'type' => 'number',
											'title' => esc_html__( 'From (Opacity %)', 'politix' ),
											'value' => '100',
										),
										'second_color_opacity' => array(
											'type' => 'number',
											'title' => esc_html__( 'To (Opacity %)', 'politix' ),
											'value' => '100',
										),
										'type' => array(
											'title' => esc_html__( 'Gradient type', 'politix' ),
											'type' => 'radio',
											'value' => array(
												'linear' => array( esc_html__( 'Linear', 'politix' ),  true, 'e:img_header_gradient_linear_settings;d:img_header_gradient_radial_settings' ),
												'radial' =>array( esc_html__( 'Radial', 'politix' ), false,  'd:img_header_gradient_linear_settings;e:img_header_gradient_radial_settings' ),
											),
										),
										'linear_settings' => array(
											'title' => esc_html__( 'Linear settings', 'politix'  ),
											'type' => 'fields',
											'addrowclasses' => 'disable',
											'layout' => array(
												'angle' => array(
													'type' => 'number',
													'title' => esc_html__( 'Angle', 'politix' ),
													'value' => '45',
												),
											)
										),
										'radial_settings' => array(
											'title' => esc_html__( 'Radial settings', 'politix'  ),
											'type' => 'fields',
											'addrowclasses' => 'disable',
											'layout' => array(
												'shape_settings' => array(
													'title' => esc_html__( 'Shape', 'politix' ),
													'type' => 'radio',
													'value' => array(
														'simple' => array( esc_html__( 'Simple', 'politix' ),  true, 'e:img_header_gradient_shape;d:img_header_gradient_size;d:img_header_gradient_size_keyword;' ),
														'extended' =>array( esc_html__( 'Extended', 'politix' ), false, 'd:img_header_gradient_shape;e:img_header_gradient_size;e:img_header_gradient_size_keyword;' ),
													),
												),
												'shape' => array(
													'title' => esc_html__( 'Gradient type', 'politix' ),
													'type' => 'radio',
													'value' => array(
														'ellipse' => array( esc_html__( 'Ellipse', 'politix' ),  true ),
														'circle' =>array( esc_html__( 'Circle', 'politix' ), false ),
													),
												),
												'img_header_gradient_size_keyword' => array(
													'type' => 'select',
													'title' => esc_html__( 'Size keyword', 'politix' ),
													'addrowclasses' => 'disable',
													'source' => array(
														'closest-side' => array(esc_html__( 'Closest side', 'politix' ), false),
														'farthest-side' => array(esc_html__( 'Farthest side', 'politix' ), false),
														'closest-corner' => array(esc_html__( 'Closest corner', 'politix' ), false),
														'farthest-corner' => array(esc_html__( 'Farthest corner', 'politix' ), true),
													),
												),
												'img_header_gradient_size' => array(
													'type' => 'text',
													'addrowclasses' => 'disable',
													'title' => esc_html__( 'Size', 'politix' ),
													'atts' => 'placeholder="'.esc_attr__( 'Two space separated percent values, for example (60% 55%)', 'politix' ).'"',
												),
											)
										)
									)
								),
								'img_header_color_overlay_opacity' => array(
									'type' => 'number',
									'title' => esc_html__( 'Opacity', 'politix' ),
									'addrowclasses' => 'box disable',
									'placeholder' => esc_attr__( 'In percents', 'politix' ),
									'value' => '40'
								),
								'img_header_use_pattern' => array(
									'title' => esc_html__( 'Add pattern', 'politix' ),
									'addrowclasses' => 'grid-col-12 checkbox',
									'type' => 'checkbox',
									'atts' => 'data-options="e:img_header_pattern_image;"',
								),
								'img_header_pattern_image' => array(
									'title' => esc_html__( 'Pattern image', 'politix' ),
									'type' => 'media',
									'addrowclasses' => 'grid-col-12 disable box',
									'url-atts' => 'readonly',
								),
								'img_header_parallaxify' => array(
									'title' => esc_html__( 'Parallaxify image', 'politix' ),
									'addrowclasses' => 'grid-col-12 checkbox',
									'type' => 'checkbox',
									'atts' => 'data-options="e:img_header_parallax_options;"',
								),
								'img_header_parallax_options' => array(
									'title' => esc_html__( 'Parallax options', 'politix' ),
									'type' => 'fields',
									'addrowclasses' => 'disable box groups',
									'layout' => array(
										'img_header_scalar-x' => array(
											'type' => 'number',
											'title' => esc_html__( 'x-axis parallax intensity', 'politix' ),
											'placeholder' => esc_attr__( 'Integer', 'politix' ),
											'value' => '2'
										),
										'img_header_scalar-y' => array(
											'type' => 'number',
											'title' => esc_html__( 'y-axis parallax intensity', 'politix' ),
											'placeholder' => esc_attr__( 'Integer', 'politix' ),
											'value' => '2'
										),
										'img_header_limit-x' => array(
											'type' => 'number',
											'title' => esc_html__( 'Maximum x-axis shift', 'politix' ),
											'placeholder' => esc_attr__( 'Integer', 'politix' ),
											'value' => '15'
										),
										'img_header_limit-y' => array(
											'type' => 'number',
											'title' => esc_html__( 'Maximum y-axis shift', 'politix' ),
											'placeholder' => esc_attr__( 'Integer', 'politix' ),
											'value' => '15'
										),
									),
								),
							),
						),// end of static img slider-section
						'home_sidebars' => array(
							'title' => esc_html__( 'Home Page Sidebar Layout', 'politix' ),
							'type' => 'fields',
							'addrowclasses' => 'box inside-box groups',
							'layout' => array(
								'layout' => array(
									'title' => esc_html__('Sidebar Position', 'politix' ),
									'type' => 'radio',
									'addrowclasses' => 'grid-col-12',
									'subtype' => 'images',
									'value' => array(
										'left' => 	array( esc_html__('Left', 'politix' ), false, 'e:sb1;d:sb2',	'/img/left.png' ),
										'right' => 	array( esc_html__('Right', 'politix' ), false, 'e:sb1;d:sb2', '/img/right.png' ),
										'both' => 	array( esc_html__('Double', 'politix' ), false, 'e:sb1;e:sb2', '/img/both.png' ),
										'none' => 	array( esc_html__('None', 'politix' ), true, 'd:sb1;d:sb2', '/img/none.png' )
									),
								),
								'sb1' => array(
									'title' => esc_html__('Select a sidebar', 'politix' ),
									'type' => 'select',
									'addrowclasses' => 'grid-col-12 disable box clear',
									'source' => 'sidebars',
								),
								'sb2' => array(
									'title' => esc_html__('Select right sidebar', 'politix' ),
									'type' => 'select',
									'addrowclasses' => 'grid-col-12 disable box',
									'source' => 'sidebars',
								),
							),
						),
					)
				),
				'layout_options_page' => array(
					'type' => 'tab',
					'icon' => array( 'fa', 'fa-book' ),
					'title' => esc_html__( 'Page', 'politix' ),
					'layout' => array(
						'page_sidebars' => array(
							'title' => esc_html__( 'Page Sidebar Layout', 'politix' ),
							'type' => 'fields',
							'addrowclasses' => 'box inside-box groups',
							'layout' => array(
								'layout' => array(
									'type' => 'radio',
									'subtype' => 'images',
									'value' => array(
										'left' => 	array( esc_html__('Left', 'politix' ), false, 'e:sb1;d:sb2', '/img/left.png' ),
										'right' => 	array( esc_html__('Right', 'politix' ), false, 'e:sb1;d:sb2', '/img/right.png' ),
										'both' => 	array( esc_html__('Double', 'politix' ), false, 'e:sb1;e:sb2', '/img/both.png' ),
										'none' => 	array( esc_html__('None', 'politix' ), true, 'd:sb1;d:sb2', '/img/none.png' )
									),
								),
								'sb1' => array(
									'title' => esc_html__('Select a sidebar', 'politix' ),
									'type' => 'select',
									'addrowclasses' => 'disable box',
									'source' => 'sidebars',
								),
								'sb2' => array(
									'title' => esc_html__('Select right sidebar', 'politix' ),
									'type' => 'select',
									'addrowclasses' => 'disable box',
									'source' => 'sidebars',
								),
							),
						),
						'boxed' => array(
							'title' => esc_html__( 'Enable Boxed Layout', 'politix' ),
							'addrowclasses' => 'checkbox alt',
							'type' => 'checkbox',
							'atts' => 'data-options="e:boxed_background"',
						),
						'boxed_background' => array(
							'title' => esc_html__( 'Background Settings', 'politix' ),
							'type' => 'info',
							'icon' => array('fa', 'calendar-plus-o'),
							'addrowclasses'	=> 'disable',
							'value' => '<a href="'.esc_url(get_admin_url(null, 'customize.php?autofocus[control]=background_image')).'" target="_blank">'.esc_html__('Click this link to customize your background settings','politix').'</a>',
						),
					)
				),
				'layout_options_blog' => array(
					'type' => 'tab',
					'icon' => array( 'fa', 'fa-book' ),
					'title' => esc_html__( 'Blog', 'politix' ),
					'layout' => array(
						'blog_sidebars' => array(
							'title' => esc_html__( 'Blog Sidebars Settings', 'politix' ),
							'type' => 'fields',
							'addrowclasses' => 'box inside-box groups grid-col-12',
							'layout' => array(
								'layout' => array(
									'title' => esc_html__('Sidebar Position', 'politix' ),
									'type' => 'radio',
									'subtype' => 'images',
									'addrowclasses' => 'grid-col-4',
									'value' => array(
										'left' => 	array( esc_html__('Left', 'politix' ), false, 'e:sb1;d:sb2',	'/img/left.png' ),
										'right' => 	array( esc_html__('Right', 'politix' ), true, 'e:sb1;d:sb2', '/img/right.png' ),
										'both' => 	array( esc_html__('Double', 'politix' ), false, 'e:sb1;e:sb2', '/img/both.png' ),
										'none' => 	array( esc_html__('None', 'politix' ), false, 'd:sb1;d:sb2', '/img/none.png' )
									),
								),
								'sb1' => array(
									'title' => esc_html__('Select a sidebar', 'politix' ),
									'type' => 'select',
									'addrowclasses' => 'disable grid-col-4',
									'source' => 'sidebars',
                                    'value' => 'blog_right'
								),
								'sb2' => array(
									'title' => esc_html__('Select right sidebar', 'politix' ),
									'type' => 'select',
									'addrowclasses' => 'disable grid-col-4',
									'source' => 'sidebars',
								),
							),
						),					
						'blog_button_name' => array(
							'title' => esc_html__( 'Button Name', 'politix' ),
							'type' => 'text',
							'value' => 'Read More',
							'addrowclasses' => 'grid-col-6',	
						),
						'def_blog_chars_count' => array(
							'title' => esc_html__( 'Text Length', 'politix' ),
							'type' => 'text',
							'addrowclasses' => 'grid-col-6',
						),						
						'def_blogtype' => array(
							'title'		=> esc_html__( 'Blog Layout', 'politix' ),
							'desc'		=> esc_html__( 'Default Blog Layout', 'politix' ),
							'type'		=> 'radio',
							'subtype' => 'images',
							'addrowclasses' => 'grid-col-6',
							'value' => array(
								'1' => array( esc_html__('Large', 'politix' ), true, '', '/img/large.png'),
								'medium' => array( esc_html__('Medium', 'politix' ), false, '', '/img/medium.png'),
								'small' => array( esc_html__('Small', 'politix' ), false, '', '/img/small.png'),
								'2' => array( esc_html__('2 Cols', 'politix' ), false, '', '/img/pinterest_2_columns.png'),
								'3' => array( esc_html__('3 Cols', 'politix' ), false, '', '/img/pinterest_3_columns.png'),
								'4' => array( esc_html__('4 Cols', 'politix' ), false, '', '/img/pinterest_4_columns.png'),
							),
						),
						'blog_slug' => array(
							'title' => esc_html__( 'Rename Blog', 'politix' ),
							'addrowclasses' => 'requirement grid-col-6',
							'type' 	=> 'text',
							'value'	=> esc_html__('Blog', 'politix'),
						),
						'def_post_hide_meta_related_items'	=> array(
							'title'		=> esc_html__( 'Hide meta (Related Items)', 'politix' ),
							'type'		=> 'select',
							'atts'		=> 'multiple',
							'addrowclasses' => 'grid-col-12',
							'source'		=> array(
								'' 				=> array( esc_html__( 'None', 'politix' ), false),
								'title' 		=> array( esc_html__( 'Title', 'politix' ), false),
								'cats' 			=> array( esc_html__( 'Categories', 'politix' ), false),
								'tags' 			=> array( esc_html__( 'Tags', 'politix' ), true),
								'author' 		=> array( esc_html__( 'Author', 'politix' ), true),
								'likes' 		=> array( esc_html__( 'Likes', 'politix' ), false),
								'date' 			=> array( esc_html__( 'Date', 'politix' ), false),
								'comments' 		=> array( esc_html__( 'Comments', 'politix' ), false),
								'read_more' 	=> array( esc_html__( 'Read More', 'politix' ), true),
								'excerpt' 		=> array( esc_html__( 'Excerpt', 'politix' ), false),
							)
						),				
					)
				),
				'layout_options_portfolio' => array(
					'type' => 'tab',
					'icon' => array( 'fa', 'fa-book' ),
					'title' => esc_html__( 'Portfolio', 'politix' ),
					'layout' => array(
						'def_layout_portfolio' => array(
							'title'		=> esc_html__( 'Portfolio Layout', 'politix' ),
							'type'		=> 'radio',
							'subtype' => 'images',
							'tooltip' => array(
								'title' => esc_html__( 'Portfolio Layout', 'politix' ),
								'content' => esc_html__( 'This option is applied to portfolio archive pages only', 'politix' ),
							),
							'value' => array(
								'1' => array( esc_html__('Large', 'politix' ), false, '', '/img/large.png'),
								'2' => array( esc_html__('2 Cols', 'politix' ), false, '', '/img/pinterest_2_columns.png'),
								'3' => array( esc_html__('3 Cols', 'politix' ), true, '', '/img/pinterest_3_columns.png'),
								'4' => array( esc_html__('4 Cols', 'politix' ), false, '', '/img/pinterest_4_columns.png'),
							),
						),
						'portfolio_mode' => array(
							'title' => esc_html__( 'Display as', 'politix' ),
							'type' => 'select',
							'source' => array(
								'grid' => array('Grid', true), // Title, isselected, data-options
								'grid_with_filter' => array( esc_html__( 'Grid with filter', 'politix' ), false ),
                                'filter_with_ajax' => array( esc_html__( 'Grid with filter(Ajax)', 'politix' ), false ),
								'carousel' => array( esc_html__( 'Carousel', 'politix'), false )
							),
						),
						'def_cws_portfolio_data_to_show'	=> array(
							'title'		=> esc_html__( 'Show Meta Data', 'politix' ),
							'type'		=> 'select',
							'atts'		=> 'multiple',
							'source'		=> array(
									'title'		=> array( esc_html__( 'Title', 'politix' ), true ),
									'excerpt'	=> array( esc_html__( 'Excerpt', 'politix' ), false ),
									'cats'		=> array( esc_html__( 'Categories', 'politix' ), false )
							)
						),
						'portfolio_pagination_style' => array(
							'title' => esc_html__( 'Pagination style', 'politix' ),
							'type' => 'radio',
							'value' => array(
								'paged' => array( esc_html__('Paged', 'politix'), false ),
								'load_more' => array( esc_html__('Load More', 'politix'), true )
							),
						),
						'portfolio_slug' => array(
							'title' => esc_html__( 'Portfolio slug', 'politix' ),
							'type' => 'text',
							'value' => 'portfolio',
						),
					)
				),
				'layout_options_staff' => array(
					'type' => 'tab',
					'icon' => array( 'fa', 'fa-book' ),
					'title' => esc_html__( 'Staff', 'politix' ),
					'layout' => array(
						'def_cws_staff_layout' => array(
							'title'		=> esc_html__( 'Staff Layout', 'politix' ),
							'type'		=> 'radio',
							'subtype' => 'images',
							'tooltip' => array(
								'title' => esc_html__( 'Staff Layout', 'politix' ),
								'content' => esc_html__( 'This option is applied to Staff archive pages only', 'politix' ),
							),
							'value' => array(
								'1' => array( esc_html__('Large', 'politix' ), false, '', '/img/large.png'),
								'2' => array( esc_html__('2 Cols', 'politix' ), false, '', '/img/pinterest_2_columns.png'),
								'3' => array( esc_html__('3 Cols', 'politix' ), false, '', '/img/pinterest_3_columns.png'),
								'4' => array( esc_html__('4 Cols', 'politix' ), true, '', '/img/pinterest_4_columns.png'),
							),
						),
						'staff_sidebars' => array(
							'title' => esc_html__( 'Staff Sidebars Settings', 'politix' ),
							'type' => 'fields',
							'addrowclasses' => 'box inside-box groups',
							'layout' => array(
								'layout' => array(
									'title' => esc_html__( 'Sidebar Position', 'politix' ),
									'type' => 'radio',
									'subtype' => 'images',
									'addrowclasses' => 'grid-col-4',
									'value' => array(
										'left' => 	array( esc_html__('Left', 'politix' ), false, 'e:sb1;d:sb2', '/img/left.png' ),
										'right' => 	array( esc_html__('Right', 'politix' ), false, 'e:sb1;d:sb2', '/img/right.png' ),
										'both' => 	array( esc_html__('Double', 'politix' ), false, 'e:sb1;e:sb2', '/img/both.png' ),
										'none' => 	array( esc_html__('None', 'politix' ), true, 'd:sb1;d:sb2', '/img/none.png' )
									),
								),
								'sb1' => array(
									'title' => esc_html__('Select a sidebar', 'politix' ),
									'type' => 'select',
									'addrowclasses' => 'disable grid-col-4',
									'source' => 'sidebars',
								),
								'sb2' => array(
									'title' => esc_html__('Select right sidebar', 'politix' ),
									'type' => 'select',
									'addrowclasses' => 'disable grid-col-4',
									'source' => 'sidebars',
								),
							),
						),
						'def_cws_staff_data_to_hide' => array(
							'title'		=> esc_html__( 'Hide Meta Data', 'politix' ),
							'type'		=> 'select',
							'atts'		=> 'multiple',
							'source'		=> array(
								'deps'			=> array( esc_html__( 'Departments', 'politix' ), true ),
								'poss'			=> array( esc_html__( 'Positions', 'politix' ), false ),
								'excerpt'		=> array( esc_html__( 'Excerpt', 'politix' ), true ),
								'experience'	=> array( esc_html__( 'Experience', 'politix' ), true ),
								'email'			=> array( esc_html__( 'Email', 'politix' ), true ),
								'tel'			=> array( esc_html__( 'Tel', 'politix' ), true ),
								'biography'		=> array( esc_html__( 'Biography', 'politix' ), true ),
								'link_button'	 => array( esc_html__( 'Link Button', 'politix' ), true ),
								'socials'		=> array( esc_html__( 'Social Links', 'politix' ), false )
							)
						),
						'staff_slug' => array(
							'title' => esc_html__( 'Staff slug', 'politix' ),
							'type' => 'text',
							'value' => 'staff',
						),

					)
				),
				'layout_options_sidebar_generator' => array(
					'type' => 'tab',
					'customizer' 	=> array( 'show' => false ),
					'icon' => array('fa', 'calendar-plus-o'),
					'title' => esc_html__( 'Sidebars', 'politix' ),
					'layout' => array(
						'sidebars' => array(
							'type' => 'group',
							'addrowclasses' => 'group single_field requirement',
							'title' => esc_html__('Sidebar generator', 'politix' ),
							'button_title' => esc_html__('Add new sidebar', 'politix' ),
							'value' => array(
									array('title' => 'Footer'),
									array('title' => 'Blog Right'),
									array('title' => 'Blog Left'),
									array('title' => 'Page Right'),
									array('title' => 'Page Left'),
									array('title' => 'Side Panel'),
									array('title' => 'WooCommerce'),
							),
							'layout' => array(
								'title' => array(
									'type' => 'text',
									'value' => 'New Sidebar',
									'atts' => 'data-role="title"',
									'verification' => array (
										'length' => array( array('!0'), esc_html__('Title should not be empty', 'politix' )),
									),
									'title' => esc_html__('Sidebar', 'politix' ),
								)
							)
						),
						'sticky_sidebars' => array(
							'title' => esc_html__( 'Sticky sidebars', 'politix' ),
							'addrowclasses' => 'checkbox alt',
							'atts' => 'checked',
							'type' => 'checkbox',
						)
					)
				),
			)
		),	// end of sections
		'typography_options' => array(
			'type' => 'section',
			'title' => esc_html__('Typography', 'politix' ),
			'icon' => array('fa', 'font'),
			'layout' => array(
				'menu_font_options' => array(
					'type' => 'tab',
					'init' => 'open',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Menu', 'politix' ),
					'layout' => array(
						'menu-font' => array(
							'title' => esc_html__('Menu Font', 'politix' ),
							'type' => 'font',
							'font-color' => true,
							'font-size' => true,
							'font-sub' => true,
							'line-height' => true,
							'value' => array(
								'font-size' => '18px',
								'line-height' => '27px',
								'color' => '#4c4c4d',
								'font-family' => 'Roboto',
								'font-weight' => array( 'regular', 'italic'),
								'font-sub' => array('latin'),
							)
						)
					)
				),
				'header_font_options' => array(
					'type' => 'tab',
					'icon' => array('fa', 'font'),
					'title' => esc_html__( 'Header', 'politix' ),
					'layout' => array(
						'header-font' => array(
							'title' => esc_html__('Header\'s Font', 'politix' ),
							'type' => 'font',
							'font-color' => true,
							'font-size' => true,
							'font-sub' => true,
							'line-height' => true,
							'value' => array(
								'font-size' => '82px',
								'line-height' => '94px',
								'color' => '#000000',
								'font-family' => 'Unna',
								'font-weight' => array( 'regular', 'italic', '700', '700italic' ),
								'font-sub' => array('latin'),
							),
						)
					)
				),
				'body_font_options' => array(
					'type' => 'tab',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Body', 'politix' ),
					'layout' => array(
						'body-font' => array(
							'title' => esc_html__('Body Font', 'politix' ),
							'type' => 'font',
							'font-color' => true,
							'font-size' => true,
							'font-sub' => true,
							'line-height' => true,
							'value' => array(
								'font-size' => '16px',
								'line-height' => '1.7em',
								'color' => '#4c4c4d',
								'font-family' => 'Open Sans',
								'font-weight' => array( 'regular', 'italic', '600', '600italic', '700', '700italic' ),
								'font-sub' => array('latin'),
							)
						)
					)
				),

			)
		), // end of sections
		'help_options' => array(
			'type' => 'section',
			'title' => esc_html__('Maintenance & Help', 'politix' ),
			'icon' => array('fa', 'life-ring'),
			'layout' => array(
				'maintenance' => array(
					'type' => 'tab',
					'init' => 'open',
					'icon' => array('fa', 'calendar-plus-o'),
					'title' => esc_html__( 'Maintenance', 'politix' ),
					'layout' => array(
						'show_loader' => array(
							'title' => esc_html__( 'ShowLoader', 'politix' ),
							'addrowclasses' => 'grid-col-12 checkbox alt',
							'type' => 'checkbox',
							'atts' => 'checked data-options="e:loader_logo;e:overlay_loader_color"',
						),
						'loader_logo' => array(
							'title' => esc_html__( 'Loader logo (Square)', 'politix' ),
							'type' => 'media',
							'url-atts' => 'readonly',
							'addrowclasses' => 'grid-col-12 disable',
							'layout' => array(
								'logo_is_high_dpi' => array(
									'title' => esc_html__( 'High-Resolution logo', 'politix' ),
									'addrowclasses' => 'checkbox',
									'type' => 'checkbox',
								),
							),
						),
						'overlay_loader_color' => array(
							'title' => esc_html__( 'Loader Color', 'politix' ),
							'atts' => 'data-default-color="'.POLITIX_FIRST_COLOR.'"',
							'value' => POLITIX_FIRST_COLOR,
							'addrowclasses' => 'disable grid-col-12',
							'type' => 'text',
						),
						'breadcrumbs' => array(
							'title' => esc_html__( 'Show breadcrumbs', 'politix' ),
							'addrowclasses' => 'checkbox alt',
							'type' => 'checkbox',
						),
						'blog_author' => array(
							'title' => esc_html__( 'Show post author', 'politix' ),
							'addrowclasses' => 'checkbox alt',
							'atts' => 'checked',
							'type' => 'checkbox',
						),
						'_theme_purchase_code' => array(
							'title' => esc_html__( 'Theme purchase code', 'politix' ),
							'tooltip' => array(
								'title' => esc_html__( 'Item Purchase Code', 'politix' ),
								'content' => wp_kses(__( 'Fill in this field with your Item Purchase Code in order to get the demo content and further theme updates.<br/> Please note, this code is applied to the theme only, it will not register Revolution Slider or any other plugins.', 'politix' ), array(
								    'br' => true,
                                )),
							),
							'type' 	=> 'text',
							'value'	=> '',
							'customizer' 	=> array( 'show' => false )
						),
					)
				),
		    'animation' => array(
			     'type' => 'tab',
			     'icon' => array('fa', 'arrow-circle-o-up'),
			     'title' => esc_html__( 'Animation', 'politix' ),
			     'layout' => array(
					'animation_curve_menu'	=> array(
						'title'	=> esc_html__( 'Animation (Menu Anchors)', 'politix' ),
						'type'	=> 'select',
						'addrowclasses' => 'grid-col-4',
						'source'	=> array(
							'linear' => array( esc_html__( '1. linear', 'politix' ), false ),
							'swing' => array( esc_html__( '2. swing', 'politix' ), false ),
							'easeInQuad' => array( esc_html__( '3. easeInQuad', 'politix' ), false ),
							'easeOutQuad' => array( esc_html__( '4. easeOutQuad', 'politix' ), false ),
							'easeInOutQuad' => array( esc_html__( '5. easeInOutQuad', 'politix' ), false ),
							'easeInCubic' => array( esc_html__( '6. easeInCubic', 'politix' ), false ),
							'easeOutCubic' => array( esc_html__( '7. easeOutCubic', 'politix' ), true ),
							'easeInOutCubic' => array( esc_html__( '8. easeInOutCubic', 'politix' ), false ),
							'easeInQuart' => array( esc_html__( '9. easeInQuart', 'politix' ), false ),
							'easeOutQuart' => array( esc_html__( '10. easeOutQuart', 'politix' ), false ),
							'easeInOutQuart' => array( esc_html__( '11. easeInOutQuart', 'politix' ), false ),
							'easeInQuint' => array( esc_html__( '12. easeInQuint', 'politix' ), false ),
							'easeOutQuint' => array( esc_html__( '13. easeOutQuint', 'politix' ), false ),
							'easeInOutQuint' => array( esc_html__( '14. easeInOutQuint', 'politix' ), false ),
							'easeInSine' => array( esc_html__( '15. easeInSine', 'politix' ), false ),
							'easeOutSine' => array( esc_html__( '16. easeOutSine', 'politix' ), false ),
							'easeInOutSine' => array( esc_html__( '17. easeInOutSine', 'politix' ), false ),
							'easeInExpo' => array( esc_html__( '18. easeInExpo', 'politix' ), false ),
							'easeOutExpo' => array( esc_html__( '19. easeOutExpo', 'politix' ), false ),
							'easeInOutExpo' => array( esc_html__( '20. easeInOutExpo', 'politix' ), false ),
							'easeInCirc' => array( esc_html__( '21. easeInCirc', 'politix' ), false ),
							'easeOutCirc' => array( esc_html__( '22. easeOutCirc', 'politix' ), false ),
							'easeInOutCirc' => array( esc_html__( '23. easeInOutCirc', 'politix' ), false ),
							'easeInElastic' => array( esc_html__( '24. easeInElastic', 'politix' ), false ),
							'easeOutElastic' => array( esc_html__( '25. easeOutElastic', 'politix' ), false ),
							'easeInOutElastic' => array( esc_html__( '26. easeInOutElastic', 'politix' ), false ),
							'easeInBack' => array( esc_html__( '27. easeInBack', 'politix' ), false ),
							'easeOutBack' => array( esc_html__( '28. easeOutBack', 'politix' ), false ),
							'easeInOutBack' => array( esc_html__( '29. easeInOutBack', 'politix' ), false ),
							'easeInBounce' => array( esc_html__( '30. easeInBounce', 'politix' ), false ),
							'easeOutBounce' => array( esc_html__( '31. easeOutBounce', 'politix' ), false ),
							'easeInOutBounce' => array( esc_html__( '32. easeInOutBounce', 'politix' ), false ),
						),
					),
					'animation_curve_scrolltop'	=> array(
						'title'	=> esc_html__( 'Animation (ScrollTop)', 'politix' ),
						'type'	=> 'select',
						'addrowclasses' => 'grid-col-4',
						'source'	=> array(
							'linear' => array( esc_html__( '1. linear', 'politix' ), false ),
							'swing' => array( esc_html__( '2. swing', 'politix' ), false ),
							'easeInQuad' => array( esc_html__( '3. easeInQuad', 'politix' ), false ),
							'easeOutQuad' => array( esc_html__( '4. easeOutQuad', 'politix' ), false ),
							'easeInOutQuad' => array( esc_html__( '5. easeInOutQuad', 'politix' ), true ),
							'easeInCubic' => array( esc_html__( '6. easeInCubic', 'politix' ), false ),
							'easeOutCubic' => array( esc_html__( '7. easeOutCubic', 'politix' ), false ),
							'easeInOutCubic' => array( esc_html__( '8. easeInOutCubic', 'politix' ), false ),
							'easeInQuart' => array( esc_html__( '9. easeInQuart', 'politix' ), false ),
							'easeOutQuart' => array( esc_html__( '10. easeOutQuart', 'politix' ), false ),
							'easeInOutQuart' => array( esc_html__( '11. easeInOutQuart', 'politix' ), false ),
							'easeInQuint' => array( esc_html__( '12. easeInQuint', 'politix' ), false ),
							'easeOutQuint' => array( esc_html__( '13. easeOutQuint', 'politix' ), false ),
							'easeInOutQuint' => array( esc_html__( '14. easeInOutQuint', 'politix' ), false ),
							'easeInSine' => array( esc_html__( '15. easeInSine', 'politix' ), false ),
							'easeOutSine' => array( esc_html__( '16. easeOutSine', 'politix' ), false ),
							'easeInOutSine' => array( esc_html__( '17. easeInOutSine', 'politix' ), false ),
							'easeInExpo' => array( esc_html__( '18. easeInExpo', 'politix' ), false ),
							'easeOutExpo' => array( esc_html__( '19. easeOutExpo', 'politix' ), false ),
							'easeInOutExpo' => array( esc_html__( '20. easeInOutExpo', 'politix' ), false ),
							'easeInCirc' => array( esc_html__( '21. easeInCirc', 'politix' ), false ),
							'easeOutCirc' => array( esc_html__( '22. easeOutCirc', 'politix' ), false ),
							'easeInOutCirc' => array( esc_html__( '23. easeInOutCirc', 'politix' ), false ),
							'easeInElastic' => array( esc_html__( '24. easeInElastic', 'politix' ), false ),
							'easeOutElastic' => array( esc_html__( '25. easeOutElastic', 'politix' ), false ),
							'easeInOutElastic' => array( esc_html__( '26. easeInOutElastic', 'politix' ), false ),
							'easeInBack' => array( esc_html__( '27. easeInBack', 'politix' ), false ),
							'easeOutBack' => array( esc_html__( '28. easeOutBack', 'politix' ), false ),
							'easeInOutBack' => array( esc_html__( '29. easeInOutBack', 'politix' ), false ),
							'easeInBounce' => array( esc_html__( '30. easeInBounce', 'politix' ), false ),
							'easeOutBounce' => array( esc_html__( '31. easeOutBounce', 'politix' ), false ),
							'easeInOutBounce' => array( esc_html__( '32. easeInOutBounce', 'politix' ), false ),
						),
					),
					'animation_curve_speed' => array(
						'type' => 'number',
						'title' => esc_html__( 'Animation Speed', 'politix' ),
						'placeholder' => esc_html__( 'In milliseconds', 'politix' ),
						'value' => '300',
						'addrowclasses' => 'grid-col-4',
					),
					'curves' => array(
						'type' => 'info',
						'addrowclasses' => 'grid-col-12',
						'value' => '<img src="'. esc_url(get_template_directory_uri()) . '/img/easing.png" />',
						'title' => esc_html__('Easing curves', 'politix' )
					),
			    )
		    ),
				'help' => array(
					'type' => 'tab',
					'icon' => array('fa', 'calendar-plus-o'),
					'title' => esc_html__( 'Help', 'politix' ),
					'layout' => array(
						'help' => array(
								 'title' 			=> esc_html__( 'Help', 'politix' ),
								 'type' 			=> 'info',
								 'subtype'		=> 'custom',
								 'value' 			=> '<a class="cwsfw_info_button" href="http://politix.cwsthemes.com/manual" target="_blank"><i 
class="fa fa-life-ring"></i>&nbsp;&nbsp;' . esc_html__( 'Online Tutorial', 'politix' ) . '</a>&nbsp;&nbsp;<a 
class="cwsfw_info_button" href="https://www.youtube.com/user/cwsvideotuts/playlists" target="_blank"><i 
class="fa fa-video-camera"></i>&nbsp;&nbsp;' . esc_html__( 'Video Tutorial', 'politix' ) . '</a>',
							),
					)
				),
				'crop' => array(
					'type' => 'tab',
					'icon' => array('fa', 'calendar-plus-o'),
					'title' => esc_html__( 'Crop Images', 'politix' ),
					'layout' => array(
						'crop_x' => array(
							'title' => esc_html__( 'Crop X', 'politix' ),
							'type' => 'radio',
							'addrowclasses' => 'grid-col-3',
							'value' => array(
								'left' => array( esc_html__( 'Left', 'politix' ),  false, '' ),
								'center' => array( esc_html__( 'Center', 'politix' ),  true, '' ),
								'right' => array( esc_html__( 'Right', 'politix' ),  false, '' ),
							),
						),
						'crop_y' => array(
							'title' => esc_html__( 'Crop Y', 'politix' ),
							'type' => 'radio',
							'addrowclasses' => 'grid-col-3',
							'value' => array(
								'top' => array( esc_html__( 'Top', 'politix' ),  false, '' ),
								'center' => array( esc_html__( 'Center', 'politix' ),  true, '' ),
								'bottom' => array( esc_html__( 'Bottom', 'politix' ),  false, '' ),
							),
						),

					)
				),
			)
		),
		
		'social_options' => array(
			'type' => 'section',
			'title' => esc_html__('Social Networks', 'politix' ),
			'icon' => array('fa', 'share-alt'),
			'layout' => array(
				'social_cont'	=> array(
					'type' => 'tab',
					'init'	=> 'open',
					'icon' => array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Social Networks', 'politix' ),
					'layout' => array(

						'social' => array(
							'type' => 'fields',
							'addrowclasses' => 'inside-box groups grid-col-12 box',
							'layout' => array(
								'location'	=> array(
									'title'		=> esc_html__( 'Social Icons Location', 'politix' ),
									'type'	=> 'select',
									'atts' => 'multiple',
									'addrowclasses' => 'grid-col-12 box',
									'source'	=> array(
										'top_bar' => array( esc_html__( 'Top Bar', 'politix' ), false, ''),
										'menu' => array( esc_html__( 'Menu', 'politix' ), false, ''),
										'copyrights' => array( esc_html__( 'Copyrights area', 'politix' ), true, ''),
										'side_panel' => array( esc_html__( 'Side panel', 'politix' ), true, ''),
									),
								),
								'icons' => array(
									'type' => 'group',
									'addrowclasses' => 'group sortable grid-col-12 box',
									'title' => esc_html__('Social Networks', 'politix' ),
									'button_title' => esc_html__('Add new social network', 'politix' ),
									'button_icon' => 'fas fa-plus',
									'layout' => array(
										'title' => array(
											'type' => 'text',
											'atts' => 'data-role="title"',
											'addrowclasses' => 'grid-col-4',
											'title' => esc_html__('Social account title', 'politix' ),
										),
										'icon' => array(
											'type' => 'select',
											'addrowclasses' => 'fai grid-col-4',
											'source' => 'fa',
											'title' => esc_html__('Icon for this social contact', 'politix' )
										),										
										'url' => array(
											'type' => 'text',
											'addrowclasses' => 'grid-col-4',
											'title' => esc_html__('Url to your account', 'politix' ),
										),
										'color'	=> array(
											'title'	=> esc_html__( 'Icon color', 'politix' ),
											'addrowclasses' => 'grid-col-3',
											'atts' => 'data-default-color="#ffffff"',
											'value' => '#ffffff',
											'type'	=> 'text',
										),
										'bg_color'	=> array(
											'title'	=> esc_html__( 'Background color', 'politix' ),
											'addrowclasses' => 'grid-col-3',
											'atts' => 'data-default-color=""',
											'value' => '',
											'type'	=> 'text',
										),			
										'hover_color'	=> array(
											'title'	=> esc_html__( 'Icon color (Hover)', 'politix' ),
											'addrowclasses' => 'grid-col-3',
											'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
											'value' => POLITIX_FIRST_COLOR,
											'type'	=> 'text',
										),
										'hover_bg_color'	=> array(
											'title'	=> esc_html__( 'Background color (Hover)', 'politix' ),
											'addrowclasses' => 'grid-col-3',
											'atts' => 'data-default-color=""',
											'value' => '',
											'type'	=> 'text',
										),
									)
								),
							),
						),

					)
				),
			)
		), // end of sections
	);

	//Show field if WPML plugin active
	if ( class_exists('SitePress') )  {
		$settings['general_setting']['layout']['menu_cont']['layout']['menu_box']['layout']['language_bar'] = array(
			'title' => esc_html__( 'Add Language Bar to menu', 'politix' ),
			'addrowclasses' => 'checkbox grid-col-6',
			'type' => 'checkbox',
		);
	}

	//Show TAB if WooCommerce plugin active
	if ( class_exists( 'woocommerce' ) )  {
		$settings['woo_options'] = array(
			'type'		=> 'section',
			'title'		=> esc_html__( 'WooCommerce', 'politix' ),
			'icon'		=> array('fa', 'shopping-cart'),
			'layout'	=> array(
				'woo_options' => array(
					'type' 	=> 'tab',
					'init'	=> 'open',
					'icon' 	=> array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Woocommerce', 'politix' ),
					'layout' => array(
						'woo_cart_enable'	=> array(
							'title'			=> esc_html__( 'Show WooCommerce Cart', 'politix' ),
							'type'			=> 'checkbox',
							'addrowclasses'	=> 'checkbox alt grid-col-12',
							'atts' => 'data-options="e:woo_cart_place;"',
						),
						'woo_cart_place' => array(
							'title' => esc_html__( 'WooCommerce Cart position', 'politix' ),
							'type' => 'radio',
							'subtype' => 'images',
							'addrowclasses' => 'disable grid-col-12',
							'value' => array(
								'top' =>array( esc_html__( 'TopBar', 'politix' ), false, '', '/img/woo-cart-top-right.png' ),
								'left' =>array( esc_html__( 'Menu (Left)', 'politix' ), false, '', '/img/woo-cart-menu-left.png' ),
								'right' =>array( esc_html__( 'Menu (Right)', 'politix' ), true, '', '/img/woo-cart-menu-right.png' ),
							),
						),
						'woo_sb_layout' => array(
							'title' => esc_html__('Sidebar Position', 'politix' ),
							'type' => 'radio',
							'subtype' => 'images',
							'addrowclasses' => 'grid-col-12',
							'value' => array(
								'left' => 	array( esc_html__('Left', 'politix' ), true, 'e:woo_sidebar;',	'/img/left.png' ),
								'right' => 	array( esc_html__('Right', 'politix' ), false, 'e:woo_sidebar;', '/img/right.png' ),
								'none' => 	array( esc_html__('None', 'politix' ), false, 'd:woo_sidebar;', '/img/none.png' )
							),
						),
						'woo_sidebar' => array(
							'title' => esc_html__('Select a sidebar', 'politix' ),
							'type' => 'select',
							'addrowclasses' => 'disable grid-col-12',
							'source' => 'sidebars',
                            'value' => 'woocommerce'
						),	
						'woo_sb_layout_single' => array(
							'title' => esc_html__('Sidebar Position Single', 'politix' ),
							'type' => 'radio',
							'subtype' => 'images',
							'addrowclasses' => 'grid-col-12',
							'value' => array(
								'left' => 	array( esc_html__('Left', 'politix' ), false, 'e:woo_sidebar_single;',	'/img/left.png' ),
								'right' => 	array( esc_html__('Right', 'politix' ), false, 'e:woo_sidebar_single;', '/img/right.png' ),
								'none' => 	array( esc_html__('None', 'politix' ), true, 'd:woo_sidebar_single;', '/img/none.png' )
							),
						),					
						'woo_sidebar_single' => array(
							'title' => esc_html__('Select a Single sidebar', 'politix' ),
							'type' => 'select',
							'addrowclasses' => 'disable grid-col-12',
							'source' => 'sidebars',
						),
						'woo_columns' => array(
							'type' => 'select',
							'title' => esc_html__( 'Columns layout', 'politix' ),
							'addrowclasses' => 'grid-col-6',
							'source' => array(
								'2' => array('Two Columns',false, ''),
								'3' => array('Three Columns',true, ''),
								'4' => array('Four Columns',false, '')
							),
						),
						'woo_num_products'	=> array(
							'title'			=> esc_html__( 'Products per page', 'politix' ),
							'type'			=> 'number',
							'addrowclasses' => 'grid-col-6',
							'value'			=> '9'
						),
						'woo_related_columns' => array(
							'type' => 'select',
							'title' => esc_html__( 'Columns layout (Related)', 'politix' ),
							'addrowclasses' => 'grid-col-6',
							'source' => array(
								'2' => array('Two Columns',false, ''),
								'3' => array('Three Columns',false, ''),
								'4' => array('Four Columns',true, '')
							),
						),						
						'woo_related_num_products'	=> array(
							'title'			=> esc_html__( 'Products per page (Related)', 'politix' ),
							'type'			=> 'number',
							'addrowclasses' => 'grid-col-6',
							'value'			=> '8'
						),
						'shop-slider-type' => array(
							'title' => esc_html__('Slider', 'politix' ),
							'type' => 'radio',
							'addrowclasses' => 'grid-col-12',
							'value' => array(
								'none' => 	array( esc_html__('None', 'politix' ), true, 'd:shop-header-slider-options;d:shopslidersection-start;d:static_img_section' ),
								'img-slider'=>	array( esc_html__('Image Slider', 'politix' ), false, 'e:shop-header-slider-options;d:shopslidersection-start;d:static_img_section' ),
								'video-slider' => 	array( esc_html__('Video Slider', 'politix' ), false, 'd:shop-header-slider-options;e:shopslidersection-start;d:static_img_section' ),
								'stat-img-slider' => 	array( esc_html__('Static image', 'politix' ), false, 'd:shop-header-slider-options;d:shopslidersection-start;e:static_img_section' ),
							),
						),
						'shop-header-slider-options' => array(
							'title' => esc_html__( 'Slider shortcode', 'politix' ),
							'addrowclasses' => 'disable grid-col-12',
							'type' => 'text',
							'value' => '[rev_slider shoppage]',
						),
						'shopslidersection-start' => array(
							'title' => esc_html__( 'Video Slider Setting', 'politix' ),
							'type' => 'fields',
							'addrowclasses' => 'disable groups',
							'layout' => array(
								'slider_switch' => array(
									'title' => esc_html__( 'Slider', 'politix' ),
									'addrowclasses' => 'checkbox',
									'type' => 'checkbox',
									'atts' => 'data-options="e:slider_shortcode;"',
								),
								'slider_shortcode' => array(
									'title' => esc_html__( 'Slider shortcode', 'politix' ),
									'addrowclasses' => 'disable box',
									'type' => 'text',
								),
								'set_video_header_height' => array(
									'title' => esc_html__( 'Set Video height', 'politix' ),
									'type' => 'checkbox',
									'addrowclasses' => 'checkbox',
									'atts' => 'data-options="e:video_header_height"',
								),
								'video_header_height' => array(
									'title' => esc_html__( 'Video height', 'politix' ),
									'addrowclasses' => 'disable box',
									'type' => 'number',
									'value' => '600',
								),
								'video_type' => array(
									'title' => esc_html__('Video type', 'politix' ),
									'type' => 'radio',
									'value' => array(
										'self_hosted' => 	array( esc_html__('Self-hosted', 'politix' ), true, 'e:sh_source;d:youtube_source;d:vimeo_source' ),
										'youtube'=>	array( esc_html__('Youtube clip', 'politix' ), false, 'd:sh_source;e:youtube_source;d:vimeo_source' ),
										'vimeo' => 	array( esc_html__('Vimeo clip', 'politix' ), false, 'd:sh_source;d:youtube_source;e:vimeo_source' ),
									),
								),
								'sh_source' => array(
									'title' => esc_html__( 'Add video', 'politix' ),
									'addrowclasses' => 'box',
									'url-atts' => 'readonly',
									'type' => 'media',
								),
								'youtube_source' => array(
									'title' => esc_html__( 'Youtube video code', 'politix' ),
									'addrowclasses' => 'disable box',
									'type' => 'text',
								),
								'vimeo_source' => array(
									'title' => esc_html__( 'Vimeo embed url', 'politix' ),
									'addrowclasses' => 'disable box',
									'type' => 'text',
								),
								'color_overlay_type' => array(
									'title' => esc_html__( 'Overlay type', 'politix' ),
									'type' => 'select',
									'source' => array(
										'none' => array( esc_html__( 'None', 'politix' ), 	true, 'd:overlay_color;d:slider_gradient_settings;d:color_overlay_opacity;'),
										'color' => array( esc_html__( 'Color', 'politix' ), 	false, 'e:overlay_color;d:slider_gradient_settings;e:color_overlay_opacity;'),
										'gradient' =>array( esc_html__( 'Gradient', 'politix' ), false, 'd:overlay_color;e:slider_gradient_settings;e:color_overlay_opacity;'),
									),
								),
								'overlay_color' => array(
									'title' => esc_html__( 'Overlay Color', 'politix' ),
									'atts' => 'data-default-color=""',
									'addrowclasses' => 'box',
									'type' => 'text',
								),
								'color_overlay_opacity' => array(
									'type' => 'number',
									'addrowclasses' => 'box',
									'title' => esc_html__( 'Opacity', 'politix' ),
									'placeholder' => esc_attr__( 'In percents', 'politix' ),
									'value' => '40'
								),
								'slider_gradient_settings' => array(
									'title' => esc_html__( 'Gradient settings', 'politix' ),
									'type' => 'fields',
									'addrowclasses' => 'disable box groups',
									'layout' => array(
										'first_color' => array(
											'type' => 'text',
											'title' => esc_html__( 'From', 'politix' ),
											'atts' => 'data-default-color=""',
										),
										'second_color' => array(
											'type' => 'text',
											'title' => esc_html__( 'To', 'politix' ),
											'atts' => 'data-default-color=""',
										),
										'first_color_opacity' => array(
											'type' => 'number',
											'title' => esc_html__( 'From (Opacity %)', 'politix' ),
											'value' => '100',
										),
										'second_color_opacity' => array(
											'type' => 'number',
											'title' => esc_html__( 'To (Opacity %)', 'politix' ),
											'value' => '100',
										),
										'type' => array(
											'title' => esc_html__( 'Gradient type', 'politix' ),
											'type' => 'radio',
											'value' => array(
												'linear' => array( esc_html__( 'Linear', 'politix' ),  true, 'e:linear_settings;d:radial_settings' ),
												'radial' =>array( esc_html__( 'Radial', 'politix' ), false,  'd:linear_settings;e:radial_settings' ),
											),
										),
										'linear_settings' => array(
											'title' => esc_html__( 'Linear settings', 'politix'  ),
											'type' => 'fields',
											'addrowclasses' => 'disable',
											'layout' => array(
												'angle' => array(
													'type' => 'number',
													'title' => esc_html__( 'Angle', 'politix' ),
													'value' => '45',
												),
											)
										),
										'radial_settings' => array(
											'title' => esc_html__( 'Radial settings', 'politix'  ),
											'type' => 'fields',
											'addrowclasses' => 'disable',
											'layout' => array(
												'shape_settings' => array(
													'title' => esc_html__( 'Shape', 'politix' ),
													'type' => 'radio',
													'value' => array(
														'simple' => array( esc_html__( 'Simple', 'politix' ),  true, 'e:shape;d:size;d:size_keyword;' ),
														'extended' =>array( esc_html__( 'Extended', 'politix' ), false, 'd:shape;e:size;e:size_keyword;' ),
													),
												),
												'shape' => array(
													'title' => esc_html__( 'Gradient type', 'politix' ),
													'type' => 'radio',
													'value' => array(
														'ellipse' => array( esc_html__( 'Ellipse', 'politix' ),  true ),
														'circle' =>array( esc_html__( 'Circle', 'politix' ), false ),
													),
												),
												'size_keyword' => array(
													'type' => 'select',
													'title' => esc_html__( 'Size keyword', 'politix' ),
													'addrowclasses' => 'disable',
													'source' => array(
														'closest-side' => array(esc_html__( 'Closest side', 'politix' ), false),
														'farthest-side' => array(esc_html__( 'Farthest side', 'politix' ), false),
														'closest-corner' => array(esc_html__( 'Closest corner', 'politix' ), false),
														'farthest-corner' => array(esc_html__( 'Farthest corner', 'politix' ), true),
													),
												),
												'size' => array(
													'type' => 'text',
													'addrowclasses' => 'disable',
													'title' => esc_html__( 'Size', 'politix' ),
													'atts' => 'placeholder="'.esc_attr__( 'Two space separated percent values, for example (60% 55%)', 'politix' ).'"',
												),
											)
										)

									),
								),
								'use_pattern' => array(
									'title' => esc_html__( 'Use pattern image', 'politix' ),
									'type' => 'checkbox',
									'addrowclasses' => 'checkbox',
									'atts' => 'data-options="e:pattern_image"',
								),
								'pattern_image' => array(
									'title' => esc_html__( 'Pattern image', 'politix' ),
									'addrowclasses' => 'disable box',
									'url-atts' => 'readonly',
									'type' => 'media',
								),
							),
						),// end of video-section
						'static_img_section' => array(
							'title' => esc_html__( 'Static image Slider Setting', 'politix' ),
							'type' => 'fields',
							'addrowclasses' => 'groups',
							'layout' => array(
								'shop_header_image_options' => array(
									'title' => esc_html__( 'Static image', 'politix' ),
									'type' => 'media',
									'url-atts' => 'readonly',
									'layout' => array(
										'is_high_dpi' => array(
											'title' => esc_html__( 'High-Resolution image', 'politix' ),
											'type' => 'checkbox',
											'addrowclasses' => 'checkbox',
										),
									),
								),
								'set_static_image_height' => array(
									'title' => esc_html__( 'Set Image height', 'politix' ),
									'addrowclasses' => 'checkbox',
									'type' => 'checkbox',
									'atts' => 'data-options="e:static_image_height;"',
								),
								'static_image_height' => array(
									'title' => esc_html__( 'Static Image Height', 'politix' ),
									'addrowclasses' => 'disable box',
									'type' => 'number',
									'default' => '600',
								),
								'static_customize_colors' => array(
									'title' => esc_html__( 'Customize colors', 'politix' ),
									'addrowclasses' => 'checkbox',
									'type' => 'checkbox',
									'atts' => 'data-options="e:img_header_color_overlay_type;e:img_header_overlay_color;e:img_header_color_overlay_opacity;"',
								),
								'img_header_color_overlay_type'	=> array(
									'title'		=> esc_html__( 'Color overlay type', 'politix' ),
									'type'	=> 'select',
									'addrowclasses' => 'box disable',
									'source'	=> array(
										'color' => array( esc_html__( 'Color', 'politix' ),  true, 'e:img_header_overlay_color;d:img_header_gradient_settings;' ),
										'gradient' => array( esc_html__( 'Gradient', 'politix' ), false, 'd:img_header_overlay_color;e:img_header_gradient_settings;' )
									),
								),
								'img_header_overlay_color'	=> array(
									'title'	=> esc_html__( 'Overlay color', 'politix' ),
									'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
									'value' => POLITIX_FIRST_COLOR,
									'addrowclasses' => 'box disable',
									'type'	=> 'text',
								),
								'img_header_gradient_settings' => array(
									'title' => esc_html__( 'Gradient Settings', 'politix' ),
									'type' => 'fields',
									'addrowclasses' => 'disable box groups',
									'layout' => array(
										'first_color' => array(
											'type' => 'text',
											'title' => esc_html__( 'From', 'politix' ),
											'atts' => 'data-default-color=""',
										),
										'second_color' => array(
											'type' => 'text',
											'title' => esc_html__( 'To', 'politix' ),
											'atts' => 'data-default-color=""',
										),
										'first_color_opacity' => array(
											'type' => 'number',
											'title' => esc_html__( 'From (Opacity %)', 'politix' ),
											'value' => '100',
										),
										'second_color_opacity' => array(
											'type' => 'number',
											'title' => esc_html__( 'To (Opacity %)', 'politix' ),
											'value' => '100',
										),
										'type' => array(
											'title' => esc_html__( 'Gradient type', 'politix' ),
											'type' => 'radio',
											'value' => array(
												'linear' => array( esc_html__( 'Linear', 'politix' ),  true, 'e:img_header_gradient_linear_settings;d:img_header_gradient_radial_settings' ),
												'radial' =>array( esc_html__( 'Radial', 'politix' ), false,  'd:img_header_gradient_linear_settings;e:img_header_gradient_radial_settings' ),
											),
										),
										'linear_settings' => array(
											'title' => esc_html__( 'Linear settings', 'politix'  ),
											'type' => 'fields',
											'addrowclasses' => 'disable',
											'layout' => array(
												'angle' => array(
													'type' => 'number',
													'title' => esc_html__( 'Angle', 'politix' ),
													'value' => '45',
												),
											)
										),
										'radial_settings' => array(
											'title' => esc_html__( 'Radial settings', 'politix'  ),
											'type' => 'fields',
											'addrowclasses' => 'disable',
											'layout' => array(
												'shape_settings' => array(
													'title' => esc_html__( 'Shape', 'politix' ),
													'type' => 'radio',
													'value' => array(
														'simple' => array( esc_html__( 'Simple', 'politix' ),  true, 'e:img_header_gradient_shape;d:img_header_gradient_size;d:img_header_gradient_size_keyword;' ),
														'extended' =>array( esc_html__( 'Extended', 'politix' ), false, 'd:img_header_gradient_shape;e:img_header_gradient_size;e:img_header_gradient_size_keyword;' ),
													),
												),
												'shape' => array(
													'title' => esc_html__( 'Gradient type', 'politix' ),
													'type' => 'radio',
													'value' => array(
														'ellipse' => array( esc_html__( 'Ellipse', 'politix' ),  true ),
														'circle' =>array( esc_html__( 'Circle', 'politix' ), false ),
													),
												),
												'img_header_gradient_size_keyword' => array(
													'type' => 'select',
													'title' => esc_html__( 'Size keyword', 'politix' ),
													'addrowclasses' => 'disable',
													'source' => array(
														'closest-side' => array(esc_html__( 'Closest side', 'politix' ), false),
														'farthest-side' => array(esc_html__( 'Farthest side', 'politix' ), false),
														'closest-corner' => array(esc_html__( 'Closest corner', 'politix' ), false),
														'farthest-corner' => array(esc_html__( 'Farthest corner', 'politix' ), true),
													),
												),
												'img_header_gradient_size' => array(
													'type' => 'text',
													'addrowclasses' => 'disable',
													'title' => esc_html__( 'Size', 'politix' ),
													'atts' => 'placeholder="'.esc_attr__( 'Two space separated percent values, for example (60% 55%)', 'politix' ).'"',
												),
											)
										)
									)
								),
								'img_header_color_overlay_opacity' => array(
									'type' => 'number',
									'title' => esc_html__( 'Opacity', 'politix' ),
									'addrowclasses' => 'box disable',
									'placeholder' => esc_attr__( 'In percents', 'politix' ),
									'value' => '40'
								),
								'img_header_use_pattern' => array(
									'title' => esc_html__( 'Add pattern', 'politix' ),
									'addrowclasses' => 'checkbox',
									'type' => 'checkbox',
									'atts' => 'data-options="e:img_header_pattern_image;"',
								),
								'img_header_pattern_image' => array(
									'title' => esc_html__( 'Pattern image', 'politix' ),
									'type' => 'media',
									'addrowclasses' => 'disable box',
									'url-atts' => 'readonly',
								),
								'img_header_parallaxify' => array(
									'title' => esc_html__( 'Parallaxify image', 'politix' ),
									'addrowclasses' => 'checkbox',
									'type' => 'checkbox',
									'atts' => 'data-options="e:img_header_parallax_options;"',
								),
								'img_header_parallax_options' => array(
									'title' => esc_html__( 'Parallax options', 'politix' ),
									'type' => 'fields',
									'addrowclasses' => 'disable box groups',
									'layout' => array(
										'img_header_scalar-x' => array(
											'type' => 'number',
											'title' => esc_html__( 'x-axis parallax intensity', 'politix' ),
											'placeholder' => esc_attr__( 'Integer', 'politix' ),
											'value' => '2'
										),
										'img_header_scalar-y' => array(
											'type' => 'number',
											'title' => esc_html__( 'y-axis parallax intensity', 'politix' ),
											'placeholder' => esc_attr__( 'Integer', 'politix' ),
											'value' => '2'
										),
										'img_header_limit-x' => array(
											'type' => 'number',
											'title' => esc_html__( 'Maximum x-axis shift', 'politix' ),
											'placeholder' => esc_attr__( 'Integer', 'politix' ),
											'value' => '15'
										),
										'img_header_limit-y' => array(
											'type' => 'number',
											'title' => esc_html__( 'Maximum y-axis shift', 'politix' ),
											'placeholder' => esc_attr__( 'Integer', 'politix' ),
											'value' => '15'
										),
									),
								),
							),
						),// end of static img slider-section
					)
				),
				'woo_menu_options' => array(
					'type' 	=> 'tab',
					'icon' 	=> array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Menu', 'politix' ),
					'layout' => array(
						'woo_customize_menu'	=> array(
							'title'	=> esc_html__( 'Customize WooCommerce Menu', 'politix' ),
							'type'	=> 'checkbox',
							'addrowclasses' => 'checkbox alt grid-col-12',
							'atts' => 'data-options="e:show_menu_bg_color;e:woo_menu_font_color;e:woo_menu_font_hover_color;e:woo_menu_border_color;e:woo_header_covers_slider"',		
						),							
						'show_menu_bg_color' => array(
							'title' => esc_html__( 'Add Background Color', 'politix' ),
							'addrowclasses' => 'checkbox disable',
							'type' => 'checkbox',
							'atts' => 'data-options="e:woo_menu_opacity;e:woo_menu_bg_color"',
						),
						'woo_menu_opacity' => array(
							'title' 		=> esc_html__( 'Opacity', 'politix' ),
							'tooltip' => array(
								'title' => esc_html__( 'Menu Opacity', 'politix' ),
								'content' => esc_html__( 'This option will apply a transparent header when set to 0. Options available from 0 to 100', 'politix' ),
							),								
							'type' 			=> 'number',
							'addrowclasses' => 'grid-col-6 disable',
							'atts' 			=> " min='0' max='100'",
							'value'			=> '0'
						),
						'woo_menu_bg_color' => array(
							'title' 		=> esc_html__( 'Background Color', 'politix' ),
							'tooltip' => array(
								'title' => esc_html__( 'Background Color', 'politix' ),
								'content' => esc_html__( 'Change the background color of the menu and logo area.', 'politix' ),
							),							
							'type' 			=> 'text',
							'addrowclasses' => 'grid-col-6 disable',
							'atts' 			=> 'data-default-color="#ffffff"',
							'value'			=> '#ffffff'
						),
						'woo_menu_font_color' => array(
							'title' 		=> esc_html__( 'Override Font Color', 'politix' ),
							'tooltip' => array(
								'title' => esc_html__( 'Override Font Color', 'politix' ),
								'content' => wp_kses(__( 'This color is applied to the main menu only, sub-menu items will use the color which is set in Typography section.<br /> This option is very useful when menu and logo covers title area or slider.', 'politix' ), array(
								    'br' => true,
                                )),
							),							
							'type' 			=> 'text',
							'addrowclasses' => 'grid-col-6 disable',
							'atts' 			=> 'data-default-color="#19191A;"',
							'value'			=> '#19191A'
						),
						'woo_menu_font_hover_color' => array(
							'title' 		=> esc_html__( 'Override Font Color on Hover', 'politix' ),
							'tooltip' => array(
								'title' => esc_html__( 'Override Font Color on Hover', 'politix' ),
								'content' => wp_kses(__( 'This color is applied to the main menu on mouse hover only, sub-menu items will use the color which is set in Typography section.<br /> This option is very useful when menu and logo covers title area or slider.', 'politix' ), array(
								    'br' => true,
                                )),
							),							
							'type' 			=> 'text',
							'addrowclasses' => 'grid-col-6 disable',
							'atts' 			=> 'data-default-color="#19191A;"',
							'value'			=> '#19191A'
						),
						'woo_header_covers_slider' => array(
							'title' => esc_html__( 'Header Hover Slider', 'politix' ),
							'tooltip' => array(
								'title' => esc_html__( 'Menu Overlays Slider', 'politix' ),
								'content' => wp_kses(__( 'This option will force the menu and logo sections to overlay the title area. <br> It is useful when using transparent menu.', 'politix' ), array(
								    'br' => true,
                                )),
							),							
							'type' => 'checkbox',
							'addrowclasses' => 'checkbox grid-col-12 disable'
						),		
						'woo_customize_logotype'	=> array(
							'title'	=> esc_html__( 'Customize WooCommerce Logotype', 'politix' ),
							'type'	=> 'checkbox',
							'addrowclasses' => 'checkbox alt grid-col-12',
							'atts' => 'data-options="e:logo_woo"',		
						),
						'logo_woo' => array(
							'title' => esc_html__( 'Logotype Woocommerce', 'politix' ),
							'type' => 'media',
							'url-atts' => 'readonly',
							'addrowclasses' => 'grid-col-12 disable',
							'layout' => array(
								'is_high_dpi' => array(
									'title' => esc_html__( 'High-Resolution logo', 'politix' ),
									'addrowclasses' => 'checkbox',
									'type' => 'checkbox',
								),
							),
						),
					)
				),
				'woo_title_options' => array(
					'type' 	=> 'tab',
					'icon' 	=> array('fa', 'arrow-circle-o-up'),
					'title' => esc_html__( 'Title Area', 'politix' ),
					'layout' => array(
						'woo_customize_title'	=> array(
							'title'	=> esc_html__( 'Customize WooCommerce Title Area', 'politix' ),
							'type'	=> 'checkbox',
							'atts' => 'data-options="e:woo_hide_title"',
							'addrowclasses' => 'checkbox alt grid-col-12'		
						),	
						'woo_hide_title'	=> array(
							'title'	=> esc_html__( 'Switch on/off the title area', 'politix' ),
							'type'	=> 'checkbox',
							'atts' => 'data-options="e:woo_page_title_spacings;e:woo_default_header_image;e:woo_header_font_color;e:woo_header_helper_font_color;e:woo_header_helper_hover_font_color;e:woo_color_overlay_type;"',
							'addrowclasses' => 'checkbox alt grid-col-12 disable'		
						),
                        'woo_subtitle_content' => array(
                            'title' => esc_html__( 'Subtitle Content', 'politix' ),
                            'addrowclasses' => 'grid-col-12 full_row',
                            'type' => 'textarea',
                            'atts' => 'rows="2"',
                        ),
						'woo_page_title_spacings' => array(
							'title' => esc_html__( 'Add Spacings (px)', 'politix' ),
							'type' => 'margins',
							'value' => array(
								'top' => array('placeholder' => esc_attr__( 'Top', 'politix' ), 'value' => '73'),
								'left' => array('placeholder' => esc_attr__( 'left', 'politix' ), 'value' => '0'),
								'right' => array('placeholder' => esc_attr__( 'Right', 'politix' ), 'value' => '0'),
								'bottom' => array('placeholder' => esc_attr__( 'Bottom', 'politix' ), 'value' => '90'),
							),
							'addrowclasses' => 'grid-col-6 disable'
						),
						'woo_default_header_image'	=> array(
							'title'	=> esc_html__( 'Add Background Image', 'politix' ),
							'addrowclasses' => 'grid-col-6 disable',
							'type'	=> 'media'
						),
                        'woo_header_font_color' => array(
                            'title'	=> esc_html__( 'Override Title Color', 'politix' ),
                            'atts' => 'data-default-color="#ffffff"',
                            'value' => '#ffffff',
                            'addrowclasses' => 'disable grid-col-6',
                            'type'	=> 'text',
                        ),
                        'woo_header_helper_font_color' => array(
                            'title'	=> esc_html__( 'Subtitle content/Breadcrumbs Font Color', 'politix' ),
                            'atts' => 'data-default-color="#ffffff"',
                            'value' => '#ffffff',
                            'addrowclasses' => 'disable grid-col-6',
                            'type'	=> 'text',
                        ),
                        'woo_header_helper_hover_font_color' => array(
                            'title'	=> esc_html__( 'Breadcrumbs hover Font Color', 'politix' ),
                            'atts' => 'data-default-color="' . POLITIX_FIRST_COLOR . '"',
                            'value' => POLITIX_FIRST_COLOR,
                            'addrowclasses' => 'disable grid-col-6',
                            'type'	=> 'text',
                        ),
						'woo_color_overlay_type'	=> array(
							'title'		=> esc_html__( 'Color Overlay', 'politix' ),
							'addrowclasses' => 'grid-col-12 disable',
							'type'	=> 'select',
							'source'	=> array(
								'none' => array( esc_html__( 'None', 'politix' ),  true, 'd:woo_color_overlay_opacity;d:woo_overlay_color;d:woo_gradient_settings;' ),
								'color' => array( esc_html__( 'Color', 'politix' ),  false, 'e:woo_color_overlay_opacity;e:woo_overlay_color;d:woo_gradient_settings;' ),
								'gradient' => array( esc_html__( 'Gradient', 'politix' ), false, 'e:woo_color_overlay_opacity;d:woo_overlay_color;e:woo_gradient_settings;' )
							),
						),
						'woo_color_overlay_opacity' => array(
							'type' => 'number',
							'addrowclasses' => 'disable grid-col-12',
							'title' => esc_html__( 'Opacity', 'politix' ),
							'placeholder' => esc_attr__( 'In percents', 'politix' ),
							'value' => '55'
						),
						'woo_overlay_color'	=> array(
							'title'	=> esc_html__( 'Overlay color', 'politix' ),
							'atts' => 'data-default-color="#000000"',
							'addrowclasses' => 'disable grid-col-12',
							'value' => '#000000',
							'type'	=> 'text'
						),
						'woo_gradient_settings' => array(
							'title' => esc_html__( 'Gradient Settings', 'politix' ),
							'type' => 'fields',
							'addrowclasses' => 'disable box inside-box groups grid-col-12',
							'layout' => array(
								'first_color' => array(
									'type' => 'text',
									'title' => esc_html__( 'From', 'politix' ),
									'atts' => 'data-default-color=""',
								),
								'second_color' => array(
									'type' => 'text',
									'title' => esc_html__( 'To', 'politix' ),
									'atts' => 'data-default-color=""',
								),
								'first_color_opacity' => array(
									'type' => 'number',
									'title' => esc_html__( 'From (Opacity %)', 'politix' ),
									'value' => '100',
								),
								'second_color_opacity' => array(
									'type' => 'number',
									'title' => esc_html__( 'To (Opacity %)', 'politix' ),
									'value' => '100',
								),
								'type' => array(
									'title' => esc_html__( 'Gradient type', 'politix' ),
									'type' => 'radio',
									'value' => array(
										'linear' => array( esc_html__( 'Linear', 'politix' ),  true, 'e:linear_settings;d:radial_settings' ),
										'radial' =>array( esc_html__( 'Radial', 'politix' ), false,  'd:linear_settings;e:radial_settings' ),
										),
								),
								'linear_settings' => array(
									'title' => esc_html__( 'Linear settings', 'politix'  ),
									'type' => 'fields',
									'addrowclasses' => 'disable',
									'layout' => array(
										'angle' => array(
											'type' => 'number',
											'title' => esc_html__( 'Angle', 'politix' ),
											'value' => '45',
										),
									)
								),
								'radial_settings' => array(
									'title' => esc_html__( 'Radial settings', 'politix'  ),
									'type' => 'fields',
									'addrowclasses' => 'disable',
									'layout' => array(
										'shape_settings' => array(
											'title' => esc_html__( 'Shape', 'politix' ),
											'type' => 'radio',
											'value' => array(
												'simple' => array( esc_html__( 'Simple', 'politix' ),  true, 'e:shape;d:size;d:size_keyword;' ),
												'extended' =>array( esc_html__( 'Extended', 'politix' ), false, 'd:shape;e:size;e:size_keyword;' ),
											),
										),
										'shape' => array(
											'title' => esc_html__( 'Gradient type', 'politix' ),
											'type' => 'radio',
											'value' => array(
												'ellipse' => array( esc_html__( 'Ellipse', 'politix' ),  true ),
												'circle' =>array( esc_html__( 'Circle', 'politix' ), false ),
											),
										),
										'size_keyword' => array(
											'type' => 'select',
											'title' => esc_html__( 'Size keyword', 'politix' ),
											'addrowclasses' => 'disable',
											'source' => array(
												'closest-side' => array(esc_html__( 'Closest side', 'politix' ), false),
												'farthest-side' => array(esc_html__( 'Farthest side', 'politix' ), false),
												'closest-corner' => array(esc_html__( 'Closest corner', 'politix' ), false),
												'farthest-corner' => array(esc_html__( 'Farthest corner', 'politix' ), true),
											),
										),
										'size' => array(
											'type' => 'text',
											'addrowclasses' => 'disable',
											'title' => esc_html__( 'Size', 'politix' ),
											'atts' => 'placeholder="'.esc_attr__( 'Two space separated percent values, for example (60% 55%)', 'politix' ).'"',
										),
									)
								),
							)
						),
					)
				)
			)
		);
	}

	if (function_exists('cws_core_build_settings')) {
		cws_core_build_settings($settings, $g_components);
	}
	return $settings;
}

/*
	here local or overrided components can be added/changed
*/
function cwsfw_get_local_components() {
	return array();
}
?>