<?php
function cws_vc_svg ( $settings, $value ){
	$svg = json_decode($value, true);
	$svg_content = '';
	if (!empty($svg) && function_exists('cwssvg_shortcode')) {
		$svg_content = cwssvg_shortcode($svg);
	}
	$output = '<div class="my_param_block" style="display: inline-block; min-width: 100px;">'
		.'<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput ' .
		esc_attr( $settings['param_name'] ) . ' ' .
		esc_attr( $settings['type'] ) . '_field" type="text" hidden value="' . esc_attr( $value ) . '" />';
    $output .= "<a href='#' class='cws_svg_icon'" . (!empty($value) ? " style='display:none;'" : "") . ">".esc_html__('Add', 'politix')."</a>";
    $output .= "<a href='#' class='cws_svg_icon_remove' style='color: red; " . (empty($value) ? "display:none;" : ""). "'>".esc_html__('Remove', 'politix')."</a>";
	$output .= $svg_content;
	$output .= "</div>";
	return $output;
}

?>