<?php
	// Map Shortcode in Visual Composer
	global $cws_theme_funcs;

    /* -----> STYLING GROUP TITLES <----- */
    $landscape_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_landscape-tablets'></i>";
    $portrait_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-tablets'></i>";
    $mobile_group = esc_html__('Mobile', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-smartphones'></i>";

    /* -----> STYLING TAB PROPERTIES <----- */
    $styles = array(
        array(
            "type"			=> "css_editor",
            "param_name"	=> "custom_styles",
            "group"			=> esc_html__( "Styling", 'politix' ),
            "responsive"	=> 'all'
        ),
    );

    /* -----> RESPONSIVE STYLING TABS PROPERTIES <----- */
    $styles_landscape = $styles_portrait = $styles_mobile = $styles;

    $styles_landscape =  $cws_theme_funcs->cws_responsive_styles($styles_landscape, 'landscape', $landscape_group);
    $styles_portrait =  $cws_theme_funcs->cws_responsive_styles($styles_portrait, 'portrait', $portrait_group);
    $styles_mobile =  $cws_theme_funcs->cws_responsive_styles($styles_mobile, 'mobile', $mobile_group);

    $params = cws_ext_merge_arrs( array(
        /* -----> GENERAL TAB <----- */
        array(
            array(
                "type"			=> "textfield",
                "admin_label"	=> true,
                "heading"		=> esc_html__( 'Link', 'politix' ),
                "param_name"	=> "url",
            ),
            array(
                "type"			=> "textfield",
                "heading"		=> esc_html__( 'Width in pixels', 'politix' ),
                "param_name"	=> "width"
            ),
            array(
                "type"			=> "textfield",
                "heading"		=> esc_html__( 'Height in pixels', 'politix' ),
                "param_name"	=> "height"
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Extra class name', 'politix' ),
                "description"		=> esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'politix' ),
                "param_name"		=> "el_class",
                "value"				=> ""
            ),
        ),
        /* -----> STYLING TAB <----- */
        $styles,
        /* -----> TABLET LANDSCAPE TAB <----- */
        $styles_landscape,
        /* -----> TABLET PORTRAIT TAB <----- */
        $styles_portrait,
        /* -----> MOBILE TAB <----- */
        $styles_mobile
    ));

	vc_map( array(
		"name"				=> esc_html__( 'CWS Embed', 'politix' ),
		"base"				=> "cws_sc_embed",
		'category'			=> "By CWS",
		"icon"     			=> "cws_icon",
		"weight"			=> 80,
		"params"			=> $params
	));

	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_CWS_Sc_Embed extends WPBakeryShortCode {
	    }
	}
?>