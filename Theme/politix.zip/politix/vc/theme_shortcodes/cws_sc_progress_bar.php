<?php
	// Map Shortcode in Visual Composer
	global $cws_theme_funcs;

	/* -----> THEME OPTIONS PROPERTIES <----- */
	$theme_first_color = esc_attr( $cws_theme_funcs->cws_get_option( 'theme_first_color' ) );

    /* -----> STYLING GROUP TITLES <----- */
    $landscape_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_landscape-tablets'></i>";
    $portrait_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-tablets'></i>";
    $mobile_group = esc_html__('Mobile', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-smartphones'></i>";

    /* -----> STYLING TAB PROPERTIES <----- */
    $styles = array(
        array(
            "type"			=> "css_editor",
            "param_name"	=> "custom_styles",
            "group"			=> esc_html__( "Styling", 'politix' ),
            "responsive"	=> 'all'
        ),
        array(
            "type"			=> "checkbox",
            "param_name"	=> "use_custom_color",
            "group"				=> esc_html__( "Styling", 'politix' ),
            "value"			=> array( esc_html__( 'Use Custom Colors', 'politix' ) => true )
        ),
        array(
            "type"				=> "colorpicker",
            "heading"			=> esc_html__( 'Title Color', 'politix' ),
            "param_name"		=> "custom_title_color",
            "group"				=> esc_html__( "Styling", 'politix' ),
            "edit_field_class" 	=> "vc_col-xs-4",
            "dependency"		=> array(
                "element"	=> "use_custom_color",
                "not_empty"	=> true
            ),
            "value"				=> "#000"
        ),
        array(
            "type"				=> "colorpicker",
            "heading"			=> esc_html__( 'Percents Color', 'politix' ),
            "param_name"		=> "custom_percents_color",
            "group"				=> esc_html__( "Styling", 'politix' ),
            "edit_field_class" 	=> "vc_col-xs-4",
            "dependency"		=> array(
                "element"	=> "use_custom_color",
                "not_empty"	=> true
            ),
            "value"				=> $theme_first_color
        ),
        array(
            "type"				=> "colorpicker",
            "heading"			=> esc_html__( 'Fill Color', 'politix' ),
            "param_name"		=> "custom_fill_color",
            "group"				=> esc_html__( "Styling", 'politix' ),
            "edit_field_class" 	=> "vc_col-xs-4",
            "dependency"		=> array(
                "element"	=> "use_custom_color",
                "not_empty"	=> true
            ),
            "value"				=> $theme_first_color
        ),
    );

    /* -----> RESPONSIVE STYLING TABS PROPERTIES <----- */
    $styles_landscape = $styles_portrait = $styles_mobile = $styles;

    $styles_landscape =  $cws_theme_funcs->cws_responsive_styles($styles_landscape, 'landscape', $landscape_group);
    $styles_portrait =  $cws_theme_funcs->cws_responsive_styles($styles_portrait, 'portrait', $portrait_group);
    $styles_mobile =  $cws_theme_funcs->cws_responsive_styles($styles_mobile, 'mobile', $mobile_group);

    $params = cws_ext_merge_arrs( array(
        /* -----> GENERAL TAB <----- */
        array(
            array(
                "type"			=> "textfield",
                "admin_label"	=> true,
                "heading"		=> esc_html__( 'Title', 'politix' ),
                "param_name"	=> "title",
                "value"			=> esc_html__( "Work`s done", 'politix' ),
            ),
            array(
                "type"			=> "textfield",
                "heading"		=> esc_html__( 'Progress', 'politix' ),
                "description"	=> esc_html__( 'In Percents', 'politix' ),
                "param_name"	=> "progress",
                "value"			=> "65",
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Extra class name', 'politix' ),
                "description"		=> esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'politix' ),
                "param_name"		=> "el_class",
                "value"				=> ""
            ),
        ),
        /* -----> STYLING TAB <----- */
        $styles,
        /* -----> TABLET LANDSCAPE TAB <----- */
        $styles_landscape,
        /* -----> TABLET PORTRAIT TAB <----- */
        $styles_portrait,
        /* -----> MOBILE TAB <----- */
        $styles_mobile
    ));

	vc_map( array(
		"name"				=> esc_html__( 'CWS Progress Bar', 'politix' ),
		"base"				=> "cws_sc_progress_bar",
		'category'			=> "By CWS",
		"icon"     			=> "cws_icon",
		"weight"			=> 80,
		"params"			=> $params
	));

	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_CWS_Sc_Progress_Bar extends WPBakeryShortCode {
	    }
	}
?>