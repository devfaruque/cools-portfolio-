<?php
	global $cws_theme_funcs;

	/* -----> THEME OPTIONS PROPERTIES <----- */
	$theme_first_color = esc_attr( $cws_theme_funcs->cws_get_option( 'theme_first_color' ) );

	/* -----> STYLING GROUP TITLES <----- */
	$landscape_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_landscape-tablets'></i>";
	$portrait_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-tablets'></i>";
	$mobile_group = esc_html__('Mobile', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-smartphones'></i>";

    /* -----> GET ICON CONFIG <----- */
    $icon_params = cws_ext_icon_vc_sc_config_params("add_icon", true, false);

	/* -----> STYLING TAB PROPERTIES <----- */
	$background_properties = cws_module_background_props();

	$styles = cws_ext_merge_arrs( array(
		array(
			array(
				"type"			=> "css_editor",
				"param_name"	=> "custom_styles",
				"group"			=> esc_html__( "Styling", 'politix' ),
				"responsive"	=> 'all'
			),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Minimal module height', 'politix' ),
                "param_name"		=> "min_height",
                "group"				=> esc_html__( "Styling", 'politix' ),
                "edit_field_class" 	=> "vc_col-xs-12",
                "value"				=> "215"
            ),
		),
		$background_properties,
		array(
			array(
				"type"			=> "checkbox",
				"param_name"	=> "bg_overlay",
				"group"			=> esc_html__( "Styling", 'politix' ),
				"value"			=> array( esc_html__( 'Use Background Color as Overlay', 'politix' ) => true ),
			),
			array(
				"type"			=> "checkbox",
				"param_name"	=> "customize_align",
				"group"			=> esc_html__( "Styling", 'politix' ),
				"responsive"	=> "all",
				"value"			=> array( esc_html__( 'Customize Alignment', 'politix' ) => true ),
			),
			array(
				"type"			=> "dropdown",
				"heading"		=> esc_html__( 'Module Aligning', 'politix' ),
				"param_name"	=> "aligning",
				"group"			=> esc_html__( "Styling", 'politix' ),
				"responsive"	=> "all",
				"dependency"		=> array(
					"element"	=> "customize_align",
					"not_empty"	=> true
				),
				"value"			=> array(
                    esc_html__( 'Center', 'politix' ) 	=> 'center',
					esc_html__( 'Left', 'politix' ) 	=> 'left',
					esc_html__( 'Right', 'politix' ) 	=> 'right',
				)
			),
            array(
                "type"			=> "dropdown",
                "heading"		=> esc_html__( 'Module Vertical Aligning', 'politix' ),
                "param_name"	=> "v_aligning",
                "group"			=> esc_html__( "Styling", 'politix' ),
                "responsive"	=> "all",
                "dependency"		=> array(
                    "element"	=> "customize_align",
                    "not_empty"	=> true
                ),
                "value"			=> array(
                    esc_html__( 'Middle', 'politix' ) 	=> 'center',
                    esc_html__( 'Top', 'politix' ) 	    => 'flex-start',
                    esc_html__( 'Bottom', 'politix' ) 	=> 'flex-end',
                )
            ),
			array(
				"type"			=> "checkbox",
				"param_name"	=> "customize_size",
				"group"			=> esc_html__( "Styling", 'politix' ),
				"responsive"	=> "all",
				"value"			=> array( esc_html__( 'Customize Sizes', 'politix' ) => true ),
			),
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Title Size', 'politix' ),
				"param_name"		=> "title_size",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-6",
				"responsive"		=> "all",
				"dependency"		=> array(
					"element"	=> "customize_size",
					"not_empty"	=> true
				),
				"value"				=> "32px"
			),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Icon Size', 'politix' ),
                "param_name"		=> "icon_size",
                "group"				=> esc_html__( "Styling", 'politix' ),
                "edit_field_class" 	=> "vc_col-xs-6",
                "responsive"		=> "all",
                "dependency"		=> array(
                    "element"	=> "customize_size",
                    "not_empty"	=> true
                ),
                "value"				=> "45px"
            ),
			array(
				"type"				=> "dropdown",
				"heading"			=> esc_html__( 'Button Size', 'politix' ),
				"param_name"		=> "button_size",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-6",
				"responsive"		=> "all",
				"dependency"		=> array(
					"element"	=> "customize_size",
					"not_empty"	=> true
				),
				"value"				=> array(
                    esc_html__( 'Large', 'politix' ) 	=> 'large',
                    esc_html__( 'Medium', 'politix' ) 	=> 'medium',
					esc_html__( 'Small', 'politix' ) 	=> 'small',
				)
			),
			array(
				"type"			=> "checkbox",
				"param_name"	=> "customize_colors",
				"group"			=> esc_html__( "Styling", 'politix' ),
				"value"			=> array( esc_html__( 'Customize Colors', 'politix' ) => true ),
			),
			array(
				"type"				=> "colorpicker",
				"heading"			=> esc_html__( 'Title Color', 'politix' ),
				"param_name"		=> "title_color",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-4",
				"dependency"		=> array(
					"element"	=> "customize_colors",
					"not_empty"	=> true
				),
				"value"				=> "#fff"
			),
            array(
                "type"				=> "colorpicker",
                "heading"			=> esc_html__( 'Icon Color', 'politix' ),
                "param_name"		=> "icon_color",
                "group"				=> esc_html__( "Styling", 'politix' ),
                "edit_field_class" 	=> "vc_col-xs-4",
                "dependency"		=> array(
                    "element"	=> "customize_colors",
                    "not_empty"	=> true
                ),
                "value"				=> "#fff"
            ),
            array(
                "type"				=> "colorpicker",
                "heading"			=> esc_html__( 'Icon Border Color', 'politix' ),
                "param_name"		=> "icon_bd_color",
                "group"				=> esc_html__( "Styling", 'politix' ),
                "edit_field_class" 	=> "vc_col-xs-4",
                "dependency"		=> array(
                    "element"	=> "customize_colors",
                    "not_empty"	=> true
                ),
                "value"				=> ""
            ),
			array(
				"type"				=> "colorpicker",
				"heading"			=> esc_html__( 'Divider Color', 'politix' ),
				"param_name"		=> "divider_color",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-4",
				"dependency"		=> array(
					"element"	=> "customize_colors",
					"not_empty"	=> true
				),
				"value"				=> $theme_first_color
			),
			array(
				"type"				=> "colorpicker",
				"heading"			=> esc_html__( 'Description Color', 'politix' ),
				"param_name"		=> "description_color",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-8",
				"dependency"		=> array(
					"element"	=> "customize_colors",
					"not_empty"	=> true
				),
				"value"				=> "rgba(255,255,255,0.9)"
			),
			array(
				"type"				=> "colorpicker",
				"heading"			=> esc_html__( 'Button Title', 'politix' ),
				"param_name"		=> "btn_font_color",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-4",
				"dependency"		=> array(
					"element"	=> "customize_colors",
					"not_empty"	=> true
				),
				"value"				=> "#fff"
			),
			array(
				"type"				=> "colorpicker",
				"heading"			=> esc_html__( 'Button Background', 'politix' ),
				"param_name"		=> "btn_background_color",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-4",
				"dependency"		=> array(
					"element"	=> "customize_colors",
					"not_empty"	=> true
				),
				"value"				=> $theme_first_color
			),
			array(
				"type"				=> "colorpicker",
				"heading"			=> esc_html__( 'Button Border', 'politix' ),
				"param_name"		=> "btn_border_color",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-4",
				"dependency"		=> array(
					"element"	=> "customize_colors",
					"not_empty"	=> true
				),
				"value"				=> $theme_first_color
			),
			array(
				"type"				=> "colorpicker",
				"heading"			=> esc_html__( 'Button Title (Hover)', 'politix' ),
				"param_name"		=> "btn_font_color_hover",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-4",
				"dependency"		=> array(
					"element"	=> "customize_colors",
					"not_empty"	=> true
				),
				"value"				=> $theme_first_color
			),
			array(
				"type"				=> "colorpicker",
				"heading"			=> esc_html__( 'Button Background (Hover)', 'politix' ),
				"param_name"		=> "btn_background_color_hover",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-4",
				"dependency"		=> array(
					"element"	=> "customize_colors",
					"not_empty"	=> true
				),
				"value"				=> "#fff"
			),
			array(
				"type"				=> "colorpicker",
				"heading"			=> esc_html__( 'Button Border (Hover)', 'politix' ),
				"param_name"		=> "btn_border_color_hover",
				"group"				=> esc_html__( "Styling", 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-4",
				"dependency"		=> array(
					"element"	=> "customize_colors",
					"not_empty"	=> true
				),
				"value"				=> "#fff"
			),
            array(
                "type"				=> "colorpicker",
                "heading"			=> esc_html__( 'Sticker color', 'politix' ),
                "param_name"		=> "sticker_color",
                "group"				=> esc_html__( "Styling", 'politix' ),
                "edit_field_class" 	=> "vc_col-xs-4",
                "dependency"		=> array(
                    "element"	=> "customize_colors",
                    "not_empty"	=> true
                ),
                "value"				=> "rgba(255,255,255,0.85)"
            ),
            array(
                "type"				=> "colorpicker",
                "heading"			=> esc_html__( 'Sticker background color', 'politix' ),
                "param_name"		=> "sticker_bg_color",
                "group"				=> esc_html__( "Styling", 'politix' ),
                "edit_field_class" 	=> "vc_col-xs-4",
                "dependency"		=> array(
                    "element"	=> "customize_colors",
                    "not_empty"	=> true
                ),
                "value"				=> ""
            ),
		)
	));

	/* -----> RESPONSIVE STYLING TABS PROPERTIES <----- */
	$styles_landscape = $styles_portrait = $styles_mobile = $styles;

	$styles_landscape =  $cws_theme_funcs->cws_responsive_styles($styles_landscape, 'landscape', $landscape_group);
	$styles_portrait =  $cws_theme_funcs->cws_responsive_styles($styles_portrait, 'portrait', $portrait_group);
	$styles_mobile =  $cws_theme_funcs->cws_responsive_styles($styles_mobile, 'mobile', $mobile_group);

	$params = cws_ext_merge_arrs( array(
		/* -----> GENERAL TAB <----- */
        array(
            array(
                "type"			=> "textarea",
                "admin_label"	=> true,
                "heading"		=> esc_html__( 'Title', 'politix' ),
                "param_name"	=> "title",
                "edit_field_class" 	=> "vc_col-xs-6",
                "value"			=> "Enter title here",
            ),
            array(
                "type"				=> "textarea",
                "heading"			=> esc_html__( 'Description', 'politix' ),
                "param_name"		=> "description",
                "edit_field_class" 	=> "vc_col-xs-6",
                "value"				=> "Enter description here",
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Banner Url', 'politix' ),
                "param_name"		=> "banner_url",
                "edit_field_class" 	=> "vc_col-xs-12",
                "value"				=> "#"
            ),
            array(
                "type"				=> "checkbox",
                "param_name"		=> "add_divider",
                "edit_field_class" 	=> "vc_col-xs-12",
                "value"				=> array( esc_html__( 'Add Divider', 'politix' ) => true ),
            ),
            array(
                "type"				=> "checkbox",
                "param_name"		=> "add_frame",
                "edit_field_class" 	=> "vc_col-xs-12",
                "value"				=> array( esc_html__( 'Add inner frame border', 'politix' ) => true ),
            ),
            array(
                "type"				=> "checkbox",
                "param_name"		=> "new_tab",
                "edit_field_class" 	=> "vc_col-xs-12",
                "value"				=> array( esc_html__( 'Open Link in New Tab', 'politix' ) => true ),
                "std"				=> '1'
            ),
            array(
                "type"				=> "checkbox",
                "param_name"		=> "add_button",
                "edit_field_class" 	=> "vc_col-xs-12",
                "value"				=> array( esc_html__( 'Add Button', 'politix' ) => true )
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Button Title', 'politix' ),
                "param_name"		=> "button_title",
                "edit_field_class" 	=> "vc_col-xs-6",
                "dependency"		=> array(
                    "element"	=> "add_button",
                    "not_empty"	=> true
                ),
                "value"				=> "Read More"
            ),
            array(
                "type"				=> "dropdown",
                "heading"			=> esc_html__( 'Button Position', 'politix' ),
                "param_name"		=> "button_position",
                "edit_field_class" 	=> "vc_col-xs-6",
                "dependency"		=> array(
                    "element"	=> "add_button",
                    "not_empty"	=> true
                ),
                "value"				=> array(
                    esc_html__( 'Default', 'politix' ) 	=> 'default',
                    esc_html__( 'Floated', 'politix' )	=> 'floated',
                )
            ),
            array(
                "type"				=> "checkbox",
                "param_name"		=> "add_icon",
                "edit_field_class" 	=> "vc_col-xs-12",
                "value"				=> array(
                    esc_html__( 'Add Banner icon', 'politix' ) => true
                )
            ),
        ),
        $icon_params,
		array(
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Extra class name', 'politix' ),
				"description"		=> esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'politix' ),
				"param_name"		=> "el_class",
				"value"				=> ""
			),
		),
		/* -----> STYLING TAB <----- */
		$styles,
		/* -----> TABLET LANDSCAPE TAB <----- */
		$styles_landscape,
		/* -----> TABLET PORTRAIT TAB <----- */
		$styles_portrait,
		/* -----> MOBILE TAB <----- */
		$styles_mobile
	));

	/* -----> MODULE DACLARATION <----- */
	vc_map( array(
		"name"				=> esc_html__( 'CWS Banner', 'politix' ),
		"base"				=> "cws_sc_banners",
		"category"			=> "By CWS",
		"icon" 				=> "cws_icon",
		"weight"			=> 80,
		"params"			=> $params
	));

	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_CWS_Sc_Banners extends WPBakeryShortCode {
	    }
	}
?>