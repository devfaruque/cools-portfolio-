<?php
	// Map Shortcode in Visual Composer
	global $cws_theme_funcs;

	/* -----> THEME OPTIONS PROPERTIES <----- */
	$theme_first_color = esc_attr( $cws_theme_funcs->cws_get_option( 'theme_first_color' ) );

	/* -----> STYLING GROUP TITLES <----- */
	$landscape_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_landscape-tablets'></i>";
	$portrait_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-tablets'></i>";
	$mobile_group = esc_html__('Mobile', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-smartphones'></i>";

    /* -----> GET ICON CONFIG <----- */
    $icon_params = cws_ext_icon_vc_sc_config_params();

	/* -----> STYLING TAB PROPERTIES <----- */
	$styles = array(
		array(
			"type"			=> "css_editor",
			"param_name"	=> "custom_styles",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> 'all'
		),
		array(
			"type"			=> "checkbox",
			"param_name"	=> "customize_align",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> "all",
			"value"			=> array( esc_html__( 'Customize Alignment', 'politix' ) => true ),
		),
		array(
			"type"			=> "dropdown",
			"heading"		=> esc_html__( 'Aligning', 'politix' ),
			"param_name"	=> "aligning",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> "all",
			"dependency"		=> array(
				"element"	=> "customize_align",
				"not_empty"	=> true
			),
			"value"			=> array(
				esc_html__( 'Left', 'politix' )		=> 'left',
				esc_html__( 'Center', 'politix' )	=> 'center',
				esc_html__( 'Right', 'politix' )	=> 'right',
			)
		),
		array(
			"type"				=> "checkbox",
			"param_name"		=> "custom_size",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"responsive"		=> "all",
			"value"				=> array( esc_html__( 'Custom Title Size', 'politix' ) => true )
		),
		array(
			"type"				=> "textfield",
			"heading"			=> esc_html__( 'Title Size', 'politix' ),
			"param_name"		=> "title_size",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"responsive"		=> "all",
			"dependency"		=> array(
				"element"	=> "custom_size",
				"not_empty"	=> true
			),
			"value"				=> "14px"
		),
		array(
			"type"				=> "checkbox",
			"param_name"		=> "custom_colors",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"value"				=> array( esc_html__( 'Custom Colors', 'politix' ) => true )
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Title Color', 'politix' ),
			"param_name"		=> "btn_font_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"dependency"		=> array(
				"element"	=> "custom_colors",
				"not_empty"	=> true
			),
			"edit_field_class" 	=> "vc_col-xs-6",
			"value"				=> "#fff"
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Title Hover Color', 'politix' ),
			"param_name"		=> "btn_font_color_hover",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"dependency"		=> array(
				"element"	=> "custom_colors",
				"not_empty"	=> true
			),
			"value"				=> $theme_first_color
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Background Color', 'politix' ),
			"param_name"		=> "btn_background_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"dependency"		=> array(
				"element"	=> "custom_colors",
				"not_empty"	=> true
			),
			"value"				=> $theme_first_color
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Background Hover Color', 'politix' ),
			"param_name"		=> "btn_background_color_hover",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"dependency"		=> array(
				"element"	=> "custom_colors",
				"not_empty"	=> true
			),
			"value"				=> "#fff"
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Border Color', 'politix' ),
			"param_name"		=> "btn_border_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"dependency"		=> array(
				"element"	=> "custom_colors",
				"not_empty"	=> true
			),
			"value"				=> $theme_first_color
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Border Hover Color', 'politix' ),
			"param_name"		=> "btn_border_color_hover",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"dependency"		=> array(
				"element"	=> "custom_colors",
				"not_empty"	=> true
			),
			"value"				=> $theme_first_color
		),
	);

	/* -----> RESPONSIVE STYLING TABS PROPERTIES <----- */
	$styles_landscape = $styles_portrait = $styles_mobile = $styles;

	$styles_landscape =  $cws_theme_funcs->cws_responsive_styles($styles_landscape, 'landscape', $landscape_group);
	$styles_portrait =  $cws_theme_funcs->cws_responsive_styles($styles_portrait, 'portrait', $portrait_group);
	$styles_mobile =  $cws_theme_funcs->cws_responsive_styles($styles_mobile, 'mobile', $mobile_group);

	$params = cws_ext_merge_arrs( array(
		/* -----> GENERAL TAB <----- */
        $icon_params,
		array(
            array(
                "type"			=> "dropdown",
                "heading"		=> esc_html__( 'Icon Position', 'politix' ),
                "param_name"	=> "icon_pos",
                "value"			=> array(
                    esc_html__( 'Right', 'politix' )	=> 'right',
                    esc_html__( 'Left', 'politix' )		=> 'left'
                )
            ),
			array(
				"type"				=> "textfield",
				"admin_label"		=> true,
				"heading"			=> esc_html__( 'Title', 'politix' ),
				"param_name"		=> "title",
				"value"				=> esc_html__("Click Me!", 'politix')
			),
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Link', 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-6",
				"param_name"		=> "url",
			),
			array(
				"type"				=> "dropdown",
				"heading"			=> esc_html__( 'Size', 'politix' ),
				"edit_field_class" 	=> "vc_col-xs-6",
				"param_name"		=> "size",
				"description"		=> esc_html__( 'For custom size change paddings in css editor', 'politix' ),
				"value"				=> array(
					esc_html__( 'Regular', 'politix' )		=> 'regular',
					esc_html__( 'Small', 'politix' )		=> 'small',
					esc_html__( 'Large', 'politix' )		=> 'large',
				),
			),
            array(
                "type"			=> "dropdown",
                "heading"		=> esc_html__( 'Button style', 'politix' ),
                "param_name"	=> "button_style",
                "value"			=> array(
                    esc_html__( 'Default', 'politix' )		=> 'default',
                    esc_html__( 'Advanced', 'politix' )	    => 'advanced',
                )
            ),
			array(
				"type"				=> "checkbox",
				"param_name"		=> "new_tab",
				"value"				=> array( esc_html__( 'Open in New Tab', 'politix' ) => true ),
				"std"				=> "1"
			),
            array(
                "type"				=> "checkbox",
                "param_name"		=> "is_inline",
                "value"				=> array( esc_html__( 'Inline position', 'politix' ) => true ),
            ),
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Extra class name', 'politix' ),
				"description"		=> esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'politix' ),
				"param_name"		=> "el_class",
				"value"				=> ""
			),
		),
		/* -----> STYLING TAB <----- */
		$styles,
		/* -----> TABLET LANDSCAPE TAB <----- */
		$styles_landscape,
		/* -----> TABLET PORTRAIT TAB <----- */
		$styles_portrait,
		/* -----> MOBILE TAB <----- */
		$styles_mobile
	));
	vc_map( array(
		"name"				=> esc_html__( 'CWS Button', 'politix' ),
		"base"				=> "cws_sc_button",
		'category'			=> "By CWS",
		"icon"     			=> "cws_icon",
		"weight"			=> 80,
		"params"			=> $params
	));

	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_CWS_Sc_Button extends WPBakeryShortCode {
	    }
	}
?>