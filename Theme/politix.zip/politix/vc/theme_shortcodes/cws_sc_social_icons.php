<?php
    // Map Shortcode in Visual Composer
    global $cws_theme_funcs;

    /* -----> THEME OPTIONS PROPERTIES <----- */
    $theme_first_color = esc_attr( $cws_theme_funcs->cws_get_option( 'theme_first_color' ) );

    /* -----> STYLING GROUP TITLES <----- */
    $landscape_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_landscape-tablets'></i>";
    $portrait_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-tablets'></i>";
    $mobile_group = esc_html__('Mobile', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-smartphones'></i>";

    /* -----> STYLING TAB PROPERTIES <----- */
    $styles = array(
        array(
            "type"          => "css_editor",
            "param_name"    => "custom_styles",
            "group"         => esc_html__( "Styling", 'politix' ),
            "responsive"    => 'all',
        ),
        array(
            "type"          => "checkbox",
            "param_name"    => "customize_align",
            "group"         => esc_html__( "Styling", 'politix' ),
            "responsive"    => "all",
            "value"         => array( esc_html__( 'Customize Alignment', 'politix' ) => true ),
        ),
        array(
            "type"          => "dropdown",
            "heading"       => esc_html__( 'Module Aligning', 'politix' ),
            "param_name"    => "aligning",
            "group"         => esc_html__( "Styling", 'politix' ),
            "responsive"    => "all",
            "dependency"    => array(
                "element"   => "customize_align",
                "not_empty" => true
            ),
            "value"         => array(
                esc_html__( 'Left', 'politix' )     => 'left',
                esc_html__( 'Center', 'politix' )   => 'center',
                esc_html__( 'Right', 'politix' )    => 'right',
            )
        ),
        array(
            "type"              => "checkbox",
            "param_name"        => "custom_size",
            "group"             => esc_html__( "Styling", 'politix' ),
            "responsive"        => 'all',
            "value"             => array( esc_html__( 'Custom Sizes', 'politix' ) => true ),
        ),
        array(
            "type"              => "textfield",
            "heading"           => esc_html__( 'Icon Size', 'politix' ),
            "param_name"        => "custom_icon_size",
            "group"             => esc_html__( "Styling", 'politix' ),
            "responsive"        => "all",
            "dependency"        => array(
                "element"   => "custom_size",
                "not_empty" => true
            ),
            "description"       => esc_html__( 'In pixels', 'politix' ),
            "value"             => "38"
        ),
        array(
            "type"              => "checkbox",
            "param_name"        => "custom_color",
            "group"             => esc_html__( "Styling", 'politix' ),
            "value"             => array( esc_html__( 'Custom Colors', 'politix' ) => true ),
            "std"               => '1'
        ),
        array(
            "type"              => "colorpicker",
            "heading"           => esc_html__( 'Icon', 'politix' ),
            "param_name"        => "icon_color",
            "group"             => esc_html__( "Styling", 'politix' ),
            "dependency"        => array(
                "element"   => "custom_color",
                "not_empty" => true
            ),
            "edit_field_class"  => "vc_col-xs-6",
            "value"             => $theme_first_color
        ),
        array(
            "type"              => "colorpicker",
            "heading"           => esc_html__( 'Icon Hover', 'politix' ),
            "param_name"        => "icon_color_hover",
            "group"             => esc_html__( "Styling", 'politix' ),
            "dependency"        => array(
                "element"   => "custom_color",
                "not_empty" => true
            ),
            "edit_field_class"  => "vc_col-xs-6",
            "value"             => "#fff"
        ),
        array(
            "type"              => "colorpicker",
            "heading"           => esc_html__( 'Icon Background', 'politix' ),
            "param_name"        => "icon_bg_color",
            "group"             => esc_html__( "Styling", 'politix' ),
            "dependency"        => array(
                "element"   => "custom_color",
                "not_empty" => true
            ),
            "edit_field_class"  => "vc_col-xs-6",
            "value"             => "#fff"
        ),
        array(
            "type"              => "colorpicker",
            "heading"           => esc_html__( 'Icon Background Hover', 'politix' ),
            "param_name"        => "icon_bg_color_hover",
            "group"             => esc_html__( "Styling", 'politix' ),
            "dependency"        => array(
                "element"   => "custom_color",
                "not_empty" => true
            ),
            "edit_field_class"  => "vc_col-xs-6",
            "value"             => $theme_first_color
        ),
    );

    /* -----> RESPONSIVE STYLING TABS PROPERTIES <----- */
    $styles_landscape = $styles_portrait = $styles_mobile = $styles;

    $styles_landscape =  $cws_theme_funcs->cws_responsive_styles($styles_landscape, 'landscape', $landscape_group);
    $styles_portrait =  $cws_theme_funcs->cws_responsive_styles($styles_portrait, 'portrait', $portrait_group);
    $styles_mobile =  $cws_theme_funcs->cws_responsive_styles($styles_mobile, 'mobile', $mobile_group);

    $params = cws_ext_merge_arrs( array(
        /* -----> GENERAL TAB <----- */
        array(
            array(
                'type' => 'param_group',
                'heading' => esc_html__( 'Values', 'politix' ),
                'param_name' => 'values',
                'description' => esc_html__( 'Enter values for graph - value, title and color.', 'politix' ),
                'value' => urlencode( json_encode( array(
                    array(
                        'link' => 'https://www.facebook.com/',
                        'icon' => 'fa fa-facebook',
                        'title' => esc_html__( 'Facebook', 'politix' ),
                        'new_tab' => true,
                    ),
                    array(
                        'link' => 'https://twitter.com/',
                        'icon' => 'fa fa-twitter',
                        'title' => esc_html__( 'Twitter', 'politix' ),
                        'new_tab' => true,
                    ),
                    array(
                        'link' => 'https://www.instagram.com/',
                        'icon' => 'fa fa-instagram',
                        'title' => esc_html__( 'Instagram', 'politix' ),
                        'new_tab' => true,
                    ),
                ) ) ),
                'params' => array(
                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__( 'Icon', 'politix' ),
                        'param_name' => 'icon',
                        'value' => 'fa fa-adjust', // default value to backend editor admin_label
                        'settings' => array(
                            'emptyIcon' => true,
                            // default true, display an "EMPTY" icon?
                            'iconsPerPage' => 200,
                            // default 100, how many icons per/page to display, we use (big number) to display all icons in single page
                        ),
                        'description' => esc_html__( 'Select icon from library.', 'politix' ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__( 'Link', 'politix' ),
                        'param_name' => 'link',
                        'admin_label' => true,
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__( 'Title', 'politix' ),
                        'param_name' => 'title',
                        'admin_label' => true,
                    ),
                    array(
                        "type"          => "checkbox",
                        "param_name"    => "new_tab",
                        "std"           => true,
                        "value"         => array( esc_html__( 'Open in New Tab', 'politix' ) => true )
                    ),
                ),
            ),
            array(
                "type"              => "dropdown",
                "heading"           => esc_html__( 'Size', 'politix' ),
                "param_name"        => "ic_size",
                "edit_field_class"  => "vc_col-xs-6",
                "value"             => array(
                    esc_html__( 'Mini', 'politix' )     => '1x',
                    esc_html__( 'Small', 'politix' )    => 'lg',
                    esc_html__( 'Medium', 'politix' )   => '2x',
                    esc_html__( 'Big', 'politix' )      => '3x',
                ),
                "std"               => '2x'
            ),
            array(
                "type"              => "dropdown",
                "heading"           => esc_html__( 'Shape', 'politix' ),
                "param_name"        => "icon_shape",
                "edit_field_class"  => "vc_col-xs-6",
                "value"             => array(
                    esc_html__( 'None', 'politix' )     => 'none',
                    esc_html__( 'Squared', 'politix' )  => 'squared',
                    esc_html__( 'Round', 'politix' )    => 'round',
                ),
            ),
            array(
                "type"              => "textfield",
                "heading"           => esc_html__( 'Extra class name', 'politix' ),
                "description"       => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'politix' ),
                "param_name"        => "el_class",
                "value"             => ""
            )
        ),
        /* -----> STYLING TAB <----- */
        $styles,
        /* -----> TABLET LANDSCAPE TAB <----- */
        $styles_landscape,
        /* -----> TABLET PORTRAIT TAB <----- */
        $styles_portrait,
        /* -----> MOBILE TAB <----- */
        $styles_mobile
    ));

    vc_map( array(
        "name"              => esc_html__( 'CWS Social Icons', 'politix' ),
        "base"              => "cws_sc_social_icons",
        'category'          => "By CWS",
        "weight"            => 80,
        'icon'              => 'cws_icon',
        "params"            => $params
    ));

    if ( class_exists( 'WPBakeryShortCode' ) ) {
        class WPBakeryShortCode_CWS_Sc_Social_Icons extends WPBakeryShortCode {
        }
    }

?>