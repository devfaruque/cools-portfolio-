<?php
	// Map Shortcode in Visual Composer
	global $cws_theme_funcs;

	/* -----> THEME OPTIONS PROPERTIES <----- */
	$theme_first_color 	= esc_attr( $cws_theme_funcs->cws_get_option( 'theme_first_color' ) );
	$body_font_color 	= esc_attr( $cws_theme_funcs->cws_get_option('body-font')['color'] );

	/* -----> STYLING GROUP TITLES <----- */
	$landscape_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_landscape-tablets'></i>";
	$portrait_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-tablets'></i>";
	$mobile_group = esc_html__('Mobile', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-smartphones'></i>";


	/* -----> STYLING TAB PROPERTIES <----- */
	$styles = array(
		array(
			"type"			=> "css_editor",
			"param_name"	=> "custom_styles",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> 'all'
		),
        array(
            "type"			=> "checkbox",
            "param_name"	=> "customize_align",
            "group"			=> esc_html__( "Styling", 'politix' ),
            "responsive"	=> "all",
            "value"			=> array( esc_html__( 'Customize Alignment', 'politix' ) => true ),
        ),
        array(
            "type"          => "dropdown",
            "heading"       => esc_html__( 'Module Aligning', 'politix' ),
            "param_name"    => "aligning",
            "group"         => esc_html__( "Styling", 'politix' ),
            "responsive"	=> "all",
            "dependency"	=> array(
				"element"	=> "customize_align",
				"not_empty"	=> true
			),
            "value"         => array(
                esc_html__( 'Center', 'politix' )   => 'center',
                esc_html__( 'Left', 'politix' )     => 'left',
                esc_html__( 'Right', 'politix' )    => 'right',
            )
        ),
        array(
			"type"				=> "checkbox",
			"param_name"		=> "custom_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"value"				=> array( esc_html__( 'Custom Colors', 'politix' ) => true ),
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Author Name', 'politix' ),
			"param_name"		=> "name_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"dependency"		=> array(
				"element"	=> "custom_color",
				"not_empty"	=> true
			),
			"edit_field_class" 	=> "vc_col-xs-4",
			"value"				=> "#000000"
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Author position', 'politix' ),
			"param_name"		=> "pos_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"dependency"		=> array(
				"element"	=> "custom_color",
				"not_empty"	=> true
			),
			"edit_field_class" 	=> "vc_col-xs-4",
			"value"				=> "#7e7e80"
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Quote', 'politix' ),
			"param_name"		=> "quote_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"dependency"		=> array(
				"element"	=> "custom_color",
				"not_empty"	=> true
			),
			"edit_field_class" 	=> "vc_col-xs-4",
			"value"				=> $body_font_color
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Dots Color', 'politix' ),
			"param_name"		=> "dots_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"dependency"		=> array(
				"element"	=> "custom_color",
				"not_empty"	=> true
			),
			"edit_field_class" 	=> "vc_col-xs-4",
			"value"				=> "rgba(0,0,0,0.3)"
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Dots Active Color', 'politix' ),
			"param_name"		=> "dots_active_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"dependency"		=> array(
				"element"	=> "custom_color",
				"not_empty"	=> true
			),
			"edit_field_class" 	=> "vc_col-xs-4",
			"value"				=> $theme_first_color
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Quotes icon color', 'politix' ),
			"param_name"		=> "quotes_icon_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"dependency"		=> array(
				"element"	=> "custom_color",
				"not_empty"	=> true
			),
			"edit_field_class" 	=> "vc_col-xs-4",
			"value"				=> $theme_first_color
		),
        array(
            "type"				=> "colorpicker",
            "heading"			=> esc_html__( 'Discrete testimonial item background color', 'politix' ),
            "param_name"		=> "item_bg_color",
            "group"				=> esc_html__( "Styling", 'politix' ),
            "edit_field_class" 	=> "vc_col-xs-4",
            "value"				=> ""
        ),
	);

	/* -----> RESPONSIVE STYLING TABS PROPERTIES <----- */
	$styles_landscape = $styles_portrait = $styles_mobile = $styles;

	$styles_landscape =  $cws_theme_funcs->cws_responsive_styles($styles_landscape, 'landscape', $landscape_group);
	$styles_portrait =  $cws_theme_funcs->cws_responsive_styles($styles_portrait, 'portrait', $portrait_group);
	$styles_mobile =  $cws_theme_funcs->cws_responsive_styles($styles_mobile, 'mobile', $mobile_group);

	$params = cws_ext_merge_arrs( array(
		/* -----> GENERAL TAB <----- */
		array(
            array(
                "type"			=> "textfield",
                "heading"		=> esc_html__( 'Module Title', 'politix' ),
                "param_name"	=> "module_title",
                "admin_label"	=> true,
                "value"			=> esc_html__("Enter title here", 'politix'),
            ),
			array(
				"type"			=> "dropdown",
				"heading"		=> esc_html__( 'Testimonials Style', 'politix' ),
				"param_name"	=> "testimonials_style",
                "admin_label"	=> true,
				"value"			=> array(
					esc_html__( 'Standard Style', 'politix' )	=> 'standard_style',
					esc_html__( 'Large Style', 'politix' )		=> 'large_style',
				),
			),
            array(
                "type"			=> "dropdown",
                "heading"		=> esc_html__( 'Info position', 'politix' ),
                "param_name"	=> "info_position",
                "value"			=> array(
                    esc_html__( 'Under Text', 'politix' )	=> 'under',
                    esc_html__( 'Above Text', 'politix' )	=> 'above',
                    esc_html__( 'Beside Text', 'politix' )	=> 'beside',
                ),
            ),
			array(
                'type' => 'param_group',
                'heading' => esc_html__( 'Values', 'politix' ),
                'param_name' => 'values',
                'description' => esc_html__( 'Enter values for graph - thumbnail, quote, author name and author position.', 'politix' ),
                'value' => urlencode( json_encode( array(
                    array(
                        'thumbnail' 		    => '',
                        'thumbnail_size'        => 'full',
                        'quote' 			    => '',
                        'author_name' 		    => 'John Doe',
                        'author_pos' 		    => '',
                        'testimonial_rating' 	=> '',
                    ),
                    array(
                        'thumbnail' 		    => '',
                        'thumbnail_size'        => 'full',
                        'quote' 			    => '',
                        'author_name' 		    => 'Jane Doe',
                        'author_pos' 		    => '',
                        'testimonial_rating' 	=> '',
                    ),
                    array(
                        'thumbnail' 		    => '',
                        'thumbnail_size'        => 'full',
                        'quote' 			    => '',
                        'author_name' 		    => 'John Doe',
                        'author_pos' 		    => '',
                        'testimonial_rating' 	=> '',
                    ),
                ) ) ),
                'params' => array(
		            array(
						"type"			        => "attach_image",
						"heading"		        => esc_html__( 'Thumbnail', 'politix' ),
						"param_name"	        => "thumbnail",
                        "edit_field_class"      => "vc_col-xs-6",
					),
                    array(
                        "type"			=> "dropdown",
                        "heading"		=> esc_html__( 'Thumbnail size', 'politix' ),
                        "param_name"	=> "thumbnail_size",
                        "value"         => array(
                            esc_html__( 'Full', 'politix' )      => 'full',
                            esc_html__( 'Large', 'politix' )     => 'large',
                            esc_html__( 'Medium', 'politix' )    => 'medium',
                            esc_html__( 'Thumbnail', 'politix' ) => 'thumbnail',
                        ),
                        "edit_field_class" 	=> "vc_col-xs-6",
                    ),
                    array(
						"type"			=> "textarea",
						"heading"		=> esc_html__( 'Quote', 'politix' ),
						"param_name"	=> "quote",
					),
					array(
						"type"			=> "textfield",
						"heading"		=> esc_html__( 'Author Name', 'politix' ),
						"param_name"	=> "author_name",
                        'admin_label' 	=> true,
					),
					array(
						"type"			=> "textfield",
						"heading"		=> esc_html__( 'Author Position', 'politix' ),
						"param_name"	=> "author_pos",
                        'admin_label' 	=> true,
					),
                    array(
                        "type"			=> "checkbox",
                        "param_name"	=> "show_rating",
                        "value"         => array( esc_html__( 'Show rating', 'politix' ) => true ),
                    ),
                    array(
                        "type"			=> "dropdown",
                        "heading"		=> esc_html__( 'Testimonial Rating', 'politix' ),
                        "param_name"	=> "testimonial_rating",
                        "value"         => array(
                            esc_html__( 'Very bad', 'politix' )     => '0',
                            esc_html__( 'Bad', 'politix' )          => '1',
                            esc_html__( 'Poor', 'politix' )         => '2',
                            esc_html__( 'Fair', 'politix' )         => '3',
                            esc_html__( 'Good', 'politix' )         => '4',
                            esc_html__( 'Excellent', 'politix' )    => '5',
                        ),
                        "dependency"	=> array(
                            "element"	=> "show_rating",
                            "not_empty"	=> true
                        ),
                    ),
                ),
            ),
			array(
                "type"          => "dropdown",
                "heading"       => esc_html__( 'Testimonials Grid', 'politix' ),
                "param_name"    => "item_grid",
                "admin_label"	=> true,
                "dependency"	=> array(
					"element"	=> "testimonials_style",
					"value"		=> "standard_style"
				),
                "value"         => array(
                    esc_html__( 'One Column', 'politix' )    => '1',
                    esc_html__( 'Two Columns', 'politix' )   => '2',
                    esc_html__( 'Three Columns', 'politix' ) => '3',
                ),              
            ),
            array(
                "type"          => "checkbox",
                "param_name"    => "use_carousel",
                "value"         => array( esc_html__( 'Use Carousel', 'politix' ) => true ),
                "std"           => "1",
            ),
            array(
                "type"			=> "checkbox",
                "param_name"	=> "carousel_infinite",
                'dependency'		=> array(
                    'element'	=> 'use_carousel',
                    'not_empty'		=> true
                ),
                "value"			=> array( esc_html__( 'Infinite Loop', 'politix' ) => true )
            ),
            array(
                "type"          => "checkbox",
                "param_name"    => "autoplay",
                "value"         => array( esc_html__( 'Autoplay', 'politix' ) => true ),
                "dependency"	=> array(
					"element"	=> "use_carousel",
					"not_empty"	=> true
				),
            ),
			array(
				"type"			=> "textfield",
				"heading"		=> esc_html__( 'Autoplay Speed', 'politix' ),
				"param_name"	=> "autoplay_speed",
                "dependency"	=> array(
					"element"	=> "autoplay",
					"not_empty"	=> true
				),
				"value" 		=> "3000"
			),
            array(
                "type"			=> "checkbox",
                "param_name"	=> "pause_on_hover",
                "dependency"	=> array(
                    "element"	=> "autoplay",
                    "not_empty"	=> true
                ),
                "value"			=> array( esc_html__( 'Pause on Hover', 'politix' ) => true )
            ),
            array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Extra class name', 'politix' ),
				"description"		=> esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'politix' ),
				"param_name"		=> "el_class",
				"value"				=> ""
			)
		),
		/* -----> STYLING TAB <----- */
		$styles,
		/* -----> TABLET LANDSCAPE TAB <----- */
		$styles_landscape,
		/* -----> TABLET PORTRAIT TAB <----- */
		$styles_portrait,
		/* -----> MOBILE TAB <----- */
		$styles_mobile
	));

	vc_map( array(
		"name"				=> esc_html__( 'Custom Testimonials', 'politix' ),
		"base"				=> "cws_sc_vc_testimonial",
		'category'			=> "By CWS",
		"icon"     			=> "cws_icon",
		"weight"			=> 80,
		"params"			=> $params
	));

	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_CWS_Sc_Testimonial extends WPBakeryShortCode {
	    }
	}
?>