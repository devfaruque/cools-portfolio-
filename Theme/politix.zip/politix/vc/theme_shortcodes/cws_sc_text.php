<?php
	global $cws_theme_funcs;

	/* -----> THEME OPTIONS PROPERTIES <----- */
	$theme_first_color = esc_attr( $cws_theme_funcs->cws_get_option( 'theme_first_color' ) );
	$theme_second_color = esc_attr( $cws_theme_funcs->cws_get_option( 'theme_second_color' ) );
	$header_color = esc_attr( $cws_theme_funcs->cws_get_option('header-font')['color'] );
	$body_color = esc_attr( $cws_theme_funcs->cws_get_option('body-font')['color'] );

	/* -----> STYLING GROUP TITLES <----- */
	$landscape_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_landscape-tablets'></i>";
	$portrait_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-tablets'></i>";
	$mobile_group = esc_html__('Mobile', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-smartphones'></i>";

	/* -----> STYLING TAB PROPERTIES <----- */
	$styles = array(
		array(
			"type"			=> "css_editor",
			"param_name"	=> "custom_styles",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> 'all',
		),
		array(
			"type"			=> "checkbox",
			"param_name"	=> "customize_align",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> "all",
			"value"			=> array( esc_html__( 'Customize Alignment', 'politix' ) => true ),
		),
		array(
			"type"			=> "dropdown",
			"heading"		=> esc_html__( 'Text Alignment', 'politix' ),
			"group"			=> esc_html__( "Styling", 'politix' ),
			"param_name"	=> "module_alignment",
			"responsive"	=> "all",
			"dependency"		=> array(
				"element"	=> "customize_align",
				"not_empty"	=> true
			),
			"value"			=> array(
				esc_html__( "Left", 'politix' ) => 'left',
				esc_html__( "Center", 'politix' ) => 'center',
				esc_html__( "Right", 'politix' ) => 'right',
			),
		),
		array(
			"type"			=> "checkbox",
			"param_name"	=> "customize_size",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> 'all',
			"value"			=> array( esc_html__( 'Customize Sizes', 'politix' ) => true ),
		),
		array(
			"type"				=> "textfield",
			"heading"			=> esc_html__( 'Title Size', 'politix' ),
			"param_name"		=> "title_size",
			"edit_field_class" 	=> "vc_col-xs-4",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"responsive"		=> 'all',
			"dependency"		=> array(
				"element"	=> "customize_size",
				"not_empty"	=> true
			),
			"value"				=> "42px",
		),
		array(
			"type"				=> "textfield",
			"heading"			=> esc_html__( 'Subtitle Size', 'politix' ),
			"param_name"		=> "subtitle_size",
			"edit_field_class" 	=> "vc_col-xs-4",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"responsive"		=> 'all',
			"dependency"		=> array(
				"element"	=> "customize_size",
				"not_empty"	=> true
			),
			"value"				=> "14px",
		),
		array(
			"type"			=> "textfield",
			"heading"		=> esc_html__( 'Title Margins', 'politix' ),
			"param_name"	=> "title_margins",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> 'all',
			"description"	=> esc_html__( '1, 2( top/bottom, left/right ) or 4, space separated, values with units', 'politix' ),
			"dependency"	=> array(
				"element"	=> "customize_size",
				"not_empty"	=> true
			),
			"value"			=> "0px 0px 0px 0px",
		),	
		array(
			"type"			=> "checkbox",
			"param_name"	=> "customize_colors",
			"std"			=> "1",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"value"			=> array( esc_html__( 'Customize Colors', 'politix' ) => true ),
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Title Color', 'politix' ),
			"param_name"		=> "custom_title_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-3",
			"dependency"		=> array(
				"element"	=> "customize_colors",
				"not_empty"	=> true
			),
			"value"				=> $header_color,
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Subtitle Color', 'politix' ),
			"param_name"		=> "custom_subtitle_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-3",
			"dependency"		=> array(
				"element"	=> "customize_colors",
				"not_empty"	=> true
			),
			"value"				=> 'rgba(0,0,0,0.8)',
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Divider Color', 'politix' ),
			"param_name"		=> "custom_divider_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-3",
			"dependency"		=> array(
				"element"	=> "customize_colors",
				"not_empty"	=> true
			),
			"value"				=> $theme_first_color,
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Font Color', 'politix' ),
			"param_name"		=> "custom_font_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-3",
			"dependency"		=> array(
				"element"	=> "customize_colors",
				"not_empty"	=> true
			),
			"value"				=> $body_color,
		),
	);

	/* -----> RESPONSIVE STYLING TABS PROPERTIES <----- */
	$styles_landscape = $styles_portrait = $styles_mobile = $styles;

	$styles_landscape =  $cws_theme_funcs->cws_responsive_styles($styles_landscape, 'landscape', $landscape_group);
	$styles_portrait =  $cws_theme_funcs->cws_responsive_styles($styles_portrait, 'portrait', $portrait_group);
	$styles_mobile =  $cws_theme_funcs->cws_responsive_styles($styles_mobile, 'mobile', $mobile_group);

	$params = cws_ext_merge_arrs( array(
		/* -----> GENERAL TAB <----- */
		array(
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Subtitle', 'politix' ),
				"param_name"		=> "subtitle",
				"value"				=> esc_html__("Enter subtitle here", 'politix'),
				"admin_label"		=> true,
			),
            array(
                "type"			=> "dropdown",
                "heading"		=> esc_html__( 'Subtitle Position', 'politix' ),
                "param_name"	=> "subtitle_position",
                "responsive"	=> "all",
                "value"			=> array(
                    esc_html__( "Above", 'politix' ) => 'above',
                    esc_html__( "Under", 'politix' ) => 'under',
                ),
                "std"           => 'above'
            ),
			array(
				"type"				=> "textarea",
				"heading"			=> esc_html__( 'Title', 'politix' ),
				"param_name"		=> "title",
				"value"				=> esc_html__("Enter title here", 'politix'),
				"edit_field_class" 	=> "vc_col-xs-6",
				"admin_label"		=> true,
			),
			array(
				"type"				=> "dropdown",
				"heading"			=> esc_html__( 'Title HTML Tag', 'politix' ),
				"param_name"		=> "title_tag",
				"edit_field_class" 	=> "vc_col-xs-6",
				"value"				=> array(
					esc_html__( "Default - (H3)", 'politix' ) 	=> 'h3',
					esc_html__( "H1", 'politix' ) 				=> 'h1',
					esc_html__( "H2", 'politix' ) 				=> 'h2',
					esc_html__( "H3", 'politix' ) 				=> 'h3',
					esc_html__( "H4", 'politix' ) 				=> 'h4',
					esc_html__( "H5", 'politix' ) 				=> 'h5',
					esc_html__( "H6", 'politix' ) 				=> 'h6',
				),
			),
			array(
				"type"			=> "checkbox",
				"param_name"	=> "add_divider",
				"value"			=> array( esc_html__( 'Add Divider', 'politix' ) => true ),
			),
            array(
                "type"			=> "dropdown",
                "heading"		=> esc_html__( 'Divider Position', 'politix' ),
                "param_name"	=> "divider_position",
                "value"			=> array(
                    esc_html__( "Left", 'politix' )  => 'left',
                    esc_html__( "Right", 'politix' ) => 'right',
                    esc_html__( "Under", 'politix' ) => 'under',
                ),
                "std"           => 'left',
                "dependency"	=> array(
                    "element"	=> "add_divider",
                    "not_empty"		=> true
                )
            ),
            array(
                "type"			=> "checkbox",
                "param_name"	=> "add_pattern",
                "value"			=> array( esc_html__( 'Add Pattern', 'politix' ) => true ),
                "dependency"	=> array(
                    "element"	=> "divider_position",
                    "value"		=> "under"
                )
            ),
			array(
				"type"			=> "textarea_html",
				"heading"		=> esc_html__( 'Text', 'politix' ),
				"param_name"	=> "content",
			),
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Extra class name', 'politix' ),
				"description"		=> esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'politix' ),
				"param_name"		=> "el_class",
				"value"				=> ""
			),
		),
		/* -----> STYLING TAB <----- */
		$styles,
		/* -----> TABLET LANDSCAPE TAB <----- */
		$styles_landscape,
		/* -----> TABLET PORTRAIT TAB <----- */
		$styles_portrait,
		/* -----> MOBILE TAB <----- */
		$styles_mobile
	));

	/* -----> MODULE DACLARATION <----- */
	vc_map( array(
		"name"				=> esc_html__( 'CWS Text', 'politix' ),
		"base"				=> "cws_sc_text",
		'category'			=> "By CWS",
		"icon"     			=> "cws_icon",		
		"weight"			=> 80,
		"params"			=> $params
	));

	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_CWS_Sc_Text extends WPBakeryShortCode {
	    }
	}
?>