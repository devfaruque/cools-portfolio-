<?php
	// Map Shortcode in Visual Composer
	global $cws_theme_funcs;

    /* -----> THEME OPTIONS PROPERTIES <----- */
    $theme_first_color = esc_attr( $cws_theme_funcs->cws_get_option( 'theme_first_color' ) );

    /* -----> STYLING GROUP TITLES <----- */
    $landscape_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_landscape-tablets'></i>";
    $portrait_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-tablets'></i>";
    $mobile_group = esc_html__('Mobile', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-smartphones'></i>";

    /* -----> GET ICON CONFIG <----- */
    $icon_params = cws_ext_icon_vc_sc_config_params();

    /* -----> STYLING TAB PROPERTIES <----- */
    $styles = array(
        array(
            "type"			=> "css_editor",
            "param_name"	=> "custom_styles",
            "group"			=> esc_html__( "Styling", 'politix' ),
            "responsive"	=> 'all'
        ),
        array(
            "type"				=> "attach_image",
            "heading"			=> esc_html__( 'Highlighted Item Background Image', 'politix' ),
            "param_name"		=> "bg_image",
            "group"				=> esc_html__( "Styling", 'politix' )
        ),
        array(
            "type"			    => "checkbox",
            "param_name"	    => "customize_colors",
            "group"				=> esc_html__( "Styling", 'politix' ),
            "value"			    => array( esc_html__( 'Customize Colors', 'politix' ) => true )
        ),
        array(
            "type"				=> "colorpicker",
            "heading"			=> esc_html__( 'Accent Color', 'politix' ),
            "param_name"		=> "accent_color_light",
            "group"				=> esc_html__( "Styling", 'politix' ),
            "value"				=> $theme_first_color,
            "dependency"	    => array(
                "element"	    => "customize_colors",
                "not_empty"	    => true
            ),
        ),
        array(
            "type"				=> "colorpicker",
            "heading"			=> esc_html__( 'Accent Color (Highlighted item)', 'politix' ),
            "param_name"		=> "accent_color_dark",
            "group"				=> esc_html__( "Styling", 'politix' ),
            "value"				=> "#ffffff",
            "dependency"	    => array(
                "element"	    => "customize_colors",
                "not_empty"	    => true
            ),
        ),
    );

    /* -----> RESPONSIVE STYLING TABS PROPERTIES <----- */
    $styles_landscape = $styles_portrait = $styles_mobile = $styles;

    $styles_landscape =  $cws_theme_funcs->cws_responsive_styles($styles_landscape, 'landscape', $landscape_group);
    $styles_portrait =  $cws_theme_funcs->cws_responsive_styles($styles_portrait, 'portrait', $portrait_group);
    $styles_mobile =  $cws_theme_funcs->cws_responsive_styles($styles_mobile, 'mobile', $mobile_group);

    $params = cws_ext_merge_arrs( array(
        /* -----> GENERAL TAB <----- */
        array(
            array(
                "type"				=> "textfield",
                "admin_label"		=> true,
                "heading"			=> esc_html__( 'Title', 'politix' ),
                "param_name"		=> "title",
                "value"				=> esc_html("Enter title here", 'politix')
            ),
        ),
        $icon_params,
        array(
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Price', 'politix' ),
                "param_name"		=> "price",
                "edit_field_class" 	=> "vc_col-xs-3",
                "value"				=> ""
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Price Сurrency', 'politix' ),
                "param_name"		=> "currency",
                "edit_field_class" 	=> "vc_col-xs-3",
                "value"				=> "$"
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Price Description', 'politix' ),
                "param_name"		=> "price_desc",
                "edit_field_class" 	=> "vc_col-xs-3",
                "value"				=> esc_html__("per month", 'politix')
            ),
            array(
                "type"			    => "checkbox",
                "param_name"	    => "add_button",
                "value"			    => array( esc_html__( 'Add Button', 'politix' ) => true )
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Button Title', 'politix' ),
                "param_name"		=> "button_title",
                "edit_field_class" 	=> "vc_col-xs-6",
                "value"				=> esc_html__("Learn More", "politix"),
                "dependency"	    => array(
                    "element"	    => "add_button",
                    "not_empty"	    => true
                ),
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Button Link', 'politix' ),
                "param_name"		=> "button_url",
                "edit_field_class" 	=> "vc_col-xs-6",
                "value"				=> "#",
                "dependency"	    => array(
                    "element"	    => "add_button",
                    "not_empty"	    => true
                ),
            ),
            array(
                "type"			=> "checkbox",
                "param_name"	=> "button_new_tab",
                "dependency"	=> array(
                    "element"	=> "add_button",
                    "not_empty"	=> true
                ),
                "value"			=> array( esc_html__( 'Open Link in New Tab', 'politix' ) => true )
            ),
            array(
                'type' => 'param_group',
                'heading' => esc_html__( 'Values', 'politix' ),
                'param_name' => 'values',
                'value' => urlencode( json_encode( array(
                    array(
                        'text' 	=> '',
                    ),
                ) ) ),
                'params' => array(
                    array(
                        "type"			=> "textarea",
                        "heading"		=> esc_html__( 'Text Information Row', 'politix' ),
                        "param_name"	=> "text",
                    ),
                ),
            ),
            array(
                "type"				=> "checkbox",
                "param_name"		=> "highlighted",
                "value"				=> array( esc_html__( 'Highlight this item', 'politix' ) => true ),
            ),
            array(
                "type"				=> "textarea_html",
                "heading"			=> esc_html__( 'Additional Text', 'politix' ),
                "param_name"		=> "content",
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Extra class name', 'politix' ),
                "description"		=> esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'politix' ),
                "param_name"		=> "el_class",
                "value"				=> ""
            ),
        ),
        /* -----> STYLING TAB <----- */
        $styles,
        /* -----> TABLET LANDSCAPE TAB <----- */
        $styles_landscape,
        /* -----> TABLET PORTRAIT TAB <----- */
        $styles_portrait,
        /* -----> MOBILE TAB <----- */
        $styles_mobile
	));

	vc_map( array(
		"name"				=> esc_html__( 'CWS Pricing Plan', 'politix' ),
		"base"				=> "cws_sc_pricing_plan",
		'category'			=> "By CWS",
		"icon"     			=> "cws_icon",
		"weight"			=> 80,
		"params"			=> $params
	));

	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_CWS_Sc_Pricing_Plan extends WPBakeryShortCode {
	    }
	}
?>