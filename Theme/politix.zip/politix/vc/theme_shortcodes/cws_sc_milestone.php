<?php
	// Map Shortcode in Visual Composer
	global $cws_theme_funcs;

	/* -----> THEME OPTIONS PROPERTIES <----- */
	$theme_first_color = esc_attr( $cws_theme_funcs->cws_get_option( 'theme_first_color' ) );
	$theme_second_color = esc_attr( $cws_theme_funcs->cws_get_option( 'theme_second_color' ) );
    $theme_body_color = esc_attr( $cws_theme_funcs->cws_get_option('body-font')['color'] );

	/* -----> STYLING GROUP TITLES <----- */
	$landscape_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_landscape-tablets'></i>";
	$portrait_group = esc_html__('Tablet', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-tablets'></i>";
	$mobile_group = esc_html__('Mobile', 'politix')."&nbsp;&nbsp;&nbsp;<i class='vc-composer-icon vc-c-icon-layout_portrait-smartphones'></i>";

	/* -----> GET ICON CONFIG <----- */
	$icon_params = cws_ext_icon_vc_sc_config_params();

	/* -----> STYLING TAB PROPERTIES <----- */
	$styles = array(
		array(
			"type"			=> "css_editor",
			"param_name"	=> "custom_styles",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> 'all'
		),
		array(
			"type"			=> "checkbox",
			"param_name"	=> "customize_position",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> "all",
			"value"			=> array( esc_html__( 'Customize Elements Position', 'politix' ) => true ),
		),
		array(
			"type"				=> "dropdown",
			"heading"			=> esc_html__( 'Module Alignment', 'politix' ),
			"param_name"		=> "module_align",
			"responsive"		=> "all",
			"dependency"		=> array(
				"element"	=> "customize_position",
				"not_empty"	=> true
			),
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"value"				=> array(
				esc_html__( 'Left', 'politix' ) 		=> 'left',
				esc_html__( 'Center', 'politix' ) 		=> 'center',
				esc_html__( 'Right', 'politix' ) 		=> 'right',
			),
			"std"				=> "center"
		),
		array(
			"type"				=> "dropdown",
			"heading"			=> esc_html__( 'Title & Description Position', 'politix' ),
			"param_name"		=> "info_pos",
			"responsive"		=> "all",
			"dependency"		=> array(
				"element"	=> "customize_position",
				"not_empty"	=> true
			),
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"value"				=> array(
				esc_html__( 'Under counter', 'politix' ) => 'under',
                esc_html__( 'Above counter', 'politix' ) => 'above',
			),
			"std"				=> "under"
		),
        array(
            "type"				=> "dropdown",
            "heading"			=> esc_html__( 'Icon Position', 'politix' ),
            "param_name"		=> "icon_pos",
            "responsive"		=> "all",
            "dependency"		=> array(
                "element"	=> "customize_position",
                "not_empty"	=> true
            ),
            "group"				=> esc_html__( "Styling", 'politix' ),
            "edit_field_class" 	=> "vc_col-xs-6",
            "value"				=> array(
                esc_html__( 'Above info', 'politix' )  => 'above',
                esc_html__( 'Beside info', 'politix' ) => 'beside',
            ),
            "std"				=> "above"
        ),

		array(
			"type"			=> "checkbox",
			"param_name"	=> "custom_size",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"responsive"	=> "all",
			"value"			=> array( esc_html__( 'Customize Sizes', 'politix' ) => true ),
		),
		array(
			"type"				=> "textfield",
			"heading"			=> esc_html__( 'Icon Size', 'politix' ),
			"param_name"		=> "icon_size",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"responsive"		=> "all",
			"edit_field_class" 	=> "vc_col-xs-3",
			"dependency"		=> array(
				"element"	=> "custom_size",
				"not_empty"	=> true
			),
			"value"				=> "45px"
		),
		array(
			"type"				=> "textfield",
			"heading"			=> esc_html__( 'Title Size', 'politix' ),
			"param_name"		=> "title_size",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"responsive"		=> "all",
			"edit_field_class" 	=> "vc_col-xs-3",
			"dependency"		=> array(
				"element"	=> "custom_size",
				"not_empty"	=> true
			),
			"value"				=> "16px"
		),
		array(
			"type"				=> "textfield",
			"heading"			=> esc_html__( 'Description Size', 'politix' ),
			"param_name"		=> "description_size",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"responsive"		=> "all",
			"edit_field_class" 	=> "vc_col-xs-3",
			"dependency"		=> array(
				"element"	=> "custom_size",
				"not_empty"	=> true
			),
			"value"				=> "16px"
		),
		array(
			"type"				=> "textfield",
			"heading"			=> esc_html__( 'Number Size', 'politix' ),
			"param_name"		=> "number_size",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"responsive"		=> "all",
			"edit_field_class" 	=> "vc_col-xs-3",
			"dependency"		=> array(
				"element"	=> "custom_size",
				"not_empty"	=> true
			),
			"value"				=> "42px"
		),

		array(
			"type"			=> "checkbox",
			"param_name"	=> "custom_color",
			"group"			=> esc_html__( "Styling", 'politix' ),
			"value"			=> array( esc_html__( 'Customize Colors', 'politix' ) => true ),
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Icon Color', 'politix' ),
			"param_name"		=> "icon_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"dependency"		=> array(
				"element"	=> "custom_color",
				"not_empty"	=> true
			),
			"value"				=> $theme_second_color
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Counter Color', 'politix' ),
			"param_name"		=> "number_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"dependency"		=> array(
				"element"	=> "custom_color",
				"not_empty"	=> true
			),
			"value"				=> $theme_first_color
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Title Color', 'politix' ),
			"param_name"		=> "title_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"dependency"		=> array(
				"element"	=> "custom_color",
				"not_empty"	=> true
			),
			"value"				=> $theme_body_color
		),
		array(
			"type"				=> "colorpicker",
			"heading"			=> esc_html__( 'Description Color', 'politix' ),
			"param_name"		=> "description_color",
			"group"				=> esc_html__( "Styling", 'politix' ),
			"edit_field_class" 	=> "vc_col-xs-6",
			"dependency"		=> array(
				"element"	=> "custom_color",
				"not_empty"	=> true
			),
			"value"				=> $theme_body_color
		),

        array(
            "type"				=> "colorpicker",
            "heading"			=> esc_html__( 'Divider Color', 'politix' ),
            "param_name"		=> "divider_color",
            "group"				=> esc_html__( "Styling", 'politix' ),
            "edit_field_class" 	=> "vc_col-xs-6",
            "dependency"		=> array(
                "element"	=> "custom_color",
                "not_empty"	=> true
            ),
            "value"				=> "#b1b2b3"
        ),
	);

	/* -----> RESPONSIVE STYLING TABS PROPERTIES <----- */
	$styles_landscape = $styles_portrait = $styles_mobile = $styles;

	$styles_landscape =  $cws_theme_funcs->cws_responsive_styles($styles_landscape, 'landscape', $landscape_group);
	$styles_portrait =  $cws_theme_funcs->cws_responsive_styles($styles_portrait, 'portrait', $portrait_group);
	$styles_mobile =  $cws_theme_funcs->cws_responsive_styles($styles_mobile, 'mobile', $mobile_group);

	$params = cws_ext_merge_arrs( array(
		/* -----> GENERAL TAB <----- */
		$icon_params,
		array(
            array(
                "type"				=> "dropdown",
                "heading"			=> esc_html__( 'Milestone type', 'politix' ),
                "param_name"		=> "block_type",
                "edit_field_class" 	=> "vc_col-xs-6",
                "value"				=> array(
                    esc_html__( 'Standard', 'politix' ) 	=> 'standard',
                    esc_html__( 'With chart', 'politix' ) 	=> 'chart',
                ),
                "std"               => "standard"
            ),
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Title', 'politix' ),
				"param_name"		=> "title",
				"edit_field_class" 	=> "vc_col-xs-6",
				"value"				=> esc_html__("Enter title here...", 'politix'),
			),
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Description', 'politix' ),
				"param_name"		=> "description",
				"edit_field_class" 	=> "vc_col-xs-6",
				"value"				=> esc_html__("Enter description here...", 'politix'),
			),
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Count To (number)', 'politix' ),
				"param_name"		=> "number",
				"edit_field_class" 	=> "vc_col-xs-6",
				"value"				=> "99",
                "dependency"		=> array(
                    "element"	    => "block_type",
                    "value"		    => "standard"
                ),
			),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Value', 'politix' ),
                "param_name"		=> "chart_value",
                "edit_field_class" 	=> "vc_col-xs-6",
                "value"				=> "55",
                "description"       => esc_html__("Enter value for graph (Note: choose range from 0 to 100).", 'politix'),
                "dependency"		=> array(
                    "element"	    => "block_type",
                    "value"		    => "chart"
                ),
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Counter additional text', 'politix' ),
                "param_name"		=> "additional",
                "edit_field_class" 	=> "vc_col-xs-6",
                "value"				=> "",
                "dependency"		=> array(
                    "element"	    => "block_type",
                    "value"		    => "standard"
                ),
            ),
            array(
                "type"				=> "textfield",
                "heading"			=> esc_html__( 'Units', 'politix' ),
                "param_name"		=> "chart_units",
                "edit_field_class" 	=> "vc_col-xs-6",
                "value"				=> "%",
                "description"       => esc_html__("Enter measurement units (Example: %, px, points, etc.)", 'politix'),
                "dependency"		=> array(
                    "element"	    => "block_type",
                    "value"		    => "chart"
                ),
            ),
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Count Speed', 'politix' ),
				"param_name"		=> "speed",
				"edit_field_class" 	=> "vc_col-xs-6",
				"value"				=> "2000"
			),
            array(
                "type"			=> "checkbox",
                "param_name"	=> "add_divider",
                "responsive"	=> "all",
                "value"			=> array( esc_html__( 'Add Divider', 'politix' ) => true ),
            ),
            array(
                "type"			=> "checkbox",
                "param_name"	=> "separator",
                "value"			=> array( esc_html__( 'Add right divider', 'politix' ) => true ),
            ),
            array(
                "type"			=> "dropdown",
                "heading"		=> esc_html__( 'Divider heigth', 'politix' ),
                "param_name"	=> "separator_height",
                "value"			=> array(
                    esc_html__( 'Small', 'politix' )	=> 'small',
                    esc_html__( 'Large', 'politix' )	=> 'large',
                ),
                "dependency"	=> array(
                    "element"	=> "separator",
                    "not_empty"	=> true,
                ),
            ),
			array(
				"type"				=> "textfield",
				"heading"			=> esc_html__( 'Extra class name', 'politix' ),
				"description"		=> esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'politix' ),
				"param_name"		=> "el_class",
				"value"				=> ""
			),
		),
		/* -----> STYLING TAB <----- */
		$styles,
		/* -----> TABLET LANDSCAPE TAB <----- */
		$styles_landscape,
		/* -----> TABLET PORTRAIT TAB <----- */
		$styles_portrait,
		/* -----> MOBILE TAB <----- */
		$styles_mobile
	));

	vc_map( array(
		"name"				=> esc_html__( 'CWS Milestone', 'politix' ),
		"base"				=> "cws_sc_milestone",
		'category'			=> "By CWS",
		"icon"     			=> "cws_icon",
		"weight"			=> 80,
		"params"			=> $params
	));

	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_CWS_Sc_Milestone extends WPBakeryShortCode {
	    }
	}
?>