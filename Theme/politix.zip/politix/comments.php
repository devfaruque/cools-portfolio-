<?php
/**
 * The template for displaying comments
 *
 * The area of the page that contains both current comments
 * and the comment form.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}

global $cws_theme_funcs;
ob_start();
	
	if ( have_comments() ) {
			$comments_number = number_format_i18n( get_comments_number() );
			$comment_text = ($comments_number == '1') ? esc_html__( 'Comment', 'politix') : esc_html__('Comments', 'politix');
			echo "<h3 class='comments_title'>" . $comment_text . " <span class='comments-count'>$comments_number</span>" . "</h3>";

			wp_list_comments( array(
				'walker' => new Politix_Walker_Comment(),
				'avatar_size' => 80,
			) );

			if ($cws_theme_funcs){
				$cws_theme_funcs->cws_comment_nav();
			} else {

				if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) {
				?>
				<div class="comments_nav carousel_nav_panel clearfix">
					<?php
						if ( $prev_link = get_previous_comments_link( "<span class='prev'></span><span>" . esc_html__( 'Older Comments', 'politix' ) . "</span>" ) ) {
							printf( '<div class="prev_section">%s</div>', $prev_link );
						}

						if ( $next_link = get_next_comments_link( "<span>" . esc_html__( 'Newer Comments', 'politix' ) . "</span><span class='next'></span>" ) ) {
							printf( '<div class="next_section">%s</div>', $next_link );
						}
					?>
				</div><!-- .comment-navigation -->
				<?php
				}

			}

	} // have_comments()

	// If comments are closed and there are comments, let's leave a little note, shall we?
	if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) {
		echo apply_filters( 'the_content',
            "<div class='cws_msg_box_module type_info'>
                <div class='icon'>
                    <i class='flaticon-info'></i>
                </div>
                <div class='cws_msg_box_info'>
                    <div class='cws_msg_box_desc'>" . esc_html__( 'Comments are closed.', 'politix' ) . "</div>
                </div>
                <div class='close_btn'></div>
            </div>" );
	}

    comment_form();


$comments_section_content = ob_get_clean();
echo !empty( $comments_section_content ) ? "<div class='grid_row single_comments'><div id='comments' 
class='comments-area'>$comments_section_content</div></div>" : "";




?>