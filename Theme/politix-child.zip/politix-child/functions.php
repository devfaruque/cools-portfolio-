<?php

add_action( 'after_setup_theme', 'cws_child_theme_setup' );
function cws_child_theme_setup() {
    load_child_theme_textdomain( 'politix', get_stylesheet_directory() . '/languages' );
}

?>
